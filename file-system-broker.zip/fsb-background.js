import { FsbOptions               } from '../modules/options.js';
import { Logger                   } from '../modules/logger.js';
import { FsbEventLogger           } from '../modules/event_logger.js';
import { FileSystemBrokerCommands } from '../modules/commands.js';
import { logProps, getExtensionId, getExtensionName, getI18nMsg, formatMsToDateForFilename, formatMsToDateTime24HR, getMidnightDelayMS, getNextMidnightDelayMS, getMidnightMS, formatNowToDateTime24HR } from './modules/utilities.js';


/********
 * NOTE: The FileSystemBroker API CANNOT be used here.
 * That would result in sending a message to itself, which the Web Extensions API apparently does not allow.
 */
class FileSystemBroker {
  #CLASS_NAME                        = this.constructor.name;
  #extId                             = getExtensionId();
  #extName                           = getExtensionName();

  #INFO                              = false;
  #LOG                               = false;
  #DEBUG                             = false;
  #WARN                              = false;

  #LOG_MIDNIGHT_EVENTS               = true;
  #LOG_PURGE_OLD_LOG_FILES           = true;
  #LOG_REMOVE_UNINSTALLED_EXTENSIONS = true;

  #logger                            = new Logger();
  #fsbOptionsApi                     = new FsbOptions(this.#logger);
  #fsbCommandsApi                    = new FileSystemBrokerCommands(this.#logger, this.#fsbOptionsApi);
  #fsbEventLogger                    = new FsbEventLogger(this.#logger, this.#fsbOptionsApi, this.#fsbCommandsApi);

  #midnightTimeout;
  #firstMidnightTimeout              = true;
  #midnightEventDispatcher           = new EventTarget();



  constructor() {
    this.#fsbOptionsApi.setEventLogger(this.#fsbEventLogger);
    this.#fsbCommandsApi.setEventLogger(this.#fsbEventLogger);
    this.#midnightEventDispatcher.addEventListener('midnight', (e) => this.onMidnight(e));
  }



  log(...info) {
    if (this.#LOG) this.#logger.log(this.#CLASS_NAME, ...info);
  }

  logAlways(...info) {
    this.#logger.logAlways(this.#CLASS_NAME, ...info);
  }

  debug(...info) {
    if (this.#DEBUG) this.#logger.debug(this.#CLASS_NAME, ...info);
  }

  debugAlways(...info) {
    this.#logger.debugAlways(this.#CLASS_NAME, ...info);
  }

  error(...info) {
    // always log errors
    this.#logger.error(this.#CLASS_NAME, ...info);
  }

  caught(e, msg, ...info) {
    // always log errors
    this.#logger.error( this.#CLASS_NAME,
                       msg,
                       "\n- error.name:    " + e.name,
                       "\n- error.message: " + e.message,
                       "\n- error.stack:   " + e.stack,
                       "\n",
                       ...info
                     );
  }



  async run() {
    this.logAlways(`=== EXTENSION ${this.#extName} STARTED ===`);
    await this.#fsbEventLogger.logInternalEvent("startup", "success", null, "");


    var   defaultOptionsSetup = false;
    var   attempts            = 0;
    const MAX_ATTEMPTS        = 3;

    while (! defaultOptionsSetup && attempts < MAX_ATTEMPTS) {
      ++attempts;
      try {
        await this.#fsbOptionsApi.setupDefaultOptions();
        defaultOptionsSetup = true;
      } catch (error) {
        // Workaround. Several users report issues with accessing the
        // messenger.local store
        //
        //    20:30:33.873 TransactionInactiveError: A request was placed
        //    against a transaction which is currently not active, or which
        //    is finished. IndexedDB.jsm:101:46
        //
        // Assuming that this error is caused by a timing issue while
        // accessing the store concurrently, we simply try to circumvent this by
        // reloading

        if (attempts >= MAX_ATTEMPTS) {
          this.caught(error, `-- Caught error while reading settings from local storage. Attempt #${attempts} >= ${MAX_ATTEMPTS}. Giving up.`);
          return;
        }

        this.caught(error, `-- Caught error while reading settings from local storage. Attempt #${attempts} of ${MAX_ATTEMPTS}. Retrying.`);
      }
    }

    messenger.runtime.onMessage.addListener(         async (message)         => this.onMessageReceivedInternal(message)         );
    messenger.runtime.onMessageExternal.addListener( async (message, sender) => this.onMessageReceivedExternal(message, sender) );
    messenger.management.onInstalled.addListener(    async (extensionInfo)   => this.onExtensionInstalled(extensionInfo)        );
    messenger.management.onUninstalled.addListener(  async (extensionInfo)   => this.onExtensionUninstalled(extensionInfo)      );

    await this.setupMidnightTimeout();



    const showOptionsWindowOnStartupEnabled = await this.#fsbOptionsApi.isEnabledOption("fsbShowOptionsWindowOnStartup", false);
    if (showOptionsWindowOnStartupEnabled) {
      this.showOptionsWindow();
    }

////await this.showGrantExtensionAccessConfirmDialog("xxx@xxx.com"); // MABXXX  <----------------------------------------------------------------<<<<<
  }



  async setupMidnightTimeout() {
    const nowMS        = Date.now();
    const midnightMS   = getMidnightMS(nowMS, 0);
    const midnightTime = formatMsToDateTime24HR(midnightMS);
    const delayMS      = midnightMS - nowMS;
////const parameters   = { 'delayMS': delayMS, 'midnightMS': midnightMS, 'midnightTime': midnightTime }; 
    const parameters   = { 'delayMS': delayMS, 'midnightTime': midnightTime }; 
    const result       = `Setting Midnight Timeout: delayMS=${delayMS} midnightMS=${midnightMS} midnightTime="${midnightTime}"`;

    this.logAlways(`-- Setting up next Midnight Timeout -- ${result}`);

    this.#midnightTimeout = setTimeout( () => this.midnightTimerTimedOut(delayMS, nowMS), delayMS);
    if (this.#LOG_MIDNIGHT_EVENTS) await this.#fsbEventLogger.logInternalEvent("setupMidnightTimeout", "success", parameters, "");

//  if (this.#firstMidnightTimeout) {
//    this.firstMidnightTimeout = false;
//    this.#midnightTimeout = setTimeout( () => this.#midnightTimerTimedOut(10000, nowMS), 10000);
//    if (this.#LOG_MIDNIGHT_EVENTS) await this.#fsbEventLogger.logInternalEvent("setupMidnightTimeout", "success", { 'delay': 10000 }, "TEST 10000");
//  }
  }

  async midnightTimerTimedOut(delayMS, timerSetAtMS) {
    const timer = this.#midnightTimeout;
    this.#midnightTimeout = null;
    if (timer) {
      clearTimeout(timer);
    }

    const timerSetAtTime = formatMsToDateTime24HR(timerSetAtMS);
    const result         = `Timed out after ${delayMS} ms -- Set at "${timerSetAtTime}"`;
    this.logAlways(`-- ${result}`);

    if (this.#LOG_MIDNIGHT_EVENTS) {
      const parameters = { 'delayMs': delayMS, 'timerSetAt': timerSetAtTime };
      await this.#fsbEventLogger.logInternalEvent("midnightTimerTimedOut", "success", parameters, result);
    }

    this.dispatchMidnightEvent();

    await this.setupMidnightTimeout();
  }

  dispatchMidnightEvent() {
    this.logAlways("-- begin");
    const midnightEvent = new Event('midnight');
    this.#midnightEventDispatcher.dispatchEvent(midnightEvent);
    this.logAlways("-- end");
  }

  async onMidnight(e) {
    this.logAlways("-- begin");
    await this.processMidnightTasks();
    this.logAlways("-- end");
  }

  async processMidnightTasks() {
    this.logAlways("-- begin");

    try {
      if (this.#LOG_MIDNIGHT_EVENTS) await this.#fsbEventLogger.logInternalEvent("processMidnightTasks", "request", null, "");

      await this.autoRemoveUninstalledExtensions(); // this event is already logged inside call
      await this.autoPurgeOldLogFiles(); // this event is already logged inside call

      if (this.#LOG_MIDNIGHT_EVENTS) await this.#fsbEventLogger.logInternalEvent("processMidnightTasks", "success", null, "");
    } catch (error) {
      this.caught(error, "Error Processing Midnight Tasks");
    }

    this.logAlways("-- end");
  }

  async autoPurgeOldLogFiles() {
    const numDays = await this.#fsbOptionsApi.getAutoLogPurgeDays(14);
    this.debug("-- numDays: ", numDays);

    const parameters = { 'numDays': numDays };
    if (this.#LOG_PURGE_OLD_LOG_FILES) await this.#fsbEventLogger.logInternalEvent("autoPurgeOldLogFiles", "request", parameters, "");

    if (numDays > 0) {
      await this.#fsbEventLogger.deleteOldEventLogs(numDays); // this event is already logged inside call
    }

    if (this.#LOG_PURGE_OLD_LOG_FILES) await this.#fsbEventLogger.logInternalEvent("autoPurgeOldLogFiles", "success", parameters, "");
  }

  async autoRemoveUninstalledExtensions() {
    const numDays                    = await this.#fsbOptionsApi.getAutoRemoveUninstalledExtensionsDays(2);
    const deleteExtensionDirectories = await this.#fsbOptionsApi.isEnabledOnRemoveExtensionDeleteDirectory();
    this.debug(`-- numDays=${ numDays}, deleteExtensionDirectories=${deleteExtensionDirectories}`);

    const parameters = {
      'numDays':                    numDays,
      'deleteExtensionDirectories': deleteExtensionDirectories,
    };
    if (this.#LOG_REMOVE_UNINSTALLED_EXTENSIONS) await this.#fsbEventLogger.logInternalEvent("autoRemoveUninstalledExtensions", "request", parameters, "");

    const removedExtensionIds = await this.#fsbOptionsApi.autoRemoveUninstalledExtensions(numDays); // this event is already logged inside call
    this.debug(`-- Extensions removed: ${removedExtensionIds ? removedExtensionIds.length : 0}`);

    if (! deleteExtensionDirectories) {
      this.debug("-- NOT Deleting Extension Directories");
    } else {

      if (! removedExtensionIds || removedExtensionIds.length < 1) {
        this.debug("-- NO Extension Directories to delete");
      } else {

        this.debug("-- Extension Directories to delete: ${removedExtensions.length}\n", removedExtensionIds);
        const deleteParams = { 'count': removedExtensionIds.length };
        if (this.#LOG_REMOVE_UNINSTALLED_EXTENSIONS) await this.#fsbEventLogger.logInternalEvent("deleteExtensionDirectories", "request", deleteParams, "");

        for (const removedExtId of removedExtensionIds) {
          const result = await this.#fsbCommandsApi.deleteExtensionDirectory(removedExtId);// a shortcut to just calling fsbCommandsApi.processInternalCommand()
          // do we care about the result?
        }

        if (this.#LOG_REMOVE_UNINSTALLED_EXTENSIONS) await this.#fsbEventLogger.logInternalEvent("deleteExtensionDirectories", "success", deleteParams, "");
      }
    }

    if (this.#LOG_REMOVE_UNINSTALLED_EXTENSIONS) await this.#fsbEventLogger.logInternalEvent("autoRemoveUninstalledExtensions", "success", parameters, "");
  }



  async showOptionsWindow() { // COPIED FROM OptionsUI in ./optionsUI/optionsUI.js
    let   popupLeft   = 100;
    let   popupTop    = 100;
    let   popupHeight = 900;
    let   popupWidth  = 700;
    const mainWindow  = await messenger.windows.getCurrent();

    if (! mainWindow) {
      this.error("-- DID NOT GET THE CURRENT (MAIN, mail:3pane) WINDOW!!! ---");
    } else {
      this.debug( "-- Got the Current (Main, mail:3pane) Window:"
                  + `\n- mainWindow.top=${mainWindow.top}`
                  + `\n- mainWindow.left=${mainWindow.left}`
                  + `\n- mainWindow.height=${mainWindow.height}`
                  + `\n- mainWindow.width=${mainWindow.width}`
                );
      popupTop  = mainWindow.top  + 100;
      popupLeft = mainWindow.left + 100;
      if (mainWindow.height - 200 > popupHeight) popupHeight = mainWindow.Height - 200;   // make it higher, but not shorter
//////if (mainWindow.Width  - 200 > popupWidth)  popupWidth  = mainWindow.Width  - 200;   // make it wider,  but not narrower --- eh, don't need it wider
    }

    const bounds = await this.#fsbOptionsApi.getWindowBounds("optionsWindowBounds");
    if (! bounds) {
      this.debug("-- no previous window bounds");
    } else if (typeof bounds !== 'object') {
      this.error(`-- PREVIOUS WINDOW BOUNDS "optionsWindowBounds" IS NOT AN OBJECT: typeof='${typeof bounds}' #####`);
    } else {
      this.debug( "-- restoring previous window bounds:"
                  + `\n- bounds.top=${bounds.top}`
                  + `\n- bounds.left=${bounds.left}`
                  + `\n- bounds.width=${bounds.width}`
                  + `\n- bounds.height=${bounds.height}`
                );
      popupTop    = bounds.top;
      popupLeft   = bounds.left;
      popupWidth  = bounds.width;
      popupHeight = bounds.height;
    }

    const optionsUrl = messenger.runtime.getURL( "optionsUI/optionsUI.html")
                                                 + "?windowMode=true"
                                                 + `&requestedBy=${encodeURIComponent(this.#extName)}`;
    const optionsWindow = await messenger.windows.create({
      url:                 optionsUrl,
      type:                "popup",
      titlePreface:        getI18nMsg("options_fsbOptionsTitle", "Options") + " - ",
      top:                 popupTop,
      left:                popupLeft,
      height:              popupHeight,
      width:               popupWidth,
      allowScriptsToClose: true,
    });
    this.debug(`-- OptionsUI Popup Window Created -- windowId="${optionsWindow.id}" URL="${optionsUrl}"`);
  }




  async onMessageReceivedInternal(message) {
    const nowMS = Date.now();

    if (this.DEBUG) {
      this.debugAlways("-- Received Internal Message:");
      logProps("", "onMessageReceivedInternal.message", message);
    }

    if (! message.hasOwnProperty('Command')) {
      //this.logAlways( "-- Received Unknown Internal Message --", message);
//    return { "error": "Invalid Request: Message has no Command Object",
//             "code": "400"
//           };
      return false;
    }

    return await this.#fsbCommandsApi.processInternalCommand(nowMS, message.Command, this.#extId);
  }

  async XXXprocessInternalCommand(timeMS, Command, extensionId) {
    const formattedParameters = this.#fsbCommandsApi.formatParameters(Command);

    if (await this.#fsbOptionsApi.isEnabledInternalMessageLogging()) {
      this.logAlways( "-- Processing Internal Command --" // MABXXX do this in logCommand???
                      + `\n- command="${Command.command}"`
                      + `\n- parameters: ${formattedParameters}`
                    );
      this.#fsbEventLogger.logCommand(timeMS, "INTERNAL", Command);
    }

    try {
      const result = await this.#fsbCommandsApi.processCommand(Command, extensionId);

      if (! result) {
        this.error("-- NO COMMAND RESULT", message);
        return { "error": "Failed to get a Command Result",
                 "code":  "500"
               };
      } else {
        if (await this.#fsbOptionsApi.isEnabledInternalMessageResultLogging()) {
          const formattedResult = this.#fsbCommandsApi.formatCommandResult(Command, result);
          this.logAlways( "-- RESULT"
                          + "\n- INTERNAL"
                          + `\n- Command="${Command.command}"`
                          + `\n- parameters: ${formattedParameters}`
                          + `\n- result: ${formattedResult}`
                        );
          this.#fsbEventLogger.logCommandResult(timeMS, "INTERNAL", Command, result);
        }
      }

      return result;

    } catch (error) {
      this.caught(error, "Error Processing Internal Command - Code 500");
      return { "error": "Internal Error", "code":  "500" };
    }
  }




  async onMessageReceivedExternal(message, sender) {
    const nowMS = Date.now();

    if (this.DEBUG) {
      this.debugAlways("-- Received External Message:");
      logProps("", "onMessageReceivedExternal.message", message);
    }

    try {
      if (! message.hasOwnProperty('Command')) {
        this.logAlways( "-- Received Unknown External Message --", message);
        return { "error": "Invalid Request: Message has no Command Object",
                 "code": "400"
               };
      }

      const formattedParameters = this.#fsbCommandsApi.formatParameters(message.Command);
      const logCommand          = await this.#fsbOptionsApi.isEnabledExternalMessageLogging();
      const logResult           = await this.#fsbOptionsApi.isEnabledExternalMessageResultLogging();

      if (logCommand) {
        this.logAlways( "-- Received External Message --"
                        + `\n- sender.id="${sender.id}"`
                        + `\n- message.Command.command="${message.Command.command}"`
////////////////////////+ `\n- message.Command.fileName="${message.Command.fileName}"`
                        + `\n- parameters: ${formattedParameters}`
                      );
        this.#fsbEventLogger.logCommand(nowMS, sender.id, message.Command);
      }

      if (! sender || ! sender.id) {
        const error = "Message has no Sender ID";
        this.error(`-- ${error}`);
        if (logResult) {
          this.#fsbEventLogger.logCommandResult(nowMS, "UNKNOWN", message.Command, "error: " + error);
        }
        return { "error": error, "code":  "400" };
      }

      if ((typeof sender.id) !== 'string') {
        const error = "Message Sender ID type must be 'string'";
        this.error(`-- ${error}`);
        if (logResult) {
          this.#fsbEventLogger.logCommandResult(nowMS, sender.id, message.Command, "error: " + error);
        }
        return { "error": error, "code":  "400" };
      }

      if (! this.checkValidFileName(sender.id)) { // MABXXX should be checkValidExtensionId
        const error = `Message Sender ID is invalid: "${sender.id}"`;
        this.debug(`-- ${error}"`);
        if (logResult) {
          this.#fsbEventLogger.logCommandResult(nowMS, sender.id, message.Command, "error: " + error);
        }
        return { "error": error, "code":  "400" };
      }

      const cmdIsAccess = message.Command.command === 'access';
      if (cmdIsAccess) this.debug("-- command='access'");

      if (! await this.#fsbOptionsApi.isEnabledExtensionAccessControl()) {
        this.debug("-- Access Control is not enabled");

      } else {
        this.debug("-- ACCESS CONTROL IS ENABLED");

        // MABXXX Check to see if Extension has NOT been added and is IMPLICITLY denied vs whether it's been EXPLICITITY denied
        // If it *HAS* been EXPLICITLY denied, do we really want to do anything???
        var   accessGranted = false;
        const extensionProps = await this.#fsbOptionsApi.getExtensionPropsById(sender.id);
        if (! extensionProps) {
          if (await this.#fsbOptionsApi.isEnabledShowGrantExtensionAccessDialog()) {
            accessGranted = await this.showGrantExtensionAccessConfirmDialog(sender.id);
          }
          if (accessGranted) {
            // MABXXX TELL OptionsUI to add the extension to the List!!!
          }
        }

        if (! accessGranted && ! await this.#fsbOptionsApi.isAllowAccess(sender.id)) {
          const accessDeniedMsg = `Access is Denied for: "${sender.id}"`;

          if (logResult || await this.#fsbOptionsApi.isEnabledAccessDeniedLogging()) {
            this.logAlways(`-- ACCESS DENIED FOR MESSAGE SENDER ID: "${sender.id}"`);
            this.#fsbEventLogger.logCommandResult(nowMS, sender.id, message.Command, accessDeniedMsg);
          }

          if (cmdIsAccess) {
            this.debug(`-- command='access' -- ACCESS DENIED FOR MESSAGE SENDER ID: "${sender.id}"`);
            return { "access": "denied" };
          } else {
            return { "error": `Access to ${this.#extName} has not been granted`, "code":  "403" };
          }
        }

        if (! cmdIsAccess && await this.#fsbOptionsApi.isEnabledAccessLogging()) {
          this.logAlways(`-- Access Granted for Message Sender ID: "${sender.id}"`);
        }
      }

      if (cmdIsAccess) {
        if (logResult || await this.#fsbOptionsApi.isEnabledAccessLogging()) {
          const accessGrantedMsg = `Access is Granted: "${sender.id}"`;
          this.logAlways(`-- command='access' - ACCESS GRANTED FOR MESSAGE SENDER ID: "${sender.id}"`);
          this.#fsbEventLogger.logCommandResult(nowMS, sender.id, message.Command, accessGrantedMsg);
        }
        return { "access": "granted" };
      }

      const result = await this.#fsbCommandsApi.processCommand(message.Command, sender.id);

      if (! result) {
        this.error("-- NO COMMAND RESULT");
        return { "error": "Failed to get a Command Result",
                 "code":  "500"
               };
      } else {
        if (logResult) {
          const formattedResult = this.#fsbCommandsApi.formatCommandResult(message.Command, result);
          this.logAlways( "-- RESULT"
                          + `\n- From="${sender.id}"`
                          + `\n- Command="${message.Command.command}"`
//////////////////////////+ `\n- FileName="${message.Command.fileName}"`
                          + `\n- parameters: ${formattedParameters}`
                          + `\n- result: ${formattedResult}`
                        );
          this.#fsbEventLogger.logCommandResult(nowMS, sender.id, message.Command, result);
        }
      }

      return result;

    } catch (error) {
      this.caught(error, "Error Receiving External Message - Code 500");
      return { "error": "Internal Error", "code":  "500" };
    }
  }



  async onExtensionInstalled(extensionInfo) {
    if (extensionInfo.type === 'extension') {
      this.debugAlways(`-- Extension has been Installed: id="${extensionInfo.id}"`);

      try {
        const extensionProps = await this.#fsbOptionsApi.getExtensionPropsById(extensionInfo.id);
        if (! extensionProps) {
          this.debugAlways(`-- Installed Extension is NOT Configured: id="${extensionInfo.id}"`);

        } else {
          this.debugAlways(`-- Installed Extension IS Configured, Un-marking as Uninstalled: id="${extensionInfo.id}"`);
          extensionProps.uninstalled = false;
          delete extensionProps['uninstalledTimeMS'];
          extensionProps['uninstalledType'];
          await this.#fsbOptionsApi.storeExtensionPropsById(extensionProps.id, extensionProps);
        }
      } catch (error) {
        this.caught(error, "Error Processing Extension Installed Notification");
      }
    }
  }

  async onExtensionUninstalled(extensionInfo) {
    if (extensionInfo.type === 'extension') {
      this.debugAlways(`-- Extension has been Uninstalled: id="${extensionInfo.id}"`);

      try {
        const extensionProps = await this.#fsbOptionsApi.getExtensionPropsById(extensionInfo.id);
        if (! extensionProps) {
          this.debugAlways(`-- Uninstalled Extension is NOT Configured: id="${extensionInfo.id}"`);

        } else {
          const autoRemoveNumDays = await this.#fsbOptionsApi.getDeletedExtensionAutoRemoveDays(2);
          this.debugAlways(`-- Uninstalled Extension IS Configured: id="${extensionInfo.id}", autoRemoveNumDays=${autoRemoveNumDays}`);

          if (autoRemoveNumDays == 0) {
            this.debugAlways(`-- Uninstalled Extension IS Configured, Immediately Removing: id="${extensionInfo.id}"`);
            await this.#fsbOptionsApi.removeExtension(extensionInfo.id);

          } else {
            this.debugAlways(`-- Uninstalled Extension IS Configured, Marking as Uninstalled: id="${extensionInfo.id}"`);
            extensionProps.uninstalled       = true;
            extensionProps.uninstalledTimeMS = Date.now();
            extensionProps.uninstalledType   = 'onExtensionUninstalled';
            await this.#fsbOptionsApi.storeExtensionPropsById(extensionProps.id, extensionProps);
          }
        }
      } catch (error) {
        this.caught(error, "Error Processing Extension Uninstalled Notification");
      }
    }
  }




  async showGrantExtensionAccessConfirmDialog(extensionId) {
    this.debug("-- begin");

    var   popupLeft   = 100;
    var   popupTop    = 100;
    var   popupHeight = 250;
    var   popupWidth  = 500;
    const mainWindow  = await messenger.windows.getCurrent();

    if (! mainWindow) {
      this.debug("-- DID NOT GET THE CURRENT (MAIN, mail:3pane) WINDOW!!! ---");

    } else {
      this.debug( "-- Got the Current (Main, mail:3pane) Window:"
                  + `\n- mainWindow.top=${mainWindow.top}`
                  + `\n- mainWindow.left=${mainWindow.left}`
                  + `\n- mainWindow.height=${mainWindow.height}`
                  + `\n- mainWindow.width=${mainWindow.width}`
                );
//////popupTop  = mainWindow.top  + mainWindow. / 2;
      popupTop  = mainWindow.top  + Math.round( (mainWindow.height - popupHeight) / 2 );
//////popupLeft = mainWindow.left + 100;
      popupLeft = mainWindow.left + Math.round( (mainWindow.width  - popupWidth)  / 2 );
      if (mainWindow.height - 200 > popupHeight) popupHeight - mainWindow.Height - 200;   // make it higher, but not shorter
////////if (mainWindow.Width  - 200 > popupWidth)  popupWidth  = mainWindow.Width  - 200;   // make it wider,  but not narrower --- eh, don't need it wider
    }

    const bounds = await this.#fsbOptionsApi.getWindowBounds("confirmDialogWindowBounds"); // MABXXX PERHAPS THIS SHOULD ALWAYS BE CENTERED??????

    if (! bounds) {
      this.debug("-- no previous window bounds");
    } else if (typeof bounds !== 'object') {
      this.error(`-- PREVIOUS WINDOW BOUNDS IS NOT AN OBJECT: typeof='${typeof bounds}' #####`);
    } else {
      this.debug( "-- restoring previous window bounds:"
                  + `\n- bounds.top=${bounds.top}`
                  + `\n- bounds.left=${bounds.left}`
                  + `\n- bounds.width=${bounds.width}`
                  + `\n- bounds.height=${bounds.height}`
                );
//    popupTop    = bounds.top;
      popupTop    = mainWindow ? mainWindow.top  + Math.round( (mainWindow.height - bounds.height) / 2 ) : bounds.top; // CENTER ON THE MAIN WINDOW!!!
//    popupLeft   = bounds.left;
      popupLeft   = mainWindow ? mainWindow.left + Math.round( (mainWindow.width  - bounds.width)  / 2 )  : bounds.left; // CENTER ON THE MAIN WINDOW!!!
      popupWidth  = bounds.width;
      popupHeight = bounds.height;
    }



    // window.id does not exist.  how do we get our own window id???
    var   ourTabId;
    var   ourWindowId;
    const currentTab = await messenger.tabs.getCurrent();
    if (! currentTab) {
      this.debug("-- messenger.tabs.getCurrent() didn't return a Tab");
    } else {
      this.debug(`-- currentTab.id="${currentTab.id}" currentTab.windowId="${currentTab.windowId}"`);
      ourTabId    = currentTab.id;
      ourWindowId = currentTab.windowId;
    }

    const title            = getI18nMsg("fsbConfirmDialogGrantExtensionTitle");
    const message1         = getI18nMsg("fsbConfirmDialogGrantExtensionMessage1");
    const message2         = getI18nMsg("fsbConfirmDialogGrantExtensionMessage2");
    const message3         = getI18nMsg("fsbConfirmDialogGrantExtensionMessage3");
    const button1MsgId     = "fsbConfirmDialog_grantButton.label";
    const button2MsgId     = "fsbConfirmDialog_denyButton.label";
    const button3MsgId     = "fsbConfirmDialog_cancelButton.label";
    const confirmDialogUrl = messenger.runtime.getURL("../dialogs/confirm.html")
                             + "?buttons_3=true"
                             + `&title=${encodeURIComponent(title)}`
                             + `&message1=${encodeURIComponent(message1)}`
                             + `&message2=${encodeURIComponent(extensionId)}`
                             + `&message3=${encodeURIComponent(message2)}`
                             + `&message4=${encodeURIComponent(' ')}` // a blank line
                             + `&message5=${encodeURIComponent(message3)}`
                             + `&button1MsgId=${encodeURIComponent(button1MsgId)}`
                             + `&button2MsgId=${encodeURIComponent(button2MsgId)}`
                             + `&button3MsgId=${encodeURIComponent(button3MsgId)}`;
    // MABXXX DAMN!!! THERE'S NO WAY TO MAKE THIS MODAL!!! MUST USE action "default_popup".  But how to get Extension ID, etc?
    // The window.confirm() function doesn't give a way to specify button text.
    // Which is worse? Ugly ugly UGLY!!!
    this.debug( "-- window bounds:"
                + `\n- popupTop=${popupTop}`
                + `\n- popupLeft=${popupLeft}`
                + `\n- popupWidth=${popupWidth}`
                + `\n- popupHeight=${popupHeight}`
              );
    const confirmDialogWindow = await messenger.windows.create(
      {
        url:                 confirmDialogUrl,
        type:                "popup",
        titlePreface:        getI18nMsg("extensionName") + " - ",
        top:                 popupTop,
        left:                popupLeft,
        height:              popupHeight,
        width:               popupWidth,
        allowScriptsToClose: true,
      }
    );

    this.debug( "-- Grant Extension Access Confirmation Popup Window Created --"
                + `\n-from ourTabId="${ourTabId}"`
                + `\n-from ourWindowId="${ourWindowId}"`
                + `\n-confirmDialogWindow.id="${confirmDialogWindow.id}"`
                + `\n-URL="${confirmDialogUrl}"`
              );

    // Re-focus on the confirmDialog window when our window gets focus
    // MABXXX PERHAPS THIS SHOULD BE DONE INSIDE confirmDialogPrompt() ???
//  const focusListener = async (windowId) => this.windowFocusChanged(windowId, ourTabId, ourWindowId, confirmDialogWindow.id);
    const focusListener = null;
//  messenger.windows.onFocusChanged.addListener(focusListener); // MABXXX async ???

    // ConfirmDialogResponse - expected:
    // - null     - the user closed the popup window        (set by our own windows.onRemoved listener - the defaultResponse sent to confirmDialogPrompt)
    // - CLOSED   - the user closed the popup window        (sent by the ConfirmDialog window's window.onRemoved listener -- NOT REALLY - we use our own onRemoved listener)
    // - BUTTON_1 - the user clicked button 1               (sent by the ConfirmDialog window's button listener)
    // - BUTTON_2 - the user clicked button 2               (sent by the ConfirmDialog window's button listener)
    // - BUTTON_3 - the user clicked button 3               (sent by the ConfirmDialog window's button listener)

    const confirmDialogResponse = await this.confirmDialogPrompt(confirmDialogWindow.id, focusListener, null);
    this.debug(`-- ConfirmDialog confirmDialogResponse="${confirmDialogResponse}"`);

    switch (confirmDialogResponse) {
      case 'BUTTON_1': // 'Yes' button
        await this.grantAccessToExtension(extensionId); // Add NEW Extension and Grant -vs- Grant existing Extension???
        return true;
      case 'BUTTON_2': // 'No' button
        await this.denyAccessToExtension(extensionId); // Add NEW Extension and Deny -vs- Deny existing Extension???
        return false;
      case 'BUTTON_3': // 'Cancel' button
        this.debug("-- ConfirmDialog canceled");
      case 'CLOSED':   // this never happens - see comments in ConfirmDialog regarding conduit failure
      case null:       // closed using the window close button
        return false;
      default:
        this.error(`-- UNKNOWN ConfirmDialog Response - NOT A KNOWN KEYWORD: "${confirmDialogResponse}"`);
    }
  }

  async grantAccessToExtension(extensionId) {
    this.debugAlways(`-- begin - extensionId="${extensionId}"`);

    const granted = await this.#fsbOptionsApi.allowAccess(extensionId);
    this.debugAlways(`-- granted=${granted}`);
    // NOW UPDATE THE UI!!! Did it get added or just altered?

    this.debugAlways("-- end");
  }

  async denyAccessToExtension(extensionId) {
    this.debugAlways(`-- begin -- extensionId="${extensionId}"`);

    const denied = await this.#fsbOptionsApi.disallowAccess(extensionId);
    this.debugAlways(`-- denied=${denied}`);
    // NOW UPDATE THE UI!!! Did it get added or just altered?

    this.debugAlways("-- end");
  }



  async confirmDialogPrompt(confirmDialogWindowId, focusListener, defaultResponse) {
    try {
      await messenger.windows.get(confirmDialogWindowId);
    } catch (error) {
      // Window does not exist, assume closed.
      this.caught(error, "-- PERHAPS WINDOW CLOSED???");
      return defaultResponse;
    }

    return new Promise(resolve => {
      var response = defaultResponse;

      function windowRemovedListener(windowId) {   // MABXXX async ???
        if (windowId == confirmDialogWindowId) {
          messenger.runtime.onMessage.removeListener(messageListener);
          messenger.windows.onRemoved.removeListener(windowRemovedListener);
//////////messenger.windows.onFocusChanged.removeListener(focusListener);

          resolve(response);
        }
      }

      /* The ConfirmDialog sends a message as ConfirmDialogResponse:
       * - CLOSED   - the user closed the popup window   (sent by the ConfirmDialog window's window.onRemoved listener -- NOT REALLY -- using OUR onRemoved instead)
       * - BUTTON_1 - the user clicked button 1          (sent by the ConfirmDialog window's button listener)
       * - BUTTON_2 - the user clicked button 2          (sent by the ConfirmDialog window's button listener)
       * - BUTTON_3 - the user clicked button 3          (sent by the ConfirmDialog window's button listener)
       * Save this ConfirmDialogResponse into response for resolve()
       */
      function messageListener(request, sender, sendResponse) {   // MABXXX async ???
        if (sender.tab && sender.tab.windowId == confirmDialogWindowId && request && request.hasOwnProperty("ConfirmDialogResponse")) {
          response = request.ConfirmDialogResponse;
        }

        return false; // we're not sending any response 
      }

      messenger.runtime.onMessage.addListener(messageListener);         // MABXXX async ???
      messenger.windows.onRemoved.addListener(windowRemovedListener);   // MABXXX async ???
    });
  }








  /* Must be a String with at least one character.
   *
   * ILLEGAL CHARS:
   *
   *   < (less-than)
   *   > (greater-than)
   *   : "colon)
   *   " (double-quote)
   *   / (forward slash(
   *   \ (backward slash(
   *   | (vertical bar)
   *   ? (question mark)
   *   * (asterisk)
   *   x00-x1F (control characters)
   *
   * RESERVED NAMES:
   * - con
   * - prn
   * - aux
   * - nul
   * - com0 - com9
   * - lpt0 - lpt9
   *
   * NO MORE THAN *64* CHARACTERS
   */
  checkValidFileName(fileName) {
    if (typeof fileName !== 'string' || fileName.length < 1 || fileName.length > 64) return false;

    const ILLEGAL_CHARS = /[<>:"/\\|?*\x00-\x1F]/g;
    if (ILLEGAL_CHARS.test(fileName)) return false;

    const RESERVED_NAMES = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;
    if (RESERVED_NAMES.test(fileName)) return false;

    return true;
  }
}



messenger.runtime.onInstalled.addListener( async ( { reason, previousVersion } ) => onInstalled(reason, previousVersion));

async function onInstalled(reason, previousVersion) {
  const extId   = getExtensionId("");
  const extName = getExtensionName("File System Broker");

  if (reason === "update") {
    console.log(`${extId} === EXTENSION ${extName} UPDATED ===`); 
  } else if (reason === "install") {
    console.log(`${extId} === EXTENSION ${extName} INSTALLED ===`); 
  } else { // last option is "browser_update"
    console.log(`${extId} === EXTENSION ${extName} INSTALLED (browser update) ===`); 
  }
}



messenger.runtime.onStartup.addListener( async () => {
  const extId   = getExtensionId("");
  const extName = getExtensionName("File System Broker");
  console.log(`${extId} === EXTENSION ${extName} STARTED === `); 
} );



messenger.runtime.onSuspend.addListener( async () => {
  const extId   = getExtensionId("");
  const extName = getExtensionName("File System Broker");
  console.log(`${extId} === EXTENSION ${extName} SUSPENDED === `); 
} );



// self-executing async "main" function
(async () => {
  const fileSystemBroker = new FileSystemBroker();
  fileSystemBroker.run();
})()
