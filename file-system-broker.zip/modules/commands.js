///import { Logger  } from '../modules/logger.js';
///import { FsbOptions     } from '../modules/options.js';
///import { FsbEventLogger } from '../modules/event_logger.js';
//import { getExtensionId, formatMsToDateTime12HR, formatMsToDateTime24HR } from './utilities.js';
import * as utils from './utilities.js';

export class FileSystemBrokerCommands {
  /* one day I hope to use options to set the logging levels */

  #CLASS_NAME     = this.constructor.name;
  #EXTENSION_ID   = utils.getExtensionId();
  #EXTENSION_NAME = utils.getExtensionName();

  #INFO           = false;
  #LOG            = false;
  #DEBUG          = false;
  #WARN           = false;

  #LOG_INTERNAL_COMMANDS = false;
  #LOG_EXTERNAL_COMMANDS = false;

  #logger;
  #fsbOptionsApi;
  #fsbEventLogger;

  

  static #COMMAND_TYPE = {
    'ACCESS':     'access',
    'READ_META':  'read-meta',
    'ALTER_META': 'alter-meta',
    'READ_DATA':  'read-data',
    'ALTER_DATA': 'alter-data',
    'INFO':       'info',
    'INTERNAL':   'internal',
  }

  static #COMMANDS = {
    'access':                 { 'type': this.#COMMAND_TYPE.ACCESS,     },
    'exists':                 { 'type': this.#COMMAND_TYPE.READ_META,  },
    'isRegularFile':          { 'type': this.#COMMAND_TYPE.READ_META,  },
    'isDirectory':            { 'type': this.#COMMAND_TYPE.READ_META,  },
    'hasFiles':               { 'type': this.#COMMAND_TYPE.READ_META,  },
    'getFileCount':           { 'type': this.#COMMAND_TYPE.READ_META,  },
    'writeFile':              { 'type': this.#COMMAND_TYPE.ALTER_DATA, },
    'replaceFile':            { 'type': this.#COMMAND_TYPE.ALTER_DATA, },
    'appendToFile':           { 'type': this.#COMMAND_TYPE.ALTER_DATA, },
    'writeJSONFile':          { 'type': this.#COMMAND_TYPE.ALTER_DATA, },
    'writeObjectToJSONFile':  { 'type': this.#COMMAND_TYPE.ALTER_DATA, },
    'readFile':               { 'type': this.#COMMAND_TYPE.READ_DATA,  },
    'readJSONFile':           { 'type': this.#COMMAND_TYPE.READ_DATA,  },
    'readObjectFromJSONFile': { 'type': this.#COMMAND_TYPE.READ_DATA,  },
    'makeDirectory':          { 'type': this.#COMMAND_TYPE.ALTER_META, },
    'getFileInfo':            { 'type': this.#COMMAND_TYPE.READ_META,  },
    'renameFile':             { 'type': this.#COMMAND_TYPE.ALTER_META, },
    'deleteFile':             { 'type': this.#COMMAND_TYPE.ALTER_META, },
    'deleteDirectory':        { 'type': this.#COMMAND_TYPE.ALTER_META, },
    'listFiles':              { 'type': this.#COMMAND_TYPE.READ_META,  },
    'listFileInfo':           { 'type': this.#COMMAND_TYPE.READ_META,  },
    'list':                   { 'type': this.#COMMAND_TYPE.READ_META,  },
    'listInfo':               { 'type': this.#COMMAND_TYPE.READ_META,  },
    'getFullPathName':        { 'type': this.#COMMAND_TYPE.INFO,       },
    'isValidFileName':        { 'type': this.#COMMAND_TYPE.INFO,       },
    'isValidDirectoryName':   { 'type': this.#COMMAND_TYPE.INFO,       },
    'getFileSystemPathName':  { 'type': this.#COMMAND_TYPE.INFO,       },
    'stats':                  { 'type': this.#COMMAND_TYPE.READ_META,  },
    'fsbListInfo':            { 'type': this.#COMMAND_TYPE.INTERNAL,   },
    'fsbList':                { 'type': this.#COMMAND_TYPE.INTERNAL,   },
    'fsbStats':               { 'type': this.#COMMAND_TYPE.INTERNAL,   },
    'fsbDeleteDirectory':     { 'type': this.#COMMAND_TYPE.INTERNAL,   },
  };

  static #x = Object.freeze(this.#COMMAND_TYPE);
  static #y = Object.freeze(this.#COMMANDS);



  constructor(logger, optionsApi) { // Logger, FsbOptions
    this.#logger         = logger;
    this.#fsbOptionsApi  = optionsApi;
  }

  setEventLogger(eventLogger) { // FsbEventLogger
    this.#fsbEventLogger = eventLogger;
  }



  info(...info) {
    if (! this.#INFO) return;
    this.#logger.info(this.#CLASS_NAME, ...info);
  }

  infoAlways(...info) {
    this.#logger.infoAlways(this.#CLASS_NAME, ...info);
  }

  log(...info) {
    if (! this.#LOG) return;
    this.#logger.log(this.#CLASS_NAME, ...info);
  }

  logAlways(...info) {
    this.#logger.logAlways(this.#CLASS_NAME, ...info);
  }

  warn(...info) {
    if (! this.#WARN) return;
    this.#logger.warn(this.#CLASS_NAME, ...info);
  }

  warnAlways(...info) {
    this.#logger.warnAlways(this.#CLASS_NAME, ...info);
  }

  debug(...info) {
    if (! this.#DEBUG) return;
    this.#logger.debug(this.#CLASS_NAME, ...info);
  }

  debugAlways(...info) {
    this.#logger.debugAlways(this.#CLASS_NAME, ...info);
  }

  error(...info) {
    // always log errors
    this.#logger.error(this.#CLASS_NAME, ...info);
  }

  caught(e, msg, ...info) {
    // always log exceptions
    this.#logger.error( this.#CLASS_NAME,
                        msg,
                        "\n name:    " + e.name,
                        "\n message: " + e.message,
                        "\n stack:   " + e.stack,
                        ...info
                      );
  }



  static getCommandList() {
    return Object.keys(FileSystemBrokerCommands.#COMMANDS);
  }



  async processExternalCommand(timeMS, Command, extensionId) {
////const logCommand = await this.#fsbOptionsApi.isEnabledExternalMessageLogging();
    const logResult  = await this.#fsbOptionsApi.isEnabledExternalMessageResultLogging();
    
    try {
//    if (logCommand) { // already done by caller
//      this.#fsbEventLogger.logCommand(timeMS, extensionId, Command);
//    }

      const result = await this.#processCommand(timeMS, Command, extensionId, { 'internalCommand': false } );

      if (! result) {
        const description =  "NO COMMAND RESULT FROM #processCommand()";
        this.error(description);
        if (this.#fsbEventLogger) {
          this.#fsbEventLogger.logInternalError(Command.command.command, Command.command, description);
        }
        return { "error": "Failed to get a Command Result",
                 "code":  "500"
               };
      } else {
        if (this.#LOG_EXTERNAL_COMMANDS) {
          const formattedResult = this.formatCommandResult(Command, result);
          this.logAlways( "-- RESULT"
                          + `\n- From="${extensionId}"`
                          + `\n- Command="${Command.command}"`
//////////////////////////+ `\n- FileName="${Command.fileName}"`
                          + `\n- parameters: ${formattedParameters}`
                          + `\n- result: ${formattedResult}`
                        );
        }

        if (logResult) {
          this.#fsbEventLogger.logCommandResult(timeMS, extensionId, Command, result);
        }
      }

      return result;

    } catch (error) {
      this.caught(error, "Error processing External Message - Code 500");
      this.#fsbEventLogger.logCaughtError(Command.command.command, Command.command, error); // Does NOT log Syntax Errors
      return { "error": "Internal Error", "code":  "500" };
    }
  }



  async processInternalCommand(timeMS, Command, extensionId) {
    const logCommand = await this.#fsbOptionsApi.isEnabledInternalMessageLogging();
    const logResult  = await this.#fsbOptionsApi.isEnabledInternalMessageResultLogging();

    var formattedParameters;

    if (this.#LOG_INTERNAL_COMMANDS) {
      formattedParameters = this.formatParameters(Command);

      this.logAlways( "\n--- Processing Internal Command ---",
                      `\n- command="${Command.command}"`,
                      `\n- parameters: ${formattedParameters}`,
                      "\n- parameters object:", Command.parameters,
                    );
    }

    if (logCommand && this.#fsbEventLogger) {
      this.#fsbEventLogger.logCommand(timeMS, "INTERNAL", Command);
    }

    try {
      const result = await this.#processCommand(timeMS, Command, extensionId, { 'internalCommand': true } );

      if (! result) {
        const description =  "NO COMMAND RESULT FROM #processCommand()";
        this.error(description);
        if (this.#fsbEventLogger) {
          this.#fsbEventLogger.logInternalError(Command.command.command, Command.command, description);
        }
        return { "error": "Failed to get a Command Result",
                 "code":  "500",
               };
      } else {
        if (this.#LOG_INTERNAL_COMMANDS) {
          const formattedResult = this.formatCommandResult(Command, result);

          this.log( "\n--- RESULT ---",
                    "\n- INTERNAL",
                    `\n- Command="${Command.command}"`,
                    `\n- result: ${formattedResult}`,
                    `\n- parameters: ${formattedParameters}`,
                    "\n- parameters object:", Command.parameters,
                  );
        }

        if (logResult && this.#fsbEventLogger) {
          this.#fsbEventLogger.logCommandResult(timeMS, "INTERNAL", Command, result);
        }
      }

      return result;

    } catch (error) {
      if (this.#fsbEventLogger) {
        this.#fsbEventLogger.logCaughtError(Command.command.command, Command.command, error); // Does NOT log Syntax Errors
      }

      this.caught(error, "Error Processing Internal Command - Code 500");
      return { "error": "Internal Error", "code":  "500" };
    }
  }





  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // it uses this.#extensionID as the extensionId,
  // and it DOES NOT use messaging.
  //
  // Since extensionId === this.#extensionID, it will delete a file only
  // in the top-most File System directory. ????????????????????????
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async deleteFile(fileName) {
    const nowMS = Date.now();
    this.debug(`~~~~~~~~~~~~~~~~~~~~ fileName="${fileName}"`);

    const Command = {
      'command':  'deleteFile',
      'fileName': fileName,
    };

    const result = await this.processInternalCommand(nowMS, Command, this.#EXTENSION_ID); // <-------------- **NOT** direct call to FileSystemBroker API!!!
  
    return result;
  }



  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // and it DOES NOT use messaging.
  //
  // It does not return invalid/error if the directory for the extension does not exist.
  // If the directory does not exist, it instead returns:
  //    { 'exists': false }
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async extensionStats(extensionId, includeChildInfo) {
    const nowMS = Date.now();

    const parameters = {
      'returnNotExist': true
    };

    if (includeChildInfo !== undefined) {
      parameters['includeChildInfo'] = includeChildInfo;
    }

    const Command = {
      'command':   'stats',
      'parameters': parameters,
    };

    const result = await this.processInternalCommand(nowMS, Command, extensionId); // <---- passed-in extensionId

    return result;
  }



  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // it sets 'recursive' and 'returnNotExist' to true,
  // and it DOES NOT use messaging.
  //
  // It does not return invalid/error if the directory for the extension does not exist.
  // If the directory does not exist, it instead returns:
  //    { "directoryName": extensionId, 'deleted': false, 'exists': false }
  // NOTE: The Experiments API does not do this.
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async deleteExtensionDirectory(extensionId) {
    const nowMS = Date.now();

    const Command = {
      'command':        'deleteDirectory',
      'recursive':      true,
      'returnNotExist': true, // no invalid/error response if it does not exist
    };

    const result = await this.processInternalCommand(nowMS, Command, extensionId); // <---- passed-in extensionId

    return result;
  }



  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // it uses this.#extensionID as the extensionId,
  // and it DOES NOT use messaging.
  //
  // fsbListInfo is an INTERNAL-ONLY COMMAND, so the extensionId MUST BE this.#EXTENSION_ID
  // (see fsbListInfoCommand() below)
  //
  // Since extensionId === this.#extensionID, it will list files only
  // in the top-most File System directory.
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async fsbListInfo(parameters) {
    const nowMS = Date.now();
    const Command = {
      'command': 'fsbListInfo',
    };

    if (parameters !== undefined) {
      Command['parameters'] = parameters;
    }

    const result = await this.processInternalCommand(nowMS, Command, this.#EXTENSION_ID); // <---- this.#EXTENSION_ID

    return result;
  }



  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // it uses this.#extensionID as the extensionId,
  // and it DOES NOT use messaging.
  //
  // fsbList is an INTERNAL-ONLY COMMAND, so the extensionId MUST BE this.#EXTENSION_ID
  // (see fsbListCommand() below)
  //
  // Since extensionId === this.#extensionID, it will list files only
  // in the top-most FileSystemBroker directory.
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async fsbList(parameters) {
    const nowMS = Date.now();
    const Command = {
      'command': 'fsbList',
    };

    if (parameters !== undefined) {
      Command['parameters'] = parameters;
    }

    const result = await this.processInternalCommand(nowMS, Command, this.#EXTENSION_ID); // <---- this.#EXTENSION_ID

    return result;
  }



  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // it uses this.#extensionID as the extensionId,
  // and it DOES NOT use messaging.
  //
  // fsbStats is an INTERNAL-ONLY COMMAND, so the extensionId MUST BE this.#EXTENSION_ID
  // (see fsbStatsCommand() below)
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async fsbStats(parameters) {
    const nowMS = Date.now();
    const Command = {
      'command': 'fsbStats',
    };

    if (parameters !== undefined) {
      Command['parameters'] = parameters;
    }

    const result = await this.processInternalCommand(nowMS, Command, this.#EXTENSION_ID); // <---- this.#EXTENSION_ID

    return result;
  }



  // This method is a shortcut for just calling processInternalCommand(),
  // but it creates the Command object for you,
  // it uses this.#extensionID as the extensionId,
  // and it DOES NOT use messaging.
  //
  // fsbDeleteDirectory is an INTERNAL-ONLY COMMAND, so the extensionId MUST BE this.#EXTENSION_ID
  // (see fsbDeleteDirectory() below)
  //
  // Since extensionId === this.#extensionID, it will delete directories only
  // in the top-most BrokerFileSystem directory.
  //
  // You can use this when you cannot use messaging to run the command
  // like it would do if you were to use the the FileSystemBrokerAPI class
  // (not the same as messenger.FileSystemBrokerAPI.)
  async fsbDeleteDirectory(directoryName, parameters) {
    const nowMS = Date.now();
    const Command = {
      'command': 'fsbDeleteDirectory',
    };

    if (directoryName !== undefined) {
      Command['directoryName'] = directoryName;
    }

    if (parameters !== undefined) {
      Command['parameters'] = parameters;
    }

    const result = await this.processInternalCommand(nowMS, Command, this.#EXTENSION_ID); // <---- this.#EXTENSION_ID

    return result;
  }





  async #processCommand(timeMS, Command, extensionId, parameters) {    
    if (! Command) {
      this.error("processCommand -- No Command parameter");
      return ( { "error": "Invalid Request: No Command.command parameter", "code": "400" } );
    } else if ((typeof Command) !== 'object') {
      this.error(`processCommand -- Command parameter is not an object -  type='${typeof Command}': `, Command);
      return ( { "error": "Invalid Request: Command.command parameter is not an object", "code": "400" } );
    } else if (! Command.hasOwnProperty('command')) {
      this.error("processCommand -- Command has no command parameter: ", Command);
      return ( { "error": "Invalid Request: Command has no command parameter", "code": "400" } );
    } else if ((typeof Command.command) !== 'string') {
      this.error(`processCommand -- Command.command parameter is NOT A STRING - type='${typeof Command.command}': `, Command.command);
      return ( { "error": "Invalid Request: Invalid Command - Command.command parameter is not a String", "code": "400" } );
    }

    if (! extensionId) {
      this.error(`processCommand -- No extensionId - Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command - no extensionId parameter", "code": "400" } );
    } else if ((typeof extensionId) !== 'string') {
      this.error(`processCommand -- extensionId parameter is NOT A STRING - type='${typeof extensionId}' Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command", "code": "400" } );
    } else if (! this.checkValidExtensionId(extensionId)) {
      this.error(`processCommand -- extensionId parameter is NOT VALID: "${extensionId}" - Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command", "code": "400" } );
    }

    const  processingInternalCommand= parameters?.internalCommand;
    if (! parameters) {
      this.error(`"processCommand -- No parameters - Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command - no 'parameters' parameter", "code": "400" } );
    } else if ((typeof parameters) !== 'object') {
      this.error(`"processCommand -- 'parameters' parameter is NOT AN OBJECT - Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command", "code": "400" } );
    } else if (! parameters.hasOwnProperty('internalCommand')) {
      this.error(`"processCommand -- 'parameters' parameter has no property 'internalCommand' - Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command", "code": "400" } );
    } else if ((typeof parameters.internalCommand) !== 'boolean') {
      this.error(`"processCommand -- 'parameters' parameter property 'internalCommand' is not BOOLEAN - Command: "${Command.command}"`);
      return ( { "error": "Invalid Request: Invalid Command", "code": "400" } );
    }



    // It is perfectly valid to have no extProps if Access Control is turned off
    const extProps = await this.#fsbOptionsApi.getExtensionPropsById(extensionId);
    if (! extProps) {
      this.debug(`processCommand -- Extension is NOT CONFIGURED: "${extensionId}"`);
    }

    const extOverQuota = extProps && ! extProps.special && ! extProps.noQuota && (extProps.overStorageQuota || extProps.overFileSizeQuota || extProps.overFileCountQuota);



    if (! Object.hasOwn(FileSystemBrokerCommands.#COMMANDS, Command.command)) {
      return this.#unknownCommand(timeMS, Command, extensionId);
    }

    const commandType = FileSystemBrokerCommands.#COMMANDS[Command.command].type;

    this.debug( `\n\nCommand ......... "${Command.command}"`,
                `\n- commandType ..... ${commandType}`,
                `\n- extId= .......... ${extProps && extProps.id}"`,
                `\n- special ......... ${extProps && extProps.special}`,
                `\n- readOnly ........ ${extProps && extProps.readOnly}`,
                `\n- noQuota ......... ${extProps && extProps.noQuota}`,
                `\n- overQuota ....... ${extOverQuota}`,
                `\n- overStorage ..... ${extProps && extProps.overStorageQuota}`,
                `\n- overFileSize .... ${extProps && extProps.overFileSizeQuota}`,
                `\n- overFileCount ... ${extProps && extProps.overFileCountQuota} `,
              );


    switch (commandType) {
      case FileSystemBrokerCommands.#COMMAND_TYPE.ACCESS:
        break;
      case FileSystemBrokerCommands.#COMMAND_TYPE.READ_DATA:
        break;
      case FileSystemBrokerCommands.#COMMAND_TYPE.READ_META:
        break;
      case FileSystemBrokerCommands.#COMMAND_TYPE.INFO:
        break;
      case FileSystemBrokerCommands.#COMMAND_TYPE.ALTER_META:
        if (extProps && extProps.readOnly) {
          return this.#readOnlyAccess(timeMS, Command, extProps);
        }
        break;
      case FileSystemBrokerCommands.#COMMAND_TYPE.ALTER_DATA:
        if (extProps && extProps.readOnly) {
          return this.#readOnlyAccess(timeMS, Command, extProps);
        }
        if (extOverQuota) {
          return this.#overQuota(timeMS, Command, extProps);
        }
        break;
      case FileSystemBrokerCommands.#COMMAND_TYPE.INTERNAL:
        if (! processingInternalCommand) {
          return this.#internalOnlyCommand(timeMS, Command, extensionId);
        }
        break;
      default:
        this.error(`UNKNOWN COMMAND TYPE: ${commandType}`);
    }



    // MABXXX REPLACE THIS SWITCH WITH A FUNCTION JUMP TABLE???
    switch(Command.command) {
      case "access": // this command must be handled where access control is handled, which is in fsb-background.js for now
      return this.#unknownCommand(timeMS, Command, extensionId);
      case "exists":
        return this.existsCommand(Command, extensionId);
      case "isRegularFile":
        return this.isRegularFileCommand(Command, extensionId);
      case "isDirectory":
        return this.isDirectoryCommand(Command, extensionId);
      case "hasFiles":
        return this.hasFilesCommand(Command, extensionId);
      case "getFileCount":
        return this.getFileCountCommand(Command, extensionId);
      case "writeFile":
        return this.writeFileCommand(Command, extensionId);
      case "replaceFile":
        return this.replaceFileCommand(Command, extensionId);
      case "appendToFile":
        return this.appendToFileCommand(Command, extensionId);
      case "writeJSONFile":
        return this.writeJSONFileCommand(Command, extensionId);
      case "writeObjectToJSONFile":
        return this.writeObjectToJSONFileCommand(Command, extensionId);
      case "readFile":
        return this.readFileCommand(Command, extensionId);
      case "readJSONFile":
        return this.readJSONFileCommand(Command, extensionId);
      case "readObjectFromJSONFile":
        return this.readObjectFromJSONFileCommand(Command, extensionId);
      case "getFileInfo":
        return this.getFileInfoCommand(Command, extensionId);
      case "renameFile":
        return this.renameFileCommand(Command, extensionId);
      case "deleteFile":
        return this.deleteFileCommand(Command, extensionId);
      case "deleteDirectory":
        return this.deleteDirectoryCommand(Command, extensionId);
      case "makeDirectory":
        return this.makeDirectoryCommand(Command, extensionId);
      case "listFiles":
        return this.listFilesCommand(Command, extensionId);
      case "listFileInfo":
        return this.listFileInfoCommand(Command, extensionId);
      case "list":
        return this.listCommand(Command, extensionId);
      case "listInfo":
        return this.listInfoCommand(Command, extensionId);
      case "getFullPathName":
        return this.getFullPathNameCommand(Command, extensionId);
      case "isValidFileName":
        return this.isValidFileNameCommand(Command, extensionId);
      case "isValidDirectoryName":
        return this.isValidDirectoryNameCommand(Command, extensionId);
      case "getFileSystemPathName":
        return this.getFileSystemPathNameCommand(Command, extensionId);
      case "stats":
        return this.statsCommand(Command, extensionId);
      case "fsbListInfo":
        return this.fsbListInfoCommand(Command, extensionId);
      case "fsbList":
        return this.fsbListCommand(Command, extensionId);
      case "fsbStats":
        return this.fsbStatsCommand(Command, extensionId);
      case "fsbDeleteDirectory":
        return this.fsbDeleteDirectoryCommand(Command, extensionId);
    }

    return this.#unknownCommand(timeMS, Command, extensionId);
  }



  async existsCommand(command, extensionId) {
    this.debug(`existsCommand -- command.fileName ="${command.fileName}"`);

    if (command.fileName) { // fileName is optional
      if ((typeof command.fileName) !== 'string') {
        this.debug("existsCommand -- Message 'fileName' parameter type is not 'string'");
        return ( { "invalid": "exists Command: 'fileName' parameter type must be 'string'" } );
      }

      if (! this.checkValidFileName(command.fileName)) {
        this.debug(`existsCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
        return ( { "invalid": `exists Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
      }
    }

    try {
      this.debug(`existsCommand -- checking if file "${command.fileName}" exists for extension "${extensionId}"`);
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
      if (command.fileName) { // fileName is optional
        this.debug(`existsCommand -- fileName="${command.fileName}" exists=${exists}`);
        return ( { "fileName": command.fileName, "exists": exists } );
      }

      this.debug(`existsCommand -- fileName="${extensionId}" exists=${exists}`);
      return ( { "fileName": extensionId, "exists": exists } );

    } catch (error) {
      if (command.fileName) { // fileName is optional
        this.caught(error, `existsCommand -- Caught error while checking if file "${command.fileName}" exists:`);
      } else {
        this.caught(error, `existsCommand -- Caught error while checking if file "${extensionId}" exists:`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing exists Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async isRegularFileCommand(command, extensionId) {
    this.debug(`isRegularFileCommand -- command.fileName ="${command.fileName}"`);

    if (! command.fileName) {
      this.debug("isRegularFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "isRegularFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("isRegularFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "isRegularFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`isRegularFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `isRegularFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    try {
      this.debug(`isRegularFileCommand -- checking if Item "${command.fileName}" exists and is a Regular File for extension "${extensionId}"`);
      const isRegularFile = await messenger.BrokerFileSystem.isRegularFile(extensionId, command.fileName);
      this.debug(`isRegularFileCommand -- fileName="${command.fileName}" isRegularFile=${isRegularFile}`);
      return ( { "fileName": command.fileName, "isRegularFile": isRegularFile } );

    } catch (error) {
      this.caught(error, `isRegularFileCommand -- Caught error while checking if Item "${command.fileName}" exists and is a Regular File:`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing isRegularFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async isDirectoryCommand(command, extensionId) {
    this.debug(`isDirectoryCommand -- command.directoryName ="${command.directoryName}"`);

    if (command.directoryName) { // directoryName is optional
      if ((typeof command.directoryName) !== 'string') {
        this.debug("isDirectoryCommand -- Message 'directoryName' parameter type is not 'string'");
        return ( { "invalid": "isDirectory Command: 'directoryName' parameter type must be 'string'" } );
      }

      if (! this.checkValidDirName(command.directoryName)) {
        this.debug(`isDirectoryCommand -- Message 'directoryName' parameter is invalid: "${command.directoryName}"`);
        return ( { "invalid": `isDirectory Command: 'directoryName' parameter is invalid: "${command.directoryName}"` } );
      }
    }

    try {
      this.debug(`isDirectoryCommand -- checking if Item "${command.directoryName}" exists and is a Directory for extension "${extensionId}"`);
      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId, command.directoryName);
      if (command.directoryName) { // directoryName is optional
        this.debug(`isDirectoryCommand -- directoryName="${command.directoryName}" isDirectory=${isDirectory}`);
        return ( { "directoryName": command.directoryName, "isDirectory": isDirectory } );
      }

      this.debug(`isDirectoryCommand -- directoryName="${extensionId}" isDirectory=${isDirectory}`);
      return ( { "directoryName": extensionId, "isDirectory": isDirectory } );

    } catch (error) {
      if (command.directoryName) { // directoryName is optional
        this.caught(error, `isDirectoryCommand -- Caught error while checking if Item "${command.directoryName}" exists and is a Directory:`);
      } else {
        this.caught(error, `isDirectoryCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing isDirectory Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async hasFilesCommand(command, extensionId) {
    this.debug(`hasFilesCommand -- command.directoryName ="${command.directoryName}"`);

    if (command.directoryName) { // directoryName is optional
      if ((typeof command.directoryName) !== 'string') {
        this.debug("hasFilesCommand -- Message 'directoryName' parameter type is not 'string'");
        return ( { "invalid": "hasFiles Command: 'directoryName' parameter type must be 'string'" } );
      }

      if (! this.checkValidDirName(command.directoryName)) {
        this.debug(`hasFilesCommand -- Message 'directoryName' parameter is invalid: "${command.directoryName}"`);
        return ( { "invalid": `hasFiles Command: 'directoryName' parameter is invalid: "${command.directoryName}"` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.directoryName);
      if (! exists) {
        if (command.directoryName) { // directoryName is optional
          this.debug(`hasFilesCommand -- Directory does not exist: "${command.directoryName}" for extension "${extensionId}"`);
          return ( { "invalid": `hasFiles Command: Directory does not exist: "${command.directoryName}" for extension "${extensionId}"` } );
        } 
        this.debug(`hasFilesCommand -- Directory does not exist: "${extensionId}"`);
        return ( { "invalid": `hasFiles Command: Directory does not exist: "${extensionId}"` } );
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId, command.directoryName);
      if (! isDirectory) {
        if (command.directoryName) { // directoryName is optional
          this.debug(`hasFilesCommand -- File is not a Directory: "${command.directoryName}" for extension "${extensionId}"`);
          return ( { "invalid": `hasFiles Command: File is not a Directory: "${command.directoryName}" for extension "${extensionId}"` } );
        }
        this.debug(`hasFilesCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `hasFiles Command: File is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      if (command.directoryName) { // directoryName is optional
        this.caught(error, `hasFilesCommand -- Caught error while checking if Item "${command.directoryName}" for extension "${extensionId}" exists and is a Directory:`);
      } else {
        this.caught(error, `hasFilesCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing hasFiles Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`hasFilesCommand -- checking if file "${command.directoryName}" exists, is a Directory for extension "${extensionId}", and contains files`);
      const hasFiles = await messenger.BrokerFileSystem.hasFiles(extensionId, command.directoryName);
      if (command.directoryName) { // directoryName is optional
        this.debug(`hasFilesCommand -- directoryName="${command.directoryName}" hasFiles=${hasFiles}`);
        return ( { "directoryName": command.directoryName, "hasFiles": hasFiles } );
      }

      this.debug(`hasFilesCommand -- directoryName="${extensionId}" hasFiles=${hasFiles}`);
      return ( { "directoryName": extensionId, "hasFiles": hasFiles } );

    } catch (error) {
      if (command.directoryName) { // directoryName is optional
        this.caught(error, `hasFilesCommand -- Caught error while checking if file "${command.directoryName}" for extention "${extensionId}" contains files:`);
      } else {
        this.caught(error, `hasFilesCommand -- Caught error while checking if file "${extensionId}" contains files:`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing hasFiles Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async getFileCountCommand(command, extensionId) {
    this.debug(`getFileCountCommand -- command.directoryName ="${command.directoryName}"`);

    if (command.directoryName) { // directoryName is optional
      if ((typeof command.directoryName) !== 'string') {
        this.debug("getFileCountCommand -- Message 'directoryName' parameter type is not 'string'");
        return ( { "invalid": "getFileCount Command: 'directoryName' parameter type must be 'string'" } );
      }

      if (! this.checkValidDirName(command.directoryName)) {
        this.debug(`getFileCountCommand -- Message 'directoryName' parameter is invalid: "${command.directoryName}"`);
        return ( { "invalid": `getFileCount Command: 'directoryName' parameter is invalid: "${command.directoryName}"` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.directoryName);
      if (! exists) {
        if (command.directoryName) { // directoryName is optional
          this.debug(`getFileCountCommand -- Directory does not exist: "${command.directoryName}"`);
          return ( { "invalid": `getFileCount Command: Directory does not exist: "${command.directoryName}"` } );
        } 
        this.debug(`getFileCountCommand -- Directory does not exist: "${extensionId}"`);
        return ( { "invalid": `getFileCount Command: Directory does not exist: "${extensionId}"` } );
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId, command.directoryName);
      if (! isDirectory) {
        if (command.directoryName) { // directoryName is optional
          this.debug(`hasFilesCommand -- File is not a Directory: "${command.directoryName}"`);
          return ( { "invalid": `hasFiles Command: File is not a Directory: "${command.directoryName}"` } );
        }
        this.debug(`hasFilesCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `hasFiles Command: File is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      if (command.directoryName) { // directoryName is optional
        this.caught(error, `getFileCountCommand -- Caught error while checking if Item "${command.directoryName}" for extention "${extensionId}" exists and is a Directory:`);
      } else {
        this.caught(error, `getFileCountCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing getFileCount Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`getFileCount -- checking if file "${command.directoryName}" exists, is a Directory for extension "${extensionId}", and contains files`);
      const fileCount = await messenger.BrokerFileSystem.getFileCount(extensionId, command.directoryName);
      if (command.directoryName) { // directoryName is optional
        this.debug(`getFileCountCommand -- directoryName="${command.directoryName}" fileCount=${fileCount}`);
        return ( { "directoryName": command.directoryName, "fileCount": fileCount } );
      }

      this.debug(`getFileCountCommand -- directoryName="${extensionId}" fileCount=${fileCount}`);
      return ( { "directoryName": extensionId, "fileCount": fileCount } );

    } catch (error) {
      if (command.directoryName) { // directoryName is optional
        this.caught(error, `getFileCountCommand -- Caught error while getting the file count for Directory "${command.directoryName}" for extension "${extensionId}":`);
      } else {
        this.caught(error, `getFileCountCommand -- Caught error while getting the file count for Directory "${extensionId}":`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing getFileCount Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async writeFileCommand(command, extensionId) {
    this.debug(`writeFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("writeFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "writeFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("writeFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "writeFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if ((typeof command.data) === 'undefined' || command.data === null) {
      this.debug("writeFileCommand -- Message has no 'data' parameter");
      return ( { "invalid": "writeFile Command: no 'data' parameter" } );
    } else if ((typeof command.data) !== 'string') {
      this.debug("writeFileCommand -- Message 'data' parameter type is not 'string'");
      return ( { "invalid": "writeFile Command: 'data' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`writeFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `writeFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    if (command.writeMode && ! checkWriteMode(command.writeMode)) {
      this.debug(`writeFileCommand -- Message 'writeMode' parameter is invalid: "${command.writeMode}"`);
      return ( { "invalid": `writeFile Command: 'writeMode' parameter is invalid: "${command.writeMode}"` } );
    }

    const writeMode = command.writeMode ? command.writeMode : 'create';

    try {
      switch (writeMode) {
        case 'append': { // write will fail if file does NOT exist
          const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
          if (! exists) {
            this.debug(`writeFileCommand -- writeMode="${writeMode}" - file does not exist: "${command.fileName}"`);
            return ( { "invalid": `writeFile Command: writeMode="${writeMode}" - file does not exist: "${command.fileName}"` } );
          }
          break;
        }  
        case 'create': { // write will fail if file DOES exist
          const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
          if (exists) {
            this.debug(`writeFileCommand -- writeMode="${writeMode}" - file already exists: "${command.fileName}"`);
            return ( { "invalid": `writeFile Command: writeMode="${writeMode}" - file already exists: "${command.fileName}"` } );
          }
          break;
        }  
      }

      this.debug(`writeFileCommand -- writing data to file "${command.fileName}" with data.length=${command.data.length} for extension "${extensionId}"`);
      const bytesWritten = await messenger.BrokerFileSystem.writeFile(extensionId, command.fileName, command.data, writeMode);
      this.debug(`writeFileCommand -- fileName="${command.fileName}" bytesWritten=${bytesWritten}`);
      return ( { "fileName": command.fileName, "bytesWritten": bytesWritten } );

    } catch (error) {
      this.caught(error, `writeFileCommand -- Caught error while writing file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing writeFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async replaceFileCommand(command, extensionId) {
    this.debug(`replaceFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("replaceFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "replaceFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("replaceFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "replaceFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if ((typeof command.data) === 'undefined' || command.data === null) {
      this.debug("replaceFileCommand -- Message has no 'data' parameter");
      return ( { "invalid": "replaceFile Command: no 'data' parameter" } );
    } else if ((typeof command.data) !== 'string') {
      this.debug("replaceFileCommand -- Message 'data' parameter type is not 'string'");
      return ( { "invalid": "replaceFile Command: 'data' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`replaceFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `replaceFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    try {
      this.debug(`replaceFileCommand -- writing data to file "${command.fileName}" with data.length=${command.data.length} for extension "${extensionId}"`);
      const bytesWritten = await messenger.BrokerFileSystem.replaceFile(extensionId, command.fileName, command.data);
      this.debug(`replaceFileCommand -- fileName="${command.fileName}" bytesWritten=${bytesWritten}`);
      return ( { "fileName": command.fileName, "bytesWritten": bytesWritten } );

    } catch (error) {
      this.caught(error, `replaceFileCommand -- Caught error while writing file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing replaceFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async appendToFileCommand(command, extensionId) {
    this.debug(`appendToFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("appendToFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "appendToFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("appendToFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "appendToFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if ((typeof command.data) === 'undefined' || command.data === null) {
      this.debug("appendToFileCommand -- Message has no 'data' parameter");
      return ( { "invalid": "appendToFile Command: no 'data' parameter" } );
    } else if ((typeof command.data) !== 'string') {
      this.debug("appendToFileCommand -- Message 'data' parameter type is not 'string'");
      return ( { "invalid": "appendToFile Command: 'data' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`appendToFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `appendToFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    try {
      this.debug(`appendToFileCommand -- writing data to file "${command.fileName}" with data.length=${command.data.length} for extension "${extensionId}"`);
      const bytesWritten = await messenger.BrokerFileSystem.appendToFile(extensionId, command.fileName, command.data);
      this.debug(`appendToFileCommand -- fileName="${command.fileName}" bytesWritten=${bytesWritten}`);
      return ( { "fileName": command.fileName, "bytesWritten": bytesWritten } );

    } catch (error) {
      this.caught(error, `appendToFileCommand -- Caught error while writing file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing appendToFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async writeJSONFileCommand(command, extensionId) {
    this.debug(`writeJSONFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("writeJSONFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "writeJSONFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("writeJSONFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "writeJSONFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if ((typeof command.data) === 'undefined' || command.data === null) {
      this.debug("writeJSONFileCommand -- Message has no 'data' parameter");
      return ( { "invalid": "writeJSONFile Command: no 'data' parameter" } );
    } else if ((typeof command.data) !== 'string') {
      this.debug("writeJSONFileCommand -- Message 'data' parameter type is not 'string'");
      return ( { "invalid": "writeJSONFile Command: 'data' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`writeJSONFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `writeJSONFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    if (command.writeMode && ! checkWriteMode(command.writeMode)) {
      this.debug(`writeJSONFileCommand -- Message 'writeMode' parameter is invalid: "${command.writeMode}"`);
      return ( { "invalid": `writeJSONFile Command: 'writeMode' parameter is invalid: "${command.writeMode}"` } );
    }

    const writeMode = command.writeMode ? command.writeMode : 'overwrite';

    try {
      switch (writeMode) {
        // writeJSONFile DOES NOT SUPPORT APPEND MODES!!!
        case 'append':
        case 'appendOrCreate':
          this.debug(`writeJSONFileCommand -- Message 'writeMode' parameter is not supported for JSON: "${command.writeMode}"`);
          return ( { "invalid": `writeJSONFile Command: 'writeMode' parameter is not supported for JSON: "${command.writeMode}"` } );
        case 'create': { // write will fail if file DOES exist
          const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
          if (exists) {
            this.debug(`writeJSONFileCommand -- writeMode="${writeMode}" - file already exists: "${command.fileName}"`);
            return ( { "invalid": `writeJSONFile Command: writeMode="${writeMode}" - file already exists: "${command.fileName}"` } );
          }
          break;
        }
      }

      this.debug(`writeJSONFileCommand -- writing data to file "${command.fileName}" with data.length=${command.data.length} for extension ${extensionId}"`);
      const bytesWritten = await messenger.BrokerFileSystem.writeJSONFile(extensionId, command.fileName, command.data, writeMode);
      this.debug(`writeJSONFileCommand -- fileName="${command.fileName}" bytesWritten=${bytesWritten}`);
      return ( { "fileName": command.fileName, "bytesWritten": bytesWritten } );

    } catch (error) {
      this.caught(error, `writeJSONFileCommand -- Caught error while writing file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing writeJSONFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async writeObjectToJSONFileCommand(command, extensionId) {
    this.debug(`writeObjectToJSONFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("writeObjectToJSONFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "writeObjectToJSONFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("writeObjectToJSONFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "writeObjectToJSONFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if ((typeof command.object) === 'undefined' || command.object === null) {
      this.debug("writeObjectToJSONFileCommand -- Message has no 'object' parameter");
      return ( { "invalid": "writeObjectToJSONFile Command: no 'object' parameter" } );
    } else if ((typeof command.object) !== 'object') {
      this.debug("writeObjectToJSONFileCommand -- Message 'object' parameter type is not 'object'");
      return ( { "invalid": "writeObjectToJSONFile Command: 'object' parameter type must be 'object'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`writeObjectToJSONFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `writeObjectToJSONFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    if (command.writeMode && ! checkWriteMode(command.writeMode)) {
      this.debug(`writeObjectToJSONFileCommand -- Message 'writeMode' parameter is invalid: "${command.writeMode}"`);
      return ( { "invalid": `writeObjectToJSONFile Command: 'writeMode' parameter is invalid: "${command.writeMode}"` } );
    }

    const writeMode = command.writeMode ? command.writeMode : 'overwrite';

    try {
      switch (writeMode) {
        // writeJSONFile DOES NOT SUPPORT APPEND MODES!!!
        case 'append':
        case 'appendOrCreate':
          this.debug(`writeObjectToJSONFileCommand -- Message 'writeMode' parameter is not supported for JSON: "${command.writeMode}"`);
          return ( { "invalid": `writeObjectToJSONFile Command: 'writeMode' parameter is not supported for JSON: "${command.writeMode}"` } );
        case 'create': { // write will fail if file DOES exist
          const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
          if (exists) {
            this.debug(`writeObjectToJSONFileCommand -- writeMode="${writeMode}" - file already exists: "${command.fileName}"`);
            return ( { "invalid": `writeObjectToJSONFile Command: writeMode="${writeMode}" - file already exists: "${command.fileName}"` } );
          }
          break;
        }
      }

      const obj = command.object;
      this.debug(`writeObjectToJSONFileCommand -- writing Object to file "${command.fileName}" with object.length=${Object.keys(obj).length} for extension ${extensionId}"`);
      const bytesWritten = await messenger.BrokerFileSystem.writeObjectToJSONFile(extensionId, command.fileName, obj, writeMode);
      this.debug(`writeObjectToJSONFileCommand -- fileName="${command.fileName}" bytesWritten=${bytesWritten}`);
      return ( { "fileName": command.fileName, "bytesWritten": bytesWritten } );

    } catch (error) {
      this.caught(error, `writeObjectToJSONFileCommand -- Caught error while writing file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing writeObjectToJSONFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async readFileCommand(command, extensionId) {
    this.debug(`readFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("readFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "readFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("readFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "readFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`readFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `readFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
      if (! exists) {
        this.debug(`readFileCommand -- File does not exist: "${command.fileName}"`);
        return ( { "invalid": `readFile Command: File does not exist: "${command.fileName}"` } );
      }

      const isRegularFile = await messenger.BrokerFileSystem.isRegularFile(extensionId, command.fileName);
      if (! exists) {
        this.debug(`readFileCommand -- File is not a Regular File: "${command.fileName}"`);
        return ( { "invalid": `readFile Command: File is not a Regular File: "${command.fileName}"` } );
      }

      this.debug(`readFileCommand -- reading from file "${command.fileName}" from the directory for extension "${extensionId}"`);
      const data = await messenger.BrokerFileSystem.readFile(extensionId, command.fileName);
      this.debug(`readFileCommand -- fileName="${ command.fileName}" data.length=${data.length}`);
      return ( { "fileName": command.fileName, "data": data } );

    } catch (error) {
      this.caught(error, `readFileCommand -- Caught error while reading file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing readFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async readJSONFileCommand(command, extensionId) {
    this.debug(`readJSONFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("readJSONFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "readJSONFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("readJSONFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "readJSONFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`readJSONFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `readJSONFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
      if (! exists) {
        this.debug(`readJSONFileCommand -- File does not exist: "${command.fileName}"`);
        return ( { "invalid": `readJSONFile Command: File does not exist: "${command.fileName}"` } );
      }

      const isRegularFile = await messenger.BrokerFileSystem.isRegularFile(extensionId, command.fileName);
      if (! exists) {
        this.debug(`readJSONFileCommand -- File is not a Regular File: "${command.fileName}"`);
        return ( { "invalid": `readJSONFile Command: File is not a Regular File: "${command.fileName}"` } );
      }

      this.debug(`readJSONFileCommand -- reading from file "${command.fileName}" from the directory for extension "${extensionId}"`);
      const data = await messenger.BrokerFileSystem.readJSONFile(extensionId, command.fileName);
      this.debug(`readJSONFileCommand -- fileName="${ command.fileName}" data.length=${data.length}`);

      return ( { "fileName": command.fileName, "data": data } );

    } catch (error) {
      this.caught(error, `readJSONFileCommand -- Caught error while reading file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing readJSONFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async readObjectFromJSONFileCommand(command, extensionId) {
    this.debug(`readObjectFromJSONFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName ="${command.fileName }"`);

    if (! command.fileName) {
      this.debug("readObjectFromJSONFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "readObjectFromJSONFile Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("readObjectFromJSONFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "readObjectFromJSONFile Command: 'fileName' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`readObjectFromJSONFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `readObjectFromJSONFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
      if (! exists) {
        this.debug(`readObjectFromJSONFileCommand -- File does not exist: "${command.fileName}"`);
        return ( { "invalid": `readObjectFromJSONFile Command: File does not exist: "${command.fileName}"` } );
      }

      const isRegularFile = await messenger.BrokerFileSystem.isRegularFile(extensionId, command.fileName);
      if (! exists) {
        this.debug(`readObjectFromJSONFileCommand -- File is not a Regular File: "${command.fileName}"`);
        return ( { "invalid": `readObjectFromJSONFile Command: File is not a Regular File: "${command.fileName}"` } );
      }

      this.debug(`readObjectFromJSONFileCommand -- reading from file "${command.fileName}" from the directory for extension "${extensionId}"`);
      const obj = await messenger.BrokerFileSystem.readObjectFromJSONFile(extensionId, command.fileName);
      this.debug(`readObjectFromJSONFileCommand -- filename="${command.fileName}" (typeof obj)='${(typeof obj)}'`);
      return ( { "fileName": command.fileName, "object": obj } );

    } catch (error) {
      this.caught(error, `readObjectFromJSONFileCommand -- Caught error while reading file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing readObjectFromJSONFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async getFileInfoCommand(command, extensionId) {
    this.debug(`getFileInfoCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName="${command.fileName}"`);

    if (command.fileName) { // fileName is optional
      if ((typeof command.fileName) !== 'string') {
        this.debug("getFileInfoCommand -- Message 'fileName' parameter type is not 'string'");
        return ( { "invalid": "getFileInfo Command: 'fileName' parameter type must be 'string'" } );
      }

      if (! this.checkValidFileName(command.fileName)) {
        this.debug(`getFileInfoCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
        return ( { "invalid": `getFileInfo Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
      if (! exists) {
        if (command.fileName) { // fileName is optional
          this.debug(`getFileInfoCommand -- File does not exist: "${command.fileName}"`);
          return ( { "invalid": `getFileInfo Command: File does not exist: "${command.fileName}"` } );
        }

        this.debug(`getFileInfoCommand -- File does not exist: "${extensionId}"`);
        return ( { "invalid": `getFileInfo Command: File does not exist: "${extensionId}"` } );
      }

      this.debug(`getFileInfoCommand -- getting File Info for file "${command.fileName}" for extension "${extensionId}"`);
      const fileInfo = await messenger.BrokerFileSystem.getFileInfo(extensionId, command.fileName); // returns null if file does not exist

      if (! fileInfo) {
        if (command.fileName) { // fileName is optional
          this.debug(`getFileInfoCommand -- File does not exist - No FileInfo for file "${command.fileName}" for extension "${extensionId}"`);
          // MABXXX Hmmm... should we return this, just return undefined/null, or something else? We *did* test for existence above...
          return ( { "error": `File does not exist: "${command.fileName}"` } ); // MABXXX actually, unable to get FileInfo, no?
        }

        this.debug(`getFileInfoCommand -- File does not exist - No FileInfo for file "${extensionId}"`);
        // MABXXX Hmmm... should we return this, just return undefined/null, or something else? We *did* test for existence above...
        return ( { "error": `File does not exist: "${extensionId}"` } ); // MABXXX actually, unable to get FileInfo, no?
      }

      if (command.fileName) { // fileName is optional
        return ( { "fileName": command.fileName, "fileInfo": fileInfo } );
      }

      return ( { "fileName": extensionId, "fileInfo": fileInfo } );

    } catch (error) {
      if (command.fileName) { // fileName is optional
        this.caught(error, `getFileInfoCommand -- Caught error while getting File Info for file "${command.fileName}":`);
      } else {
        this.caught(error, `getFileInfoCommand -- Caught error while getting File Info for file "${extensionId}":`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing getFileInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return; // undefined .. maybe "invalid" instead???
  }



  async renameFileCommand(command, extensionId) {
    this.debug(`renameFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fromFileName="${command.fromFileName}" command.toFileName="${command.toFileName}" command.overwrite=${command.overwrite}`);

    if ((typeof command.fromFileName) !== 'string') {
      this.debug("renameFileCommand -- Message 'fromFileName' parameter type is not 'string'");
      return ( { "invalid": "renameFile Command: 'fromFileName' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.fromFileName)) {
      this.debug(`renameFileCommand -- Message 'fromFileName' parameter is invalid: "${command.fromFileName}"`);
      return ( { "invalid": `renameFile Command: 'fromFileName' parameter is invalid: "${command.fromFileName}"` } );
    }

    if ((typeof command.toFileName) !== 'string') {
      this.debug("renameFileCommand -- Message 'toFileName' parameter type is not 'string'");
      return ( { "invalid": "renameFile Command: 'toFileName' parameter type must be 'string'" } );
    }

    if (! this.checkValidFileName(command.toFileName)) {
      this.debug(`renameFileCommand -- Message 'toFileName' parameter is invalid: "${command.toFileName}"`);
      return ( { "invalid": `renameFile Command: 'toFileName' parameter is invalid: "${command.toFileName}"` } );
    }

    if (command.overwrite !== null && (typeof command.overwrite) !== 'undefined' && (typeof command.overwrite) !== 'boolean' ) { // optional
      this.debug("renameFileCommand -- Message 'overwrite' parameter type is not 'boolean'");
      return ( { "invalid": "renameFile Command: 'overwrite' parameter type must be 'boolean'" } );
    }

    try {
      this.debug(`renameFileCommand -- Checking if From file exists: "${command.fromFileName}" for extension "${extensionId}"`);
      const fromFileExists = await messenger.BrokerFileSystem.exists(extensionId, command.fromFileName);
      if (! fromFileExists) {
        this.debug(`renameFileCommand -- From File does not exist: "${command.fromFileName}"`);
        return ( { "invalid": `renameFile Command: From File does not exist: "${command.fromFileName}"` } );
      }

      this.debug(`renameFileCommand -- Checking if From file is a Regular File: "${command.fromFileName}" for extension "${extensionId}"`);
      const isRegularFile = await messenger.BrokerFileSystem.isRegularFile(extensionId, command.fromFileName);
      if (! isRegularFile) {
        this.debug(`renameFileCommand -- From File is not a Regular File: "${command.fromFileName}" for extension "${extensionId}"`);
        return ( { "invalid": `From File is not a Regular File: "${command.fromFileName}"` } );
      }
    } catch (error) {
      this.caught(error, `renameFileCommand -- Caught error getting info for From file "${command.fromFileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing renameFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    var toFileOverwrite = false;
    if (command.overwrite !== null && (typeof command.overwrite) !== 'undefined') {
      toFileOverwrite = command.overwrite;
    }
    this.debug(`renameFileCommand -- (typeof command.overwrite)='${(typeof command.overwrite)}' command.overwrite=${command.overwrite} toFileOverwrite=${toFileOverwrite}`);

    if (! toFileOverwrite) {
      try {
        this.debug(`renameFileCommand -- Checking if To file exists: "${command.toFileName}" for extension "${extensionId}"`);
        const toFileExists = await messenger.BrokerFileSystem.exists(extensionId, command.toFileName);
        if (toFileExists) {
          this.debug(`renameFileCommand -- Rename to File already exists: "${command.toFileName}"`);
          return ( { "invalid": `renameFile Command: Rename to File already exists: "${command.toFileName}"` } );
        }
      } catch (error) {
        this.caught(error, `renameFileCommand -- Caught error getting info for To file "${command.toFileName}":`);
        this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
        return ( { "error": `Error Processing renameFile Command: ${error.name} - ${error.message}`, "code": "500" } );
      }
    }

    try {
      const renamed = await messenger.BrokerFileSystem.renameFile(extensionId, command.fromFileName, command.toFileName, command.overwrite);
      return ( { "fromFileName": command.fromFileName, "toFileName": command.toFileName, 'renamed': renamed } );
    } catch (error) {
      this.caught(error, `renameFileCommand -- Caught error renaming file "${command.fromFileName}" to "${command.toFileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing renameFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return; // undefined .. maybe "invalid" instead???
  }



  async deleteFileCommand(command, extensionId) {
    this.debug(`deleteFileCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName="${command.fileName}"`);

    if (! command.fileName) {
      this.debug("deleteFileCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "deleteFile Command: no 'fileName' parameter" } );
    }
    if ((typeof command.fileName) !== 'string') {
      this.debug("deleteFileCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "deleteFile Command: 'fileName' parameter type must be 'string'" } );
    }
    if (! this.checkValidFileName(command.fileName)) {
      this.debug(`deleteFileCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
      return ( { "invalid": `deleteFile Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
    }

    var returnNotExist = false;
    if ((typeof command.returnNotExist) === 'boolean') {
      returnNotExist = command.returnNotExist;
    } else if ((typeof command.returnNotExist) !== 'undefined') {
      this.debug(`deleteFileCommand -- Message 'returnNotExist' parameter type is not 'boolean'. It is '${typeof command.returnNotExist}'`);
      return ( { "invalid": `deleteFile Command: 'returnNotExist' parameter must be type 'boolean'. It is '${typeof command.returnNotExist}'` } );
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.fileName);
      if (! exists) {
        this.debug(`deleteFileCommand -- File does not exist: "${command.fileName}"`);
        if (returnNotExist) {
          return ( { "fileName": command.fileName, "deleted": false, "exists": false } );
        } else {
          return ( { "invalid": `deleteFile Command: File does not exist: "${command.fileName}"` } );
        }
      }

      const isRegularFile = await messenger.BrokerFileSystem.isRegularFile(extensionId, command.fileName);
      if (! isRegularFile) {
        this.debug(`deleteFileCommand -- File is not a Regular File: "${command.fileName}"`);
        return ( { "invalid": `deleteFile Command: File is not a Regular File: "${command.fileName}"` } );
      }

      this.debug(`deleteFileCommand -- deleting file "${command.fileName}" for extension "${extensionId}"`);
      const deleted = await messenger.BrokerFileSystem.deleteFile(extensionId, command.fileName);
      this.debug(`deleteFileCommand -- deleted=${deleted}`);
      return ( { "fileName": command.fileName, "deleted": deleted } );

    } catch (error) {
      this.caught(error, `deleteFileCommand -- Caught error while deleting file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing deleteFile Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async deleteDirectoryCommand(command, extensionId) {
    this.debug(`deleteDirectoryCommand ~~~~~~~~~~~~~~~~~~~~ command.directoryName="${command.directoryName}" recursive=${command.recursive}`);

    if (command.directoryName) { // directoryName is optional
      if ((typeof command.directoryName) !== 'string') {
        this.debug("deleteDirectory -- Message 'directoryName' parameter type is not 'string'");
        return ( { "invalid": "deleteDirectory Command: 'directoryName' parameter type must be 'string'" } );
      }

      if (! this.checkValidDirName(command.directoryName)) {
        this.debug(`deleteDirectoryCommand -- Message 'directoryName' parameter is invalid: "${command.directoryName}"`);
        return ( { "invalid": `deleteDirectory Command: 'directoryName' parameter is invalid: "${command.directoryName}"` } );
      }
    }

    var recursive = false;
    if ((typeof command.recursive) === 'boolean') {
      recursive = command.recursive;
    } else if (command.recursive !== null && (typeof command.recursive) !== 'undefined') {
      this.debug(`deleteDirectoryCommand -- Message 'recursive' parameter type is not 'boolean'. It is '${typeof command.recursive}'`);
      return ( { "invalid": `deleteDirectory Command: 'recursive' parameter must be type 'boolean'. It is '${typeof command.recursive}'` } );
    }

    // NOTE: The Experiments API does not do this:
    var returnNotExist = false;
    if ((typeof command.returnNotExist) === 'boolean') {
      returnNotExist = command.returnNotExist;
    } else if ((typeof command.returnNotExist) !== 'undefined') {
      this.debug(`deleteDirectoryCommand -- Message 'returnNotExist' parameter type is not 'boolean'. It is '${typeof command.returnNotExist}'`);
      return ( { "invalid": `deleteDirectory Command: 'returnNotExist' parameter must be type 'boolean'. It is '${typeof command.returnNotExist}'` } );
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId, command.directoryName);
      if (! exists) {
        if (returnNotExist) {
          if (command.directoryName) { // directoryName is optional
            this.debug(`deleteDirectoryCommand -- Directory does not exist: "${command.directoryName}"`);
            // NOTE: The Experiments API does not do this:
            return ( { "directoryName": command.directoryName, "deleted": false, "exists": false } );
          }

          this.debug(`deleteDirectoryCommand -- Directory does not exist: "${extensionId}"`);
          // NOTE: The Experiments API does not do this:
          return ( { "directoryName": extensionId, "deleted": false, "exists": false } );

        } else {
          if (command.directoryName) { // directoryName is optional
            this.debug(`deleteDirectoryCommand -- Directory does not exist: "${command.directoryName}"`);
            return ( { "invalid": `deleteDirectory Command: Directory does not exist: "${command.directoryName}"` } );
          }

          this.debug(`deleteDirectoryCommand -- Directory does not exist: "${extensionId}"`);
          return ( { "invalid": `deleteDirectory Command: Directory does not exist: "${extensionId}"` } );
        }
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId, command.directoryName);
      if (! isDirectory) {
        if (command.directoryName) { // directoryName is optional
          this.debug(`deleteDirectoryCommand -- File is not a Directory: "${command.directoryName}"`);
          return ( { "invalid": `deleteDirectory Command: File is not a Directory: "${command.directoryName}"` } );
        }

        this.debug(`deleteDirectoryCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `deleteDirectory Command: File is not a Directory: "${extensionId}"` } );
      }

      if (! recursive) {
        const hasFiles = await messenger.BrokerFileSystem.hasFiles(extensionId, command.directoryName);
        if (hasFiles) {
          if (command.directoryName) { // directoryName is optional
            this.debug(`deleteDirectoryCommand -- Directory has files and recursive=false: "${command.directoryName}"`);
            return ( { "invalid": `deleteDirectory Command: Directory has files and recursive=false: "${command.directoryName}"` } );
          }

          this.debug(`deleteDirectoryCommand -- Directory has files and recursive=false: "${extensionId}"`);
          return ( { "invalid": `deleteDirectory Command: Directory has files and recursive=false: "${extensionId}"` } );
        }
      }

      this.debug(`deleteDirectoryCommand -- deleting directory "${command.directoryName}" for extension "${extensionId}"`);
      const deleted = await messenger.BrokerFileSystem.deleteDirectory(extensionId, command.directoryName, recursive);
      if (command.directoryName) { // directoryName is optional
        this.debug(`deleteDirectoryCommand -- directoryName="${command.directoryName}" deleted=${deleted}`);
        return ( { "directoryName": command.directoryName, "recursive": recursive, "deleted": deleted } );
      }

      this.debug(`deleteDirectoryCommand -- directoryName="${extensionId}" deleted=${deleted}`);
      return ( { "directoryName": extensionId, "recursive": recursive, "deleted": deleted } );

    } catch (error) {
      if (command.directoryName) { // directoryName is optional
        this.caught(error, `deleteDirectoryCommand -- Caught error while deleting directory "${command.directoryName}":`);
      } else {
        this.caught(error, `deleteDirectoryCommand -- Caught error while deleting directory "${extensionId}":`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing deleteDirectory Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async makeDirectoryCommand(command, extensionId) {
    this.debug("makeDirectoryCommand --");

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId);
      if (exists) {
        this.debug(`makeDirectoryCommand -- File or Directory already exists: "${extensionId}"`);
        return ( { "invalid": `makeDirectory Command: File or Directory already exists: "${extensionId}"` } );
      }
    } catch (error) {
      this.caught(error, `makeDirectoryCommand -- Caught error while checking for existing file or directory "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing makeDirectory Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      const created = await messenger.BrokerFileSystem.makeDirectory(extensionId);
      this.debug(`makeDirectoryCommand -- directoryName="${extensionId}" created=${created}`); // notice that directoryName is (*ONLY*) the extensionId - NO SUB-DIRS
      return ( { "directoryName": extensionId, "created": created } );                         // notice that directoryName is (*ONLY*) the extensionId - NO SUB-DIRS

    } catch (error) {
      this.caught(error, `makeDirectoryCommand -- Caught error while creating directory "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing makeDirectory Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async listFilesCommand(command, extensionId) {
    this.debug(`listFilesCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ matchGLOB="${command.matchGLOB}"`);

    if (command.matchGLOB) {
      if ((typeof command.matchGLOB) !== 'string') {
        this.debug(`listFilesCommand -- Message 'matchGLOB' parameter type is not 'string', type='${(typeof command.matchGLOB)}'`);
        return ( { "invalid": `listFiles Command: 'matchGLOB' parameter type must be 'string', type='${(typeof command.matchGLOB)}'` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId);
      if (! exists) {
        this.debug(`hasFilesCommand -- Directory does not exist: "${extensionId}"`);
        return ( { "invalid": `listFiles Command: Directory does not exist: "${extensionId}"` } );
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
      if (! isDirectory) {
        this.debug(`hasFilesCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `listFiles Command: File is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      this.caught(error, `hasFilesCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing listFiles Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`listFilesCommand -- getting list of files for extension "${extensionId}"`);
      const fileNames = await messenger.BrokerFileSystem.listFiles(extensionId, command.matchGLOB);
      this.debug(`listFilesCommand -- fileNames.length=${fileNames.length}`);
      return ( { "fileNames": fileNames, "length": fileNames.length } );

    } catch (error) {
      this.caught(error, `listFilesCommand -- Caught error while listing files for extension "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing listFiles Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  async listFileInfoCommand(command, extensionId) {
    this.debug(`listFileInfoCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ matchGLOB="${command.matchGLOB}"`);

    if (command.matchGLOB) {
      if ((typeof command.matchGLOB) !== 'string') {
        this.debug(`listFileInfoCommand -- Message 'matchGLOB' parameter type is not 'string', type='${(typeof command.matchGLOB)}'`);
        return ( { "invalid": `listFileInfo Command: 'matchGLOB' parameter type must be 'string', type='${(typeof command.matchGLOB)}'` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId);
      if (! exists) {
        this.debug(`hasFilesCommand -- Directory does not exist: "${extensionId}"`);
        return ( { "invalid": `listFileInfo Command: Directory does not exist: "${extensionId}"` } );
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
      if (! isDirectory) {
        this.debug(`hasFilesCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `listFileInfo Command: File is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      this.caught(error, `hasFilesCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing listFileInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`listFileInfoCommand -- getting list of files for extension "${extensionId}"`);
      const fileInfo = await messenger.BrokerFileSystem.listFileInfo(extensionId, command.matchGLOB);
      this.debug(`listFileInfoCommand -- fileInfo.length=${fileInfo.length}`);
      return ( { "fileInfo": fileInfo, "length": fileInfo.length } );

    } catch (error) {
      this.caught(error, `listFileInfoCommand -- Caught error while listing files for extension "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing listFileInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  async listCommand(command, extensionId) {
    this.debug(`list ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ matchGLOB="${command.matchGLOB}"`);

    if (command.matchGLOB) {
      if ((typeof command.matchGLOB) !== 'string') {
        this.debug(`listCommand -- Message 'matchGLOB' parameter type is not 'string', type='${(typeof command.matchGLOB)}'`);
        return ( { "invalid": `list Command: 'matchGLOB' parameter type must be 'string', type='${(typeof command.matchGLOB)}'` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId);
      if (! exists) {
        this.debug(`hasFilesCommand -- Directory does not exist: "${extensionId}"`);
        return ( { "invalid": `list Command: Directory does not exist: "${extensionId}"` } );
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
      if (! isDirectory) {
        this.debug(`hasFilesCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `list Command: File is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      this.caught(error, `hasFilesCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing list Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`list -- getting list of items for extension "${extensionId}"`);
      const fileNames = await messenger.BrokerFileSystem.list(extensionId, command.matchGLOB);
      this.debug(`list -- fileNames.length=${fileNames.length}`);
      return ( { "fileNames": fileNames, "length": fileNames.length } );

    } catch (error) {
      this.caught(error, `list -- Caught error while listing items for extension "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing list Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  async listInfoCommand(command, extensionId) {
    this.debug(`listInfo ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ matchGLOB="${command.matchGLOB}"`);

    if (command.matchGLOB) {
      if ((typeof command.matchGLOB) !== 'string') {
        this.debug(`listInfoCommand -- Message 'matchGLOB' parameter type is not 'string', type='${(typeof command.matchGLOB)}'`);
        return ( { "invalid": `listInfo Command: 'matchGLOB' parameter type must be 'string', type='${(typeof command.matchGLOB)}'` } );
      }
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId);
      if (! exists) {
        this.debug(`hasFilesCommand -- Directory does not exist: "${extensionId}"`);
        return ( { "invalid": `listInfo Command: Directory does not exist: "${extensionId}"` } );
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
      if (! isDirectory) {
        this.debug(`hasFilesCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `listInfo Command: File is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      this.caught(error, `hasFilesCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing listInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`listInfo -- getting listInfo of items for extension "${extensionId}"`);
      const fileInfo = await messenger.BrokerFileSystem.listInfo(extensionId, command.matchGLOB);
      this.debug(`listInfo -- fileInfo.length=${fileInfo.length}`);
      return ( { "fileInfo": fileInfo, "length": fileInfo.length } );

    } catch (error) {
      this.caught(error, `listInfo -- Caught error while listing items for extension "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing listInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  async getFullPathNameCommand(command, extensionId) {
    this.debug(`getFullPathNameCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName="${command.fileName}"`);

    if (command.fileName) { // fileName is optional
      if ((typeof command.fileName) !== 'string') {
        this.debug("getFullPathNameCommand -- Message 'fileName' parameter type is not 'string'");
        return ( { "invalid": "getFullPathName Command: 'fileName' parameter type must be 'string'" } );
      }

      if (! this.checkValidFileName(command.fileName)) {
        this.debug(`getFullPathNameCommand -- Message 'fileName' parameter is invalid: "${command.fileName}"`);
        return ( { "invalid": `getFullPathName Command: 'fileName' parameter is invalid: "${command.fileName}"` } );
      }
    }

    try {
      this.debug(`getFullPathNameCommand -- getting full pathname for file "${command.fileName}" for extension "${extensionId}"`);
      const fullPathName = await messenger.BrokerFileSystem.getFullPathName(extensionId, command.fileName);
      if (command.fileName) { // fileName is optional
        this.debug(`getFullPathNameCommand -- fileName="${command.fileName}", fullPathName="${fullPathName}"`);
        return ( { "fileName": command.fileName, "fullPathName": fullPathName } );
      }

      this.debug(`getFullPathNameCommand -- fileName="${extensionId}", fullPathName="${fullPathName}"`);
      return ( { "fileName": extensionId, "fullPathName": fullPathName } );

    } catch (error) {
      if (command.fileName) { // fileName is optional
        this.caught(error, `getFullPathNameCommand -- Caught error while getting full pathname for file "${command.fileName}":`);
      } else {
        this.caught(error, `getFullPathNameCommand -- Caught error while getting full pathname for file "${extensionId}":`);
      }
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing getFullPathName Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async isValidFileNameCommand(command, extensionId) {
    this.debug(`isValidFileNameCommand ~~~~~~~~~~~~~~~~~~~~ command.fileName="${command.fileName}"`);

    if (! command.fileName) {
      this.debug("isValidFileNameCommand -- Message has no 'fileName' parameter");
      return ( { "invalid": "isValidFileName Command: no 'fileName' parameter" } );
    } else if ((typeof command.fileName) !== 'string') {
      this.debug("isValidFileNameCommand -- Message 'fileName' parameter type is not 'string'");
      return ( { "invalid": "isValidFileName Command: 'fileName' parameter type must be 'string'" } );
    }

    try {
      this.debug(`isValidFileNameCommand -- checking for valid fileName for file "${command.fileName}"`);
      const valid = await messenger.BrokerFileSystem.isValidFileName(command.fileName);
      this.debug(`isValidFileNameCommand -- valid=${valid}`);
      return ( { "fileName": command.fileName, "valid": valid } );

    } catch (error) {
      this.caught(error, `isValidFileNameCommand -- Caught error while checking for valid fileName for file "${command.fileName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing isValidFileName Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async isValidDirectoryNameCommand(command, extensionId) {
    this.debug(`isValidDirectoryNameCommand ~~~~~~~~~~~~~~~~~~~~ command.directoryName="${command.directoryName}"`);

    if (! command.directoryName) {
      this.debug("isValidDirectoryNameCommand -- Message has no 'directoryName' parameter");
      return ( { "invalid": "isValidDirectoryName Command: no 'directoryName' parameter" } );
    } else if ((typeof command.directoryName) !== 'string') {
      this.debug("isValidDirectoryNameCommand -- Message 'directoryName' parameter type is not 'string'");
      return ( { "invalid": "isValidDirectoryName Command: 'directoryName' parameter type must be 'string'" } );
    }

    try {
      this.debug(`isValidDirectoryNameCommand -- checking for valid directoryName for directory "${command.directoryName}"`);
      const valid = await messenger.BrokerFileSystem.isValidDirectoryName(command.directoryName);
      this.debug(`isValidDirectoryNameCommand -- valid=${valid}`);
      return ( { "directoryName": command.directoryName, "valid": valid } );

    } catch (error) {
      this.caught(error, `isValidDirectoryNameCommand -- Caught error while checking for valid directoryName for directory "${command.directoryName}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing isValidDirectoryName Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async getFileSystemPathNameCommand(command, extensionId) {
    this.debug("getFileSystemPathNameCommand ~~~~~~~~~~~~~~~~~~~~");

    try {
      this.debug("getFileSystemPathNameCommand -- getting full pathName for FileSystem");
      const pathName = await messenger.BrokerFileSystem.getFileSystemPathName();
      this.debug(`getFileSystemPathNameCommand -- pathName="${pathName}"`);
      return ( { "pathName": pathName } );

    } catch (error) {
      this.caught(error, "getFileSystemPathNameCommand -- Caught error while getting full pathName for FileSystem:");
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing getFileSystemPathName Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    return false;
  }



  async statsCommand(command, extensionId) {
    this.debug(`statsCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ extensionId="${extensionId}" \nCOMMAND: `, command);

    const parameters = command.parameters;
    if (parameters) {
      if ((typeof parameters) !== 'object') {
        this.debug(`statsCommand -- 'parameters' parameter type is not 'object': "${typeof parameters}"`);
        return ( { "invalid": `stats Command: 'parameters' parameter type must be 'object': type='${(typeof parameters)}'` } );
      }
      const badKey = this.checkStatsCmdParms(parameters);
      if (badKey) {
        this.debug(`statsCommand -- 'parameters' parameter has invalid key: "${badKey}"`);
        return ( { "invalid": `stats Command: 'parameters' parameter has invalid key: '${badKey}'` } );
      }
    }

    var returnNotExist = parameters?.returnNotExist;
    if (returnNotExist === null || (typeof returnNotExist) === 'undefined') {
      // this is ok
      returnNotExist = false;
    } else if ((typeof returnNotExist) !== 'boolean') {
      this.debug(`statsCommand -- Message 'parameters.returnNotExist' type is not 'boolean'. It is '${typeof returnNotExist}'`);
      return ( { "invalid": `stats Command: 'parameters.returnNotExist' must be type 'boolean'. It is '${typeof returnNotExist}'` } );
    }

    var includeChildInfo = parameters?.includeChildInfo;
    if (includeChildInfo === null || (typeof includeChildInfo) === 'undefined') {
      // this is ok
      includeChildInfo = false;
    } else if ((typeof includeChildInfo) !== 'boolean') {
      this.debug(`statsCommand -- 'parameters.includeChildInfo' type is not 'boolean': '${typeof includeChildInfo}'` );
      return ( { "invalid": `stats Command: 'parameters.includeChlidInfo' must be type 'boolean': It is '${typeof includeChildInfo}'` } );
    }

    var types = parameters?.types;
    if (types === null || (typeof types) === 'undefined') {
      // this is ok
    } else if (! includeChildInfo) {
      this.debug("statsCommand -- 'parameters.types' parameter is not allowed when 'parameters.includeChildInfo is not 'true' - parameters:\n", parameters);
      return ( { "invalid": "stats -- 'parameters.types' parameter is not allowed when 'parameters.includeChildInfo' is not 'true'" } );
    } else if ((typeof types) !== 'object') {
      this.debug(`statsCommand -- Invalid 'parameters.types' parameter type - Must be 'object': type='${(typeof types)}'`);
      return ( { "invalid": `stats -- Invalid 'parameters.types' parameter type - Must be 'object': type='${(typeof types)}'` } );
    } else if (! Array.isArray(types)) {
      this.debug("statsCommand -- Invalid 'parameters.types' parameter type - Must be an Array");
      return ( { "invalid": "stats -- 'Invalid 'parameters.types' parameter type - Must be an Array" } );
    } else if (types.length < 1) {
      this.debug("statsCommand -- Invalid 'parameters.types' Array parameter is empty");
      return ( { "invalid": "stats -- 'parameters.types' Array parameter is empty" } );
    } else if (types.length > 3) {
      this.debug(`statsCommand -- Invalid 'parameters.types' Array parameter length > 3: ${types.length}`);
      return ( { "invalid": `stats -- 'parameters.types' Array parameter length > 3: ${types.length}` } );
    } else {
      const badType = this.checkStatsItemTypes(types); // we don't check for repeats, but schema.json does
      if (badType) {
        this.debug(`statsCommand -- 'types' parameter contains an invalid value: "${badType}"`);
        return ( { "invalid": `Stats Command: 'parameters.types'  parameter contains an invalid value: "${badType}"` } );
      }
      // this is ok
    }

    try {
      const exists = await messenger.BrokerFileSystem.exists(extensionId);
      if (! exists) {
        this.debug(`statsCommand -- Extension directory does not exist: "${extensionId}"`);
        if (returnNotExist) {
          return ( { "exists": false } );
        } else {
          return ( { "invalid": `stats Command: Extension Directory does not exist: "${extensionId}"` } );
        }
      }

      const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
      if (! isDirectory) {
        this.debug(`statsCommand -- File is not a Directory: "${extensionId}"`);
        return ( { "invalid": `stats Command: Extension Directory is not a Directory: "${extensionId}"` } );
      }
    } catch (error) {
      this.caught(error, `statsCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing stats Command: ${error.name} - ${error.message}`, "code": "500" } );
    }

    try {
      this.debug(`statsCommand -- getting stats for extension "${extensionId}", parameters:\n`, parameters);
      const stats = await messenger.BrokerFileSystem.stats(extensionId, parameters);
      this.debug(`statsCommand -- stats.extenstionId=${stats.extenstionId}\n`, stats);

      const response = { 'stats': stats };
      if (parameters) response['parameters'] = parameters;
      return response;

    } catch (error) {
      this.caught(error, `statsCommand -- Caught error getting stats for extension "${extensionId}":`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing stats Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  // MABXXX THIS IS AN INTERNAL-ONLY COMMAND!!!
  async fsbListInfoCommand(command, extensionId) {
    this.debug(`fsbListInfoCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ extensionId="${extensionId}"`);

    if (this.#EXTENSION_ID !== extensionId) {
      this.error(`fsbListInfoCommand -- THIS IS AN INTERNAL-ONLY COMMAND!  But it was requested by "${extensionId}"`);
      return ( { "error": "fsbListInfo: Unknown Command" } ); // MABXXX return something better???
    }

    const parameters = command.parameters;
    if (parameters) {
      if ((typeof parameters) !== 'object') {
        this.debug(`fsbListCommand -- Message 'parameters' parameter type is not 'object', type='${(typeof parameters)}'`);
        return ( { "invalid": `fsbList Command: 'parameters' parameter type must be 'object', type='${(typeof parameters)}'` } );
      }
      const badKey = this.checkListCmdParms(parameters);
      if (badKey) {
        this.debug(`fsbListInfoCommand -- 'parameters' parameter has invalid key: "${badKey}"`);
        return ( { "invalid": `fsbListInfo Command: 'parameters' parameter has invalid key: '${badKey}'` } );
      }
    }

    const types = parameters?.types;
    if (types === null || (typeof types) === 'undefined') {
      // this is ok
    } else if ((typeof types) !== 'object') {
      this.debug(`fsbList -- Invalid 'types' parameter type - Must be 'object': type='${(typeof types)}'`);
      return ( { "invalid": `fsbList Command: 'parameters.types' parameter type must be 'object', type='${(typeof types)}'` } );
    } else if (! Array.isArray(types)) {
      this.debug("fsbList -- Invalid 'types' parameter type - Must be an Array");
      return ( { "invalid": `fsbList Command: 'parameters.types' parameter type must be be an Array` } );
    } else if (types.length < 1) {
      this.debug("fsbList -- Invalid 'types' Array parameter is empty");
      return ( { "invalid": "fsbList Command: 'parameters.types' Array parameter is empty" } );
      throw new ExtensionError("BrokerFileSystem.fsbList -- 'types' Array parameter is empty");
    } else if (types.length > 3) {
      this.debug(`fsbList -- Invalid 'types' Array parameter has length > 3: ${types.length}`);
      return ( { "invalid": `fsbList Command: 'parameters.types' Array parameter is has length > 3: ${types.length}` } );
    } else {
      const badType = this.checkListItemTypes(types); // we don't check for repeats, but schema.json does
      if (badType) {
        this.debug(`fsbListInfo -- 'types' parameter contains an invalid value: "${badType}"`);
        return ( { "invalid": `fsbListInfo Command: 'parameters.types'  parameter contains an invalid value: "${badType}"` } );
      }
      // this is ok
    } 

    const matchGLOB = parameters?.matchGLOB;
    if (matchGLOB) {
      if ((typeof matchGLOB) !== 'string') {
        this.debug(`fsbListInfoCommand -- Message 'matchGLOB' parameter type is not 'string', type='${(typeof matchGLOB)}'`);
        return ( { "invalid": `fsbListInfo Command: 'matchGLOB' parameter type must be 'string', type='${(typeof matchGLOB)}'` } );
      }
    }

//  MABXXX DO WE HAVE A REAL extensionId TO DO ANY OF THIS!!! MABXXX
//
//         And if the directory doesn't exist,
//         it gets created by the API anyway.
//
//  try {
//    const exists = await messenger.BrokerFileSystem.exists(extensionId);
//    if (! exists) {
//      this.debug(`fsbListInfoCommand -- Directory does not exist: "${extensionId}"`);
//      return ( { "invalid": `fsbListInfo Command: Directory does not exist: "${extensionId}"` } );
//    }
//
//    const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
//    if (! isDirectory) {
//      this.debug(`fsbListInfoCommand -- File is not a Directory: "${extensionId}"`);
//      return ( { "invalid": `fsbListInfo Command: File is not a Directory: "${extensionId}"` } );
//    }
//  } catch (error) {
//    this.caught(error, `fsbListInfoCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
//    this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
//    return ( { "error": `Error Processing fsbListInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
//  }

    try {
      this.debug(`fsbListInfoCommand -- getting FileInfo of items for the Extension FileSystem`);
      const fileInfo = await messenger.BrokerFileSystem.fsbListInfo(parameters);  // NOTE: No extensionId!!!
      this.debug(`fsbListInfoCommand -- fileInfo.length=${fileInfo.length}`);

      const response = { "fileInfo": fileInfo, "length": fileInfo.length };
      if (parameters) response['parameters'] = parameters;
      return response;

    } catch (error) {
      this.caught(error, `fsbListInfoCommand -- Caught error while listing items for the Extension FileSystem`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing fsbListInfo Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  // MABXXX THIS IS AN INTERNAL-ONLY COMMAND!!!
  async fsbListCommand(command, extensionId) {
    this.debug(`fsbListCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ extensionId="${extensionId}"`);

    if (this.#EXTENSION_ID !== extensionId) {
      this.error(`fsbListCommand -- THIS IS AN INTERNAL-ONLY COMMAND!  But it was requested by "${extensionId}"`);
      return ( { "error": "fsbList: Unknown Command" } ); // MABXXX return something better???
    }

    const parameters = command.parameters;
    if (parameters) {
      if ((typeof parameters) !== 'object') {
        this.debug(`fsbListCommand -- Message 'parameters' parameter type is not 'object', type='${(typeof parameters)}'`);
        return ( { "invalid": `fsbList Command: 'parameters' parameter type must be 'object', type='${(typeof parameters)}'` } );
      }
      const badKey = this.checkListCmdParms(parameters);
      if (badKey) {
        this.debug(`fsbListCommand -- 'parameters' parameter has invalid key: "${badKey}"`);
        return ( { "invalid": `fsbListCommand: 'parameters' parameter has invalid key: '${badKey}'` } );
      }
    }

    const types = parameters?.types;
    if (types === null || (typeof types) === 'undefined') {
      // this is ok
    } else if ((typeof types) !== 'object') {
      this.debug(`fsbList -- Invalid 'types' parameter type - Must be 'object': type='${(typeof types)}'`);
      return ( { "invalid": `fsbList Command: 'parameters.types' parameter type must be 'object', type='${(typeof types)}'` } );
    } else if (! Array.isArray(types)) {
      this.debug("fsbList -- Invalid 'types' parameter type - Must be an Array");
      return ( { "invalid": `fsbList Command: 'parameters.types' parameter type must be be an Array` } );
    } else if (types.length < 1) {
      this.debug("fsbList -- Invalid 'types' Array parameter is empty");
      return ( { "invalid": "fsbList Command: 'parameters.types' Array parameter is empty" } );
      throw new ExtensionError("BrokerFileSystem.fsbList -- 'types' Array parameter is empty");
    } else if (types.length > 3) {
      this.debug(`fsbList -- Invalid 'types' Array parameter has length > 3: ${types.length}`);
      return ( { "invalid": `fsbList Command: 'parameters.types' Array parameter is has length > 3: ${types.length}` } );
    } else {
      const badType = this.checkListItemTypes(types); // we don't check for repeats, but schema.json does
      if (badType) {
        this.debug(`fsbList -- 'types' parameter contains an invalid value: "${badType}"`);
        return ( { "invalid": `fsbList Command: 'parameters.types'  parameter contains an invalid value: "${badType}"` } );
      }
      // this is ok
    } 

    const matchGLOB = parameters?.matchGLOB;
    if (matchGLOB) {
      if ((typeof matchGLOB) !== 'string') {
        this.debug(`fsbListInfoCommand -- Message 'matchGLOB' parameter type is not 'string', type='${(typeof matchGLOB)}'`);
        return ( { "invalid": `fsbListInfo Command: 'matchGLOB' parameter type must be 'string', type='${(typeof matchGLOB)}'` } );
      }
    }

//  MABXXX DO WE HAVE A REAL extensionId TO DO ANY OF THIS!!! MABXXX
//
//         And if the directory doesn't exist,
//         it gets created by the API anyway.
//
//  try {
//    const exists = await messenger.BrokerFileSystem.exists(extensionId);
//    if (! exists) {
//      this.debug(`fsbListCommand -- Directory does not exist: "${extensionId}"`);
//      return ( { "invalid": `fsbList Command: Directory does not exist: "${extensionId}"` } );
//    }
//
//    const isDirectory = await messenger.BrokerFileSystem.isDirectory(extensionId);
//    if (! isDirectory) {
//      this.debug(`fsbListCommand -- File is not a Directory: "${extensionId}"`);
//      return ( { "invalid": `fsbList Command: File is not a Directory: "${extensionId}"` } );
//    }
//  } catch (error) {
//    this.caught(error, `fsbListCommand -- Caught error while checking if Item "${extensionId}" exists and is a Directory:`);
//    this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
//    return ( { "error": `Error Processing fsbList Command: ${error.name} - ${error.message}`, "code": "500" } );
//  }

    try {
      this.debug(`fsbListCommand -- getting fileNames of items for the Extension FileSystem`);
      const list = await messenger.BrokerFileSystem.fsbList(parameters);  // NOTE: No extensionId!!!
      this.debug(`fsbListCommand -- list.length=${list.length}`);

      const response = { "list": list, "length": list.length };
      if (parameters) response['parameters'] = parameters;
      return response;

    } catch (error) {
      this.caught(error, `fsbListCommand -- Caught error while listing items for the Extension FileSystem`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing fsbList Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }


  // MABXXX THIS IS AN INTERNAL-ONLY COMMAND!!!
  async fsbStatsCommand(command, extensionId) {
    this.debug(`fsbStatsCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ extensionId="${extensionId}"`);

    if (this.#EXTENSION_ID !== extensionId) {
      this.error(`fsbStatsCommand -- THIS IS AN INTERNAL-ONLY COMMAND!  But it was requested by "${extensionId}"`);
      return ( { "error": "fsbStats: Unknown Command" } ); // MABXXX return something better???
    }

    const parameters = command.parameters;
    if (parameters) {
      if ((typeof parameters) !== 'object') {
        this.debug(`fsbStatsCommand -- Message 'parameters' parameter type is not 'object', type='${(typeof parameters)}'`);
        return ( { "invalid": `fsbStats Command: 'parameters' parameter type must be 'object', type='${(typeof parameters)}'` } );
      }
      const badKey = this.checkCmdParms(parameters, ['includeDirStats']);
      if (badKey) {
        this.debug(`fsbStatsCommand -- 'parameters' parameter has invalid key: "${badKey}"`);
        return ( { "invalid": `fsbStatsCommand: 'parameters' parameter has invalid key: '${badKey}'` } );
      }
    }

    var includeDirStats = parameters?.includeDirStats;
    if (includeDirStats === null || (typeof includeDirStats) === 'undefined') {
      includeDirStats = true; // <----------------------------------------------------- NOTE: DEFAULT IS true -------------------------<<<<<
    } else if ((typeof includeDirStats) !== 'boolean') {
      this.debug(`fsbStatsCommand -- 'parameters.includeDirStats' type is not 'boolean': '${typeof includeDirStats}'` );
      return ( { "invalid": `fsbStats Command: 'parameters.includeDirStats' type must be 'boolean': type='${typeof includeDirStats}'` } );
    }

    try {
      this.debug(`fsbStatsCommand -- getting stats for Directories in the Extension FileSystem`);
      const stats = await messenger.BrokerFileSystem.fsbStats(parameters);  // NOTE: No extensionId!!!
      this.debug(`fsbStatsCommand -- stats.length=${stats.length}`);

      const response = { "stats": stats, "length": Object.keys(stats).length };
      return response;

    } catch (error) {
      this.caught(error, `fsbStatsCommand -- Caught error while listing items for the Extension FileSystem`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing fsbStats Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }


  // MABXXX THIS IS AN INTERNAL-ONLY COMMAND!!!
  async fsbDeleteDirectoryCommand(command, extensionId) {
    this.debug(`fsbDeleteDirectoryCommand ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ extensionId="${extensionId}", COMMAND:\n"`, command);

    if (this.#EXTENSION_ID !== extensionId) {
      this.error(`fsbDeleteDirectoryCommand -- THIS IS AN INTERNAL-ONLY COMMAND!  But it was requested by "${extensionId}"`);
      return ( { "error": "fsbDeleteDirectory: Unknown Command" } ); // MABXXX return something better???
    }

    if (! command.directoryName) {
      this.debug("fsbDeleteDirectory -- Message 'directoryName' parameter is missing");
      return ( { "invalid": "fsbDeleteDirectory Command: 'directoryName' parameter is required" } );
    } else if ((typeof command.directoryName) !== 'string') {
      this.debug("fsbDeleteDirectory -- Message 'directoryName' parameter type is not 'string'");
      return ( { "invalid": "fsbDeleteDirectory Command: 'directoryName' parameter type must be 'string'" } );
    } else if (! this.checkValidDirName(command.directoryName)) {
      this.debug(`fsbDeleteDirectoryCommand -- Message 'directoryName' parameter is invalid: "${command.directoryName}"`);
      return ( { "invalid": `fsbDeleteDirectory Command: 'directoryName' parameter is invalid: "${command.directoryName}"` } );
    }

    const parameters = command.parameters;
    if (parameters) {
      if ((typeof parameters) !== 'object') {
        this.debug(`fsbDeleteDirectoryCommand -- Message 'parameters' parameter type is not 'object', type='${(typeof parameters)}'`);
        return ( { "invalid": `fsbDeleteDirectory Command: 'parameters' parameter type must be 'object', type='${(typeof parameters)}'` } );
      }
      const badKey = this.checkCmdParms(parameters, ['recursive']);
      if (badKey) {
        this.debug(`fsbDeleteDirectoryCommand -- 'parameters' parameter has invalid key: "${badKey}"`);
        return ( { "invalid": `fsbDeleteDirectory Command: 'parameters' parameter has invalid key: '${badKey}'` } );
      }
    }

    var recursive = parameters?.recursive;
    if (recursive === null || recursive === undefined) {
      recursive = false;
    } else if ((typeof recursive) !== 'boolean') {
      this.debug(`fsbDeleteDirectoryCommand -- Message 'parameters.recursive' parameter type is not 'boolean'. It is '${typeof command.recursive}'`);
      return ( { "invalid": `fsbDeleteDirectory Command: 'parameters.recursive' parameter must be type 'boolean'. It is '${typeof command.recursive}'` } );
    }

    try {
      this.debug(`fsbDeleteDirectoryCommand -- getting stats for Directories in the Extension FileSystem`);
      const deleted = await messenger.BrokerFileSystem.fsbDeleteDirectory(command.directoryName, parameters);  // NOTE: No extensionId!!!
      this.debug(`fsbDeleteDirectoryCommand -- deleted=${deleted}`);

      const response = { "deleted": deleted, "directoryName": command.directoryName };
      if (parameters) response['parameters'] = parameters;
      return response;

    } catch (error) {
      this.caught(error, `fsbDeleteDirectoryCommand -- Caught error while deleting a directory in the Extension FileSystem: "${command.directoryName}"`);
      this.#fsbEventLogger.logCaughtError(command.command, command, error); // Does NOT log Syntax Errors
      return ( { "error": `Error Processing fsbDeleteDirectory Command: ${error.name} - ${error.message}`, "code": "500" } );
    }
  }



  #unknownCommand(timeMS, Command, extId) {
    this.debug(`#unknownCommand ~~~~~~~~~~~~~~~~~~~~ Command.command="${Command.command}"`);

    if (! Command.command) {
      this.error("unknownCommand -- Message has no 'command' parameter");
      return ( { "error": "unknownCommand: Missing 'command' parameter", "code":  "400" });
    }

    this.error(`unknownCommand -- Message has an Invalid Command.command parameter: "${Command.command}"`);
    return ( { "error": `unknownCommand: Invalid 'command' Parameter: "${Command.command}"`, "code":  "404" } );
  }



  async #readOnlyAccess(timeMS, Command, extProps) {
    this.debug(`readOnlyAccess ~~~~~~~~~~~~~~~~~~~~ Command.command="${Command.command}"`);

    const logAccessDenied  = await this.#fsbOptionsApi.isEnabledAccessDeniedLogging();
    if (logAccessDenied) {
      const accessDeniedMsg = "Extension has Read-Only Access - Write Access is Denied";
      this.#fsbEventLogger.logCommandResult(timeMS, extProps.id, Command, accessDeniedMsg, "Read-Only Access");
    }

    const msg = `readOnlyAccess -- Extension "${extProps.id}" has Read-Only Access and is Denied Access to command "${Command.command}"`;
    this.error(msg);
    return { "error": msg, "code":  "403", "subCode": "read-only" };
  }



  async #overQuota(timeMS, Command, extProps) {
    this.debug(`overQuota ~~~~~~~~~~~~~~~~~~~~ Command.command="${Command.command}"`);

    const logAccessDenied  = await this.#fsbOptionsApi.isEnabledAccessDeniedLogging();
    if (logAccessDenied) {
      const accessDeniedMsg = "Extension is Over Quota - Write Access is Denied";
      this.#fsbEventLogger.logCommandResult(timeMS, extProps.id, Command, accessDeniedMsg, "Over Quota");
    }

    const msg = `overQuota -- Extension "${extProps.id}" is Over Quota and is Denied Access to command "${Command.command}"`;
    this.error(msg);
    return { "error": msg, "code":  "403", "subCode": "over-quota" };
  }



  async #internalOnlyCommand(timeMS, Command, extId) {
    this.debug(`internalOnlyCommand ~~~~~~~~~~~~~~~~~~~~ Command.command="${Command.command}"`);

    const logAccessDenied  = await this.#fsbOptionsApi.isEnabledAccessDeniedLogging();
    if (logAccessDenied) {
      const accessDeniedMsg = "This is an Internal-Only Command";
      this.#fsbEventLogger.logCommandResult(timeMS, extId, Command, accessDeniedMsg, "Internal Command");
    }

    const msg = `internalOnlyCommand -- Access is Denied, command "${Command.command}" is Internal-Use Only`;
    this.error(msg);
    return { "error": msg, "code":  "403" };
  }



  // Add every key/value pair in command to toObject for recording into a log file, but...
  // - if value is a String, limit to 25 chars,
  //   otherwise use (key + ":string.length") as the key and the string length as the value
  // - if value is an Array, use (key + ":array") as the key and format the elements, but limit to 5,
  //   otherwise use (key + ":array.length") as the key and the array length as the value
  // - if value is an Object, use (key + ":object.entries") as the key and format the entries, but limit to 5,
  //   otherwise use (key + ":object.entries.length") as the key and object.entries.length as the value
  //
  addCommandToObject(command, toObject) {
    if (command === null || toObject === null || (typeof command) !== 'object' || (typeof toObject) !== 'object') {
      // MABXXX
    } else {
      for (const [key, value] of Object.entries(command)) {
        if (key === 'data' && (typeof value) === 'string') {
          // if data string value is "short" (<=25) we put value
          if (value.length <= 25) {
            toObject[key] = value;
          } else {
            toObject[`${key}:string.length`] = value.length; // length because data could be huge!
          }
        } else if (value && (typeof value) === 'object') { // test for extistence of value - why for the love of puppies is (typeof null) === 'object'???
          if (Array.isArray(value)) { // no commands currently take arrays as parameters, but wth?
            // if array is "short" (<=5) we put elements, otherwise we put length
            if (value.length <= 5) {
              var valueList = '';
              const limit = value.length > 5 ? 5 : value.length;
              for (var i=0; i<limit; ++i) {
                const v = value[i]; // doesn't work if v is object
                if (i > 0) valueList += ", ";
                if ((typeof v) === 'string') {
                  if (v.length > 10) {
                    valueList += "[" + i + `]=stgring[${v.length}]`;
                  } else {
                    valueList += "[" + i + "]='" + v + "'"
                  }
                } else if (v == null) {
                  valueList += "[" + i + "]=null";
                } else if ((typeof v) === 'undefined') {
                  valueList += "[" + i + "]=undefined";
                } else if (Array.isArray(v)) {
                  valueList += "[" + i + `]=array[${v.length}]`;
                } else if ((typeof v) === 'object') {
                  valueList += "[" + i + "]=object";
                } else {
                  valueList += "[" + i + "]=" + v;
                }
              }
              toObject[`${key}[${value.length}]`] = valueList;
            } else {
              toObject[`${key}[${value.length}]`] = value.length;
            }
          } else { // just an object
            // if entries is "short" (<=5) we put entries, otherwise we put length
            const entries = Object.entries(value);
            if (entries.length > 0 && entries.length <= 5) {
              var valueList = '';
              var i = 0;
              for (const [k, v] of entries) { // doesn't work if v is object
                if (++i > 1) valueList += ", ";
                if ((typeof v) === 'string') {
                  valueList += "'" + k + "': '" + v + "'"; // what if string is long?
                } else {
                  valueList += "'" + k + "': " + v;
                }
              }
              toObject[`${key}:object.entries`] = valueList;
            } else {
              toObject[`${key}:object.entries.length`] = entries.length;
            }
          }
        } else if ((typeof value) === 'string') {
          // if value is "short" (<=25) we put value
          if (value.length <= 25) {
            toObject[key] = value;
          } else {
            toObject[`${key}:string.length`] = value.length; // length because data could be huge!
          }
        } else {
          toObject[key] = value;
        }
      }
    }
  }



  // Add every key/value pair in command to A string and return it, but
  // - if value is a String, limit to 25 chars,
  //   otherwise use ("string.length=" + length) as the value
  // - if value is an Array, format elements, but limit to 5,
  //   otherwise use ("array.length=" + length) as the value
  // - if value is an Object, format entries, but limit to 5,
  //   otherwise use ("object.entries.length=" + object.entries.length) as the value
  formatParameters(command) {
    this.debug(`formatParameters -- (typeof command): '${typeof command}'`);

    if ((typeof command) !== 'object') {
      this.error(`formatParameters -- (typeof command) is not 'object': '${typeof command}'`);
      this.debug(`formatParameters -- returning: '(command unavailable)'`);
      return "(command unavailable)";
    }

    var formatted = '';
    var idx = 0;
    for (const [key, value] of Object.entries(command)) {
      if (key === 'command') continue;

      if (++idx > 1) formatted += ', ';

      if (key === 'data' && (typeof value) === 'string') {
        // if data string value is "short" (<=25) we put value
        if (value.length <= 25) {
          formatted += `${key}="${value}"`;
        } else {
          formatted += `${key}: string(${value.length})`;
        }
      } else if (value && (typeof value) === 'object') {
        if (Array.isArray(value)) { // no commands currently take arrays as parameters, but wth?
          formatted += `${key}:array[${value.length}]`;
          // if array is "short" (<=5) we put elements, otherwise we put length
          if (value.length <= 5) {
            var valueList = '';
            const limit = value.length > 5 ? 5 : value.length;
            for (var i=0; i<limit; ++i) {
              const v = value[i];
              if (i > 0) valueList += ", ";
              if ((typeof v) === 'string') {
                if (v.length <= 25) {
                  valueList += `[${i}]="${v}"`;
                } else {
                  valueList += `[${i}]: string[${v.length}]`;
                }  
              } else if (v == null) {
                valueList += `[${i}]: null`;
              } else if (Array.isArray(v)) {
                valueList += `[${i}]: array[${v.length}]`;
              } else if ((typeof v) === 'object') {
                valueList += `[${i}]: object`;
              } else {
                valueList += `[${i}]=${v}`;
              }
            }
            formatted += ': ' + valueList;
          } else {
            // already done above
          }
        } else { // just and object
          // if entries is "short" (<=5) we put entries, otherwise we put length
          const entries = Object.entries(value);
          formatted += `${key}: object[${entries.length}]`;
          if (entries.length > 0 && entries.length <= 5) {
            var valueList = '';
            var i = 0;
            for (const [k, v] of entries) {
              if (++i > 1) valueList += ", ";
              if ((typeof v) === 'string') {
                if (v.length <= 25) {
                  valueList += `${k}: "${v}"`;
                } else {
                  valueList += `${k}: string(${v.length})`;
                }
              } else if (v == null) {
                valueList += `${k}: null`;
              } else if (Array.isArray(v)) {
                valueList += `${k}: array[${v.length}]`;
              } else if ((typeof v) === 'object') {
                valueList += `${k}: object`; // MABXXX WHAT IF k==="parameters";
              } else {
                valueList += `${k}: ${v}`;
              }
            }
            formatted += ': ' + valueList;
          } else {
            // already done above
          }
        }
      } else if ((typeof value) === 'string') {
        if (value.length <= 25) {
          formatted += `${key}="${value}"`;
        } else {
          formatted += `${key}: string(${value.length})`;
        }
      } else {
        formatted += `${key}=${value}`;
      }
    }

    this.debug(`formatParameters -- returning: '${formatted}'`);
    return formatted;
  }



  formatCommandResult(command, result) {
    if (command === null || (typeof command) !== 'object' || result === null || (typeof result) !== 'object') {
      this.error(`formatCommandResult -- Invalid Parameter Types: (typeof command)='${typeof command}' (typeof result)='${typeof result}'`);
      return "(result unavailable)";

    } else {
      if (result.hasOwnProperty("error")) {
        return "error: " + result.error;
      }
      if (result.hasOwnProperty("invalid")) {
        return "invalid: " + result.invalid;
      }

      switch(command.command) {
        case "access": // this command must be handled where access control is handled, which is in fsb-background.js for now
          return "access=" + result.access;
        case "exists":
          return "exists=" + result.exists;
        case "isRegularFile":
          return "isRegularFile=" + result.isRegularFile;
        case "isDirectory":
          return "isDirectory=" + result.isDirectory;
        case "hasFiles":
          return "hasFiles=" + result.hasFiles;
        case "getFileCount":
          return "fileCount=" + result.fileCount;
        case "writeFile":
          return "bytesWritten=" + result.bytesWritten;
        case "replaceFile":
          return "bytesWritten=" + result.bytesWritten;
        case "appendToFile":
          return "bytesWritten=" + result.bytesWritten;
        case "writeJSONFile":
          return "bytesWritten=" + result.bytesWritten;
        case "writeObjectToJSONFile":
          return "bytesWritten=" + result.bytesWritten;
        case "readFile":
          return "length=" + result.data.length;
        case "readJSONFile":
          return "length=" + result.data.length;
        case "readObjectFromJSONFile":
          {
            const value   = result.object;
            const entries = Object.entries(value);
//          if (entries.length > 0 && entries.length <= 5) {
//            var valueList = '';
//            var idx = 0;
//            for (const [k, v] of entries) { // doesn't work if v is object
//              if (++idx > 1) valueList += ", ";
//              if ((typeof v) === 'string') {
//                valueList += "'" + k + "': '" + v + "'"; // what if string is long?
//              } else {
//                valueList += "'" + k + "': " + v;
//              }
//            }
//            return "object:entries=" + valueList;
//          }
            return "object:entries.length=" + entries.length;

          }
        case "getFileInfo":
          {
            const info = result.fileInfo;
//          return     "FileInfo:"
//                   + ` fileName="${info.fileName}"`
            return      `fileName="${info.fileName}"`
//                   + ` path="${info.path}"`
                     + ` type="${info.type}"`
                     + ` size=${info.size}`
//                   + ` permissions=${info.permissions}`
//                   + ` creationTime="${utils.formatMsToDateTime24HR(info.creationTime)}" (${info.creationTime})`
                     + ` creationTime="${utils.formatMsToDateTime24HR(info.creationTime)}"`
//                   + ` lastAccessed="${utils.formatMsToDateTime24HR(info.lastAccessed)}" (${info.lastAccessed})`
                     + ` lastAccessed="${utils.formatMsToDateTime24HR(info.lastAccessed)}"`
//                   + ` lastModified="${utils.formatMsToDateTime24HR(info.lastModified)}" (${info.lastModified})`;
                     + ` lastModified="${utils.formatMsToDateTime24HR(info.lastModified)}"`;
          }
        case "renameFile":
          return "renamed=" + result.renamed;
        case "deleteFile":
          return "deleted=" + result.deleted;
        case "deleteDirectory":
          return "deleted=" + result.deleted;
        case "makeDirectory":
          return "created=" + result.created;
        case "listFiles":
          return result.fileNames ? "fileNameslength=" + result.fileNames.length : "(NO fileNames)";
        case "listFileInfo":
          return result.fileInfo  ? "fileInfo.length=" + result.fileInfo.length  : "(NO fileInfo)";
        case "list":
          return result.fileNames ? "fileNameslength=" + result.fileNames.length : "(NO fileNames)";
        case "listInfo":
          return result.fileInfo  ? "fileInfo.length=" + result.fileInfo.length  : "(NO fileInfo)";
        case "getFullPathName":
          return "fullPathName=" + result.fullPathName;
        case "isValidFileName":
          return "valid=" + result.valid;
        case "isValidDirectoryName":
          return "valid=" + result.valid;
        case "getFileSystemPathName":
          return "pathName=" + result.pathName;
        case "stats":
          if (result.stats && (typeof result.stats) === 'object') {
            var resultEntries = Object.entries(result.stats);
            if (resultEntries.length < 1) {
              // return "(NO stats)"; // fall through to below
            } else if (resultEntries.length > 1) { // there should only be one
              return `stats entries=${entries.length}`;
            } else {
              var out = '';
              for (const [extId, stats] of resultEntries) { // limited to exactly one by the tests above
                if (out.length > 0) out += " || ";
                if (stats && (typeof stats) === 'object') {
                  out +=   ` extensionId="${extId}":`
                         + ` dirname="${stats.dirName}"`
                         + ` children="${stats.children}"`
                         + ` regular="${stats.regular}"`
                         + ` directory="${stats.directory}"`
                         + ` other="${stats.other}"`
                         + ` unknown="${stats.unknown}"`
                         + ` weeoe="${stats.weeoe}"`
                         + ` size="${stats.size}"`;
                } else {
                  out += "(not an object)";
                }
              }
              return out;
            }
          }
          return "(NO stats)";
        case "fsbListInfo":
          return result.fileInfo  ? "fileInfo.length=" + result.fileInfo.length  : "(NO fileInfo)";
        case "fsbList":
          return result.list  ? "list.length=" + result.list.length  : "(NO list)";
        case "fsbStats":
          if (result.stats) { 
            return result.stats.dirStats ? `dirStats.length=${Object.keys(result.stats.dirStats).length} length=${result.length}` : "(NO dirStats)";
          }
          return "(NO stats)";
        case "fsbDeleteDirectory":
          return "deleted=" + result.deleted;
      }

      return "Unknown Command:" + command.command;
    }
  }




  checkStatsCmdParms(parms) {
    for (const key of Object.keys(parms)) {
      if ((typeof key) !== 'string') return '(not a string)';
      switch (key) {
        case 'returnNotExist':
        case 'includeChildInfo':
        case 'types':
          break;
        default:
          return key;
      }
    }
  }

  checkListCmdParms(parms) {
    for (const key of Object.keys(parms)) {
      if ((typeof key) !== 'string') return '(not a string)';
      switch (key) {
        case 'matchGLOB':
        case 'types':
          break;
        default:
          return key;
      }
    }
  }

  checkCmdParms(parms, allowedKeys) {
    for (const key of Object.keys(parms)) {
      if ((typeof key) !== 'string') return '(not a string)';
      if (! allowedKeys.includes(key)) return key;
    }
  }

  checkStatsItemTypes(itemTypes) {
    for (const itemType of itemTypes) {
      if (typeof itemType !== 'string') return '(not a string)';
      if (! this.checkStatsItemType(itemType)) return itemType;
    }
  }

  checkStatsItemType(itemType) {
    switch (itemType) {
      case 'regular':
      case 'directory':
      case 'other':
      case 'unknown':
      case 'error':
        return true;
    }

    return false;
  }

  checkListItemTypes(itemTypes) {
    for (const itemType of itemTypes) {
      if (typeof itemType !== 'string') return '(not a string)';
      if (! this.checkListItemType(itemType)) return itemType;
    }
  }

  checkListItemType(itemType) {
    switch (itemType) {
      case 'regular':
      case 'directory':
      case 'other':
        return true;
    }

    return false;
  }




  /* Return true of the given filename is valid, otherwise false
   *
   * filename type must be 'string'
   *
   * ILLEGAL CHARS:
   *
   *   <
   *   >
   *   :
   *   "
   *   /
   *   \
   *   |
   *   ?
   *   *
   *   x00-x1F (control characters)
   *
   * RESERVED NAMES:
   * - con
   * - prn
   * - aux
   * - nul
   * - com0 - com9
   * - lpt0 - lpt9
   * AND FOR DIRECTORIES:
   * - ..
   *
   * NO MORE THAN 64 CHARACTERS
   */
  checkValidFileName(filename) {
    if ((typeof filename) !== 'string') return false;
    if (filename.length < 1 || filename.length > 64) return false;

    const ILLEGAL_CHARS = /[<>:"/\\|?*\x00-\x1F]/g;
    if (ILLEGAL_CHARS.test(filename)) return false;

    // should this be windows-only???
    const RESERVED_NAMES = /^(con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;
    if (RESERVED_NAMES.test(filename)) return false;

    return true;
  }

  checkValidDirName(dirname) {
    if ((typeof dirname) !== 'string') return false;
    if (dirname.length < 1 ||  dirname.length > 64) return false;

    const ILLEGAL_CHARS = /[<>:"/\\|?*\x00-\x1F]/g;
    if (ILLEGAL_CHARS.test(dirname)) return false;

    // should this be windows-only???
    const RESERVED_NAMES = /^(\.\.|con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;
    if (RESERVED_NAMES.test(dirname)) return false;


    return true;
  }

  /* Must be a String with at least one character.
   *
   * ILLEGAL CHARS:
   *
   *   A-Z (must be lower-case)
   *   <
   *   >
   *   :
   *   "
   *   /
   *   \
   *   |
   *   ?
   *   *
   *   x00-x1F (control characters)
   *
   * RESERVED NAMES:
   * - con
   * - prn
   * - aux
   * - nul
   * - com0 - com9
   * - lpt0 - lpt9
   * - ..
   *
   * NO MORE THAN *64* CHARACTERS
   */
  checkValidExtensionId(extensionId) {
    if ((typeof extensionId) !== 'string' || extensionId.length < 1 || extensionId.length > 64) return false;

    const ILLEGAL_CHARS = /[<>:"/\\|?*\x00-\x1F]/g; // will be used as part of a directoryName, so no OS-restricted chars
    if (ILLEGAL_CHARS.test(extensionId)) return false;

    // should this be windows-only???
    const RESERVED_NAMES = /^(\.\.|con|prn|aux|nul|com[0-9]|lpt[0-9])$/i;
    if (RESERVED_NAMES.test(extensionId)) return false;

    // note: no upper-case
    const LIKE_EMAIL_REGEX = /\A(?=[a-z0-9@.!#$%&'*+/=?^_`{|}~-]{6,254}\z)(?=[a-z0-9.!#$%&'*+/=?^_`{|}~-]{1,64}@)[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:(?=[a-z0-9-]{1,63}\.)[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?=[a-z0-9-]{1,63}\z)[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\z/;

////const ENCLOSED_GUID_REGEX   = /^\{[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\}$/;
////const UNENCLOSED_GUID_REGEX = /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    // note: no upper-case
    const ENCLOSED_GUID_REGEX   = /^\{[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\}$/;
    const UNENCLOSED_GUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

    if (! LIKE_EMAIL_REGEX.test(extensionId)) {
      if (extensionId[0] === '{') {
        if (ENCLOSED_GUID_REGEX.test(extensionId)) return true;
      } else {
        if (UNENCLOSED_GUID_REGEX.test(extensionId)) return true;
      }
    }

    return true;
  }




  checkWriteMode(writeMode) {
    if ((typeof writeMode) !== 'string') return false;

    switch (writeMode) {
      case 'overwrite':
      case 'append':
      case 'appendOrCreate':
      case 'create':
        return true;
    }

    return false;
  }
}
