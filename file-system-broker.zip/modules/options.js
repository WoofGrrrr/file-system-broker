import { FileSystemBrokerAPI } from '../modules/FileSystemBroker/filesystem_broker_api.js';

import { logProps, getExtensionId, getExtensionName, getI18nMsg, formatNowToDateTimeForFilename, formatMsToDateTime24HR, getMidnightMS } from './utilities.js';

export class FsbOptions {
  #DEFAULT_OPTION_KEYS = [
    'fsbExtensionAccessControlEnabled',
    'fsbShowGrantExtensionAccessDialog',
    'fsbShowOptionsWindowOnStartup', 
    'fsbSkipOnboardingEnabled',
    'fsbEnableConsoleLog',
    'fsbEnableConsoleDebug',
    'fsbEnableConsoleDebugTrace',
    'fsbEnableConsoleWarn',
    'fsbEnableConsoleErrorTrace',
    'fsbEnableAccessLogging',
    'fsbEnableAccessDeniedLogging',
    'fsbEnableInternalMessageLogging',
    'fsbEnableInternalMessageResultLogging',
    'fsbEnableExternalMessageLogging',
    'fsbEnableExternalMessageResultLogging',
    'fsbEnableInternalEventLogging',
    'fsbShowLoggingOptions',
    'fsbAutoLogPurgeDays',
    'fsbAutoRemoveUninstalledExtensionsDays',
    'fsbShowOptionsHints',
    'fsbShowOptionsActions',
    'fsbShowExtensionChooserInstructions',
    'fsbShowBackupManagerInstructions',
    'fsbShowEventLogManagerInstructions',
    'fsbShowStatsManagerInstructions',
    'fsbOnRemoveExtensionDeleteDirectory',
  ];

  #DEFAULT_OPTION_VALUES = {
    'fsbExtensionAccessControlEnabled':       true,
    'fsbShowGrantExtensionAccessDialog':      false,
    'fsbShowOptionsWindowOnStartup':          false,
    'fsbSkipOnboardingEnabled':               false,
    'fsbEnableConsoleLog':                    false,
    'fsbEnableConsoleDebug':                  false,
    'fsbEnableConsoleDebugTrace':             false,
    'fsbEnableConsoleWarn':                   false,
    'fsbEnableConsoleErrorTrace':             false,
    'fsbEnableAccessLogging':                 false,
    'fsbEnableAccessDeniedLogging':           true,
    'fsbEnableInternalMessageLogging':        false,
    'fsbEnableInternalMessageResultLogging':  true,
    'fsbEnableExternalMessageLogging':        false,
    'fsbEnableExternalMessageResultLogging':  true,
    'fsbEnableInternalEventLogging':          true,
    'fsbShowLoggingOptions':                  true,
    'fsbAutoLogPurgeDays':                    14,
    'fsbAutoRemoveUninstalledExtensionsDays': 2,
    'fsbShowOptionsHints':                    true,
    'fsbShowOptionsActions':                  true,
    'fsbShowExtensionChooserInstructions':    true,
    'fsbShowBackupManagerInstructions':       true,
    'fsbShowEventLogManagerInstructions':     true,
    'fsbShowStatsManagerInstructions':        true,
    'fsbOnRemoveExtensionDeleteDirectory':    true,
  };



  constructor(logger, fsbEventLogger) {
    this.className      = this.constructor.name;
    this.extId          = getExtensionId();
    this.extName        = getExtensionName();

    this.INFO           = false;
    this.LOG            = false;
    this.DEBUG          = false;
    this.WARN           = false;

    this.logger         = logger;
    this.fsbEventLogger = fsbEventLogger;
    this.fsBrokerApi    = new FileSystemBrokerAPI();

    this.BACKUP_FILENAME_EXTENSION  = ".fsbbackup";
    this.BACKUP_FILENAME_MATCH_GLOB = "*.fsbbackup";

    this.settingDefaultOptions = false;

    Object.freeze(this.#DEFAULT_OPTION_KEYS);
    Object.freeze(this.#DEFAULT_OPTION_VALUES);
  }


  
  log(...info) {
    if (this.LOG)  {
      if (this.logger) {
        this.logger.log(this.className, ...info); // this adds the extension ID and Caller Info
      } else {
        console.log(this.extId + "." + this.className, ...info);
      }
    }
  }
  
  logAlways(...info) {
    if (this.logger) {
      this.logger.logAlways(this.className, ...info); // this adds the extension ID and Caller Info
    } else {
      console.log(this.extId + "." + this.className, ...info);
    }
  }

  debug(...info) {
    if (this.DEBUG) {
      if (this.logger) {
        this.logger.debug(this.className, ...info); // this adds the extension ID and Caller Info
      } else {
        console.debug(this.extId + "." + this.className, ...info);
      }
    }
  }

  debugAlways(...info) {
    if (this.logger) {
      this.logger.debugAlways(this.className, ...info); // this adds the extension ID and Caller Info
    } else {
      console.debug(this.extId + "." + this.className, ...info);
    }
  }

  error(...info) {
    if (this.logger) {
      this.logger.error(this.className, ...info); // this adds the extension ID and Caller Info
    } else {
      console.error(this.extId + "." + this.className, ...info);
    }
  }

  caught(e, msg, ...info) {
    // always log exceptions
    if (this.logger) {
      this.logger.error( this.className,
                         msg,
                         "\n- name:    " + e.name,
                         "\n- message: " + e.message,
                         "\n- stack:   " + e.stack,
                         ...info
                   );
    } else {
      console.error( this.extId,
                     msg,
                     "\n- name:    " + e.name,
                     "\n- message: " + e.message,
                     "\n- stack:   " + e.stack,
                     ...info
                   );
    }
  }



  setEventLogger(fsbEventLogger) {
    this.fsbEventLogger = fsbEventLogger;
  }




  async resetOptions() {
    await messenger.storage.local.clear();
    await this.setupDefaultOptions();
  }



  async setupDefaultOptions() {
    this.log("-- begin");

    const optionKeys = await messenger.storage.local.get(this.#DEFAULT_OPTION_KEYS);
    this.log('locally stored options:',  optionKeys);

    for (const [optionKey, defaultValue] of Object.entries(this.#DEFAULT_OPTION_VALUES)) {
      if (!(optionKey in optionKeys)) {
        messenger.storage.local.set(
          { [optionKey] : defaultValue}
        );
        this.log(`new option: [${optionKey}]: ${defaultValue}`);
      }
    }
    
    this.settingDefaultOptions = true;
    let extensionsProps = await this.getExtensionsProps();
    this.settingDefaultOptions = false;

    let defaultExtensionProps;
    if (! extensionsProps) {
      this.logAlways("creating initial extensions properties");
      extensionsProps = {};
    } else {
      this.log("got extensions properties");
      defaultExtensionProps = extensionsProps[this.extId];
    }

    if (! defaultExtensionProps) {
      const ourExtensionInfo = await messenger.management.getSelf();
      defaultExtensionProps = {
        'id':          ourExtensionInfo.id, // should be same as this.extId
        'shortName':   ourExtensionInfo.shortName,
        'name':        ourExtensionInfo.name,
        'description': ourExtensionInfo.description,
        'version':     ourExtensionInfo.version,
        'versionName': ourExtensionInfo.versionName,
        'disabled':    false, // ! ourExtensionInfo.enabled
        'allowAccess': true,
        'locked':      true
      };

      if (this.LOG) {
        this.logAlways("creating default extension properties");
        logProps("", "setupDefaultOptions.defaultExtensionProps", defaultExtensionProps);
      }
      extensionsProps[this.extId] = defaultExtensionProps;

      if (this.LOG) {
        logProps("", `setupDefaultOptions.extensionsProps["${this.extId}"]`, extensionsProps[this.extId]);
        this.logAlways(`and storing them -- length=${Object.keys(extensionsProps).length}`);
        logProps("", "setupDefaultOptions.extensionProps", extensionsProps);
      }
      await this.storeExtensionsProps(extensionsProps);
    }

    this.log("-- end");
  }

  getDefaultOptionNames() {
    return this.#DEFAULT_OPTION_KEYS;
  }

  getDefaultOptions() {
    return this.#DEFAULT_OPTION_VALUES;
  }

  isDefaultOption(optionName) {
    return this.#DEFAULT_OPTION_KEYS.includes(optionName);
  }



  async isEnabledExtensionAccessControl() {
    return this.isEnabledOption('fsbExtensionAccessControlEnabled', false);
  }

  async isEnabledShowGrantExtensionAccessDialog() {
    return this.isEnabledOption('fsbShowGrantExtensionAccessDialog', false);
  }

  async isEnabledShowOptionsWindowOnStartup() {
    return this.isEnabledOption('fsbShowOptionsWindowOnStartup', false);
  }

  async isEnabledSkipOnboarding() {
    return this.isEnabledOption('fsbSkipOnboardingEnabled', false);
  }

  async isEnabledConsoleLog() {
    return this.isEnabledOption('fsbEnableConsoleLog', false);
  }

  async isEnabledConsoleDebug() {
    return this.isEnabledOption('fsbEnableConsoleDebug', false);
  }

  async isEnabledConsoleDebugTrace() {
    return this.isEnabledOption('fsbEnableConsoleDebugTrace', false);
  }

  async isEnabledConsoleWarn() {
    return this.isEnabledOption('fsbEnableConsoleWarn', false);
  }

  async isEnabledConsoleErrorTrace() {
    return this.isEnabledOption(' fsbEnableConsoleErrorTrace', false);
  }

  async isEnabledAccessLogging() {
    return this.isEnabledOption('fsbEnableAccessLogging', false);
  }

  async isEnabledAccessDeniedLogging() {
    return this.isEnabledOption('fsbEnableAccessDeniedLogging', true);
  }

  async isEnabledInternalMessageLogging() {
    return this.isEnabledOption('fsbEnableInternalMessageLogging', false);
  }

  async isEnabledInternalMessageResultLogging() {
    return this.isEnabledOption('fsbEnableInternalMessageResultLogging', true);
  }

  async isEnabledExternalMessageLogging() {
    return this.isEnabledOption('fsbEnableExternalMessageLogging', false);
  }

  async isEnabledInternalEventLogging() {
    return this.isEnabledOption('fsbEnableInternalEventLogging', true);
  }

  async isEnabledExternalMessageResultLogging() {
    return this.isEnabledOption('fsbEnableExternalMessageResultLogging', true);
  }

  async isEnabledShowLoggingOptions() {
    return this.isEnabledOption('fsbShowLoggingOptions', true);
  }

  async isEnabledShowOptionsHints() {
    return this.isEnabledOption('fsbShowOptionsHints', true);
  }

  async isEnabledShowOptionsActions() {
    return this.isEnabledOption('fsbShowOptionsActions', true);
  }

  async isEnabledShowExtensionChooserInstructions() {
    return this.isEnabledOption('fsbShowExtensionChooserInstructions', true);
  }

  async isEnabledShowBackupManagerInstructions() {
    return this.isEnabledOption('fsbShowBackupManagerInstructions', true);
  }

  async isEnabledShowEventLogManagerInstructions() {
    return this.isEnabledOption('fsbShowEventLogManagerInstructions', true);
  }

  async isEnabledShowStatsManagerInstructions() {
    return this.isEnabledOption('fsbShowStatsManagerInstructions', true);
  }

  async isEnabledOnRemoveExtensionDeleteDirectory() {
    const KEY = 'fsbOnRemoveExtensionDeleteDirectory';
    return this.isEnabledOption(KEY, true);
  }

  async isEnabledOption(key, defaultValue) {
    const options = await messenger.storage.local.get(key); // returns a Promise of an Object with a key-value pair for every key found

    var value = defaultValue;
    if (key in options) {
      value = options[key]; // get the value for the specific key
    }

    return value;
  }



  async getAutoLogPurgeDays(defaultValue) {
    const options = await messenger.storage.local.get('fsbAutoLogPurgeDays'); // returns a Promise of an Object with a key-value pair for every key found

    var value = defaultValue;
    if ('fsbAutoLogPurgeDays' in options) {
      value = options['fsbAutoLogPurgeDays']; // get the value for the specific key
      if (typeof value === 'string') {
        value = +value;
        if (Number.isNaN(value)) value = defaultValue;
      }
    }

    return value;
  }

  async getAutoRemoveUninstalledExtensionsDays(defaultValue) {
    const options = await messenger.storage.local.get('fsbAutoRemoveUninstalledExtensionsDays'); // returns a Promise of an Object with a key-value pair for every key found

    var value = defaultValue;
    if ('fsbAutoRemoveUninstalledExtensionsDays' in options) {
      value = options['fsbAutoRemoveUninstalledExtensionsDays']; // get the value for the specific key
      if (typeof value === 'string') {
        value = +value;
        if (Number.isNaN(value)) value = defaultValue;
      }
    }

    return value;
  }



  async getAllOptions() {
    return messenger.storage.local.get(); // returns a Promise of an array of Object with a key-value pair for every key found
  }

  async getOption(key, defaultValue) {
    const options = await messenger.storage.local.get(key); // returns a Promise of an Object with a key-value pair for every key found

    var value = defaultValue;
    if (key in options) {
      value = options[key]; // get the value for the specific key
    }

    return value;
  }



  // obj must be object like: {[key], value}
  async storeOption(obj) {
    return messenger.storage.local.set(obj);
  }

  // build object {[key], value} and store it
  async saveOption(key, value) {
    const obj = {[key]: value};
    return await this.storeOption(obj);
  }



  async getExtensionsProps() {
    const nowMS               = Date.now();
    const installedExtensions = await messenger.management.getAll();
    const props               = await messenger.storage.local.get('extensionsProps'); // return Object with key-value pair for every key found
    let   extensionsProps;

    if (this.DEBUG) {
      this.debugAlways(`-- installedExtensions.length=${installedExtensions.length}`);
      logProps("", "FSBOptions.getExtensionsProps.installedExtensions", installedExtensions);
    }

    if (! props) {
      // this is not an error if we're setting defaults
      if (! this.settingDefaultOptions) this.error("-- failed to get 'extensionsProps' from local storage");

    } else {
      extensionsProps = props['extensionsProps'];
      if (! extensionsProps) {
        if (! this.settingDefaultOptions) this.error("-- failed to get props['extensionsProps'] (extensionsProps) from local storage");

      } else if (typeof extensionsProps !== 'object') {
        if (! this.settingDefaultOptions) this.error("-- props['extensionsProps'] (extensionsProps) is not a object");

      } else {
        if (this.DEBUG) {
          this.debugAlways(`-- Object.keys(extensionsProps).length=${Object.keys(extensionsProps).length}`);
          logProps("", "FSBOptions.getExtensionsProps.extensionsProps", extensionsProps);
        }

        if (installedExtensions && installedExtensions.length > 0) {
          // Update extensionsProps with data from the currently-installed extensions
          for (const installedExtension of installedExtensions) { // an array of managament.ExtensionInfo
            if (installedExtension.type === 'extension') {
              const installedExtensionIsConfigured = extensionsProps.hasOwnProperty(installedExtension.id);
              if (! installedExtensionIsConfigured) {
                this.debug(`-- Extension NOT configured - not found in extensionsProps: ID="${installedExtension.id}`);
              } else {
                this.debug(`-- Extension IS configured - found in extensionsProps: ID="${installedExtension.id}`);

                const extensionProps       = extensionsProps[installedExtension.id];
                extensionProps.installed   = true; // this should have been 'configured'
                extensionProps.uninstalled = false;
                extensionProps.id          = installedExtension.id;                       // redundant - should already be there
                extensionProps.description = installedExtension.description;              // remove this line if we ever store this locally so we can edit/replace
                extensionProps.disabled    = ! installedExtension.enabled;                // remove this line if we ever store this locally so we can edit/replace
////////////////extensionProps.name        = installedExtension.name;                     // we store this locally so we can edit/replace MABXXX WHY?
                extensionProps.shortName   = installedExtension.shortName;                // remove this line if we ever store this locally so we can edit/replace
                extensionProps.version     = installedExtension.version;
                extensionProps.versionName = installedExtension.versionName;
              }
            }
          }

          // If the extension is NOT in installedExtensions, then mark it as uninstalled
          for (const [extensionId, extensionProps] of Object.entries(extensionsProps)) {
            const foundInstalledExtension = installedExtensions.find(extension => extension.id === extensionId);
            if (foundInstalledExtension) {
              extensionProps.uninstalled = false; // <--- Redudant with code just above, but WTF? 
              delete extensionProps['uninstalledTimeMS'];
            } else {
              extensionProps.uninstalled       = true;
              extensionProps.uninstalledTimeMS = Date.now(); // MABXXX uninstalledTimeMS
            }
          }
        } else {
          // NO installedExtensions, so mark them all as uninstalled
          for (const [extensionId, extensionProps] of Object.entries(extensionsProps)) {
            extensionProps.uninstalled       = true;
            extensionProps.uninstalledTimeMS = Date.now(); // MABXXX uninstalledTimeMS
          }
        }

        //MABXXX SHOULD WE UPDATE STORAGE???

        if (this.DEBUG) {
          this.debugAlways(`-- RETURNING Object.keys(extensionsProps).length=${Object.keys(extensionsProps).length}`);
          logProps("", "FSBOptions.getExtensionsProps.extensionsProps", extensionsProps);
        }
      }
    }

    return extensionsProps;
  }

  async getExtensionsPropsSortedById() {
    const extensionsProps = await this.getExtensionsProps();

    if (! extensionsProps) {
      this.error("-- getExtensionsProps() DIDN'T RETURN ANYTHING");
    } else {
      if (this.LOG) {
        this.log("-- extensionsProps:");
        logProps("", "FSBOptions.getExtensionsPropsSortedById.extensionsProps", extensionsProps);
      }

      const sorted = sortExtensionsPropsById(extensionsProps, true);

      if (this.LOG) {
        this.log("-- sorted:");
        logProps("", "FSBOptions.getExtensionsPropsSortedById.sorted", sorted);
      }


      return sorted;
    }

    function sortExtensionsPropsById(extensionsProps, ascending = true) {
      const sortedEntries = Object.entries(extensionsProps).sort(([, a], [, b]) => {
        return ascending ? a.id.localeCompare(b.id, { 'sensitity': 'base' } )
                         : a.id.localeCompare(b.id, { 'sensitity': 'base' } ) * -1;
      });
      return Object.fromEntries(sortedEntries);
    }
  }

  async getExtensionsPropsSortedByName() {
    const extensionsProps = await this.getExtensionsProps();

    if (! extensionsProps) {
      this.error("-- getExtensionsProps() DIDN'T RETURN ANYTHING");
    } else {
      if (this.LOG) {
        this.log("-- extensionsProps:");
        logProps("", "FSBOptions.getExtensionsPropsSortedByName.extensionsProps", extensionsProps);
      }

      const sorted =  sortExtensionsPropsByName(extensionsProps, true);

      if (this.LOG) {
        this.log("-- sorted:");
        logProps("", "FSBOptions.getExtensionsPropsSortedByName.sorted", sorted);
      }

      return sorted;
    }

    function sortExtensionsPropsByName(extensionsProps, ascending = true) {
      const sortedEntries = Object.entries(extensionsProps).sort(([, a], [, b]) => {
        return ascending ? a.name.localeCompare(b.name, { 'sensitity': 'base' } )
                         : a.name.localeCompare(b.name, { 'sensitity': 'base' } ) * -1;
      });
      return Object.fromEntries(sortedEntries);
    }
  }

  async getExtensionPropsById(extensionId) {
    if ((typeof extensionId === 'string') && extensionId.length > 0) {
      const extensionsProps = await this.getExtensionsProps();
      return extensionsProps[extensionId];
    }
  }

  async isAllowAccess(extensionId) {
    if ((typeof extensionId === 'string') && extensionId.length > 0) {
      const extensionsProps = await this.getExtensionsProps();
      const props = extensionsProps[extensionId];
      if (props) {
        return props.allowAccess;
      }
    }

    return false;
  }

  async storeExtensionsProps(props) { // MABXXX an array???
    // MABXXX SHOULD WE REMOVE ALL THE STUFF THAT WE DON'T ALLOW THE USER TO CHANGE - and thus we should always be getting from messenger.management.getAll() ???
    //        - id
    //        - description
    //        - disabled
    //        - shortName
    //        - version
    //        - versionName
    // MABXXX IF AN EXTENSION GETS UNINSTALLED, THUS IT WON'T BE RETURNED FROM messenger.management.getAll(), THESE WILL BE THE LAST-KNOWN VALUES
    //        But uninstalled should be true.
    return messenger.storage.local.set(
      { 'extensionsProps': props }
    );
  }

  async storeExtensionPropsById(extensionId, props) {
    if ((typeof extensionId === 'string') && extensionId.length > 0 && (typeof props === 'object')) {
      // MABXXX SHOULD WE REMOVE ALL THE STUFF THAT WE DON'T ALLOW THE USER TO CHANGE - and thus we should always be getting from messenger.management.getAll???
      //        - id
      //        - description
      //        - disabled
      //        - shortName
      //        - version
      //        - versionName
    // MABXXX IF AN EXTENSION GETS UNINSTALLED, THUS IT WON'T BE RETURNED FROM messenger.management.getAll(), THESE WILL BE THE LAST-KNOWN VALUES
    //        But uninstalled should be true.
      const extensionsProps = await this.getExtensionsProps();
      extensionsProps[extensionId] = props; // MABXXX DANGER!!! THIS COULD CHANGE THE extensionId!!!
      await this.storeExtensionsProps(extensionsProps);
      return extensionsProps[extensionId];
    }
  }



  // Create/Update an extensionProps and return it.
  async addOrUpdateExtension(oldExtensionId, newExtensionId, newExtensionName, newAllowAccess) {
    if (    (! oldExtensionId || (typeof oldExtensionId   === 'string'))
         && (newExtensionId   && (typeof newExtensionId   === 'string') && newExtensionId.length   > 0)
         && (newExtensionName && (typeof newExtensionName === 'string') && newExtensionName.length > 0)
       )
    {
      const allExtensionsProps = await this.getExtensionsProps();

      if (oldExtensionId && oldExtensionId !== newExtensionId) {
        delete allExtensionsProps[oldExtensionId];
      }

      const allowAccess = (typeof newAllowAccess === 'boolean') ? newAllowAccess : true;
      const newProps = {
        'id':          newExtensionId,
        'name':        newExtensionName,
        'allowAccess': allowAccess
      };
      allExtensionsProps[newExtensionId] = newProps;

      await this.storeExtensionsProps(allExtensionsProps);
      return newProps;
    }
  }



  // Delete the extensionProps for the Extension (not the Extension istself)
  // with the given extensionId and return it.
  async removeExtension(extensionId) {
    this.log(`-- begin extensionId="${extensionId}"`);

    let deleted;
    if (extensionId && (typeof extensionId === 'string') && extensionId.length > 0) {
      const allExtensionsProps = await this.getExtensionsProps();
      if (allExtensionsProps) {
        const props = allExtensionsProps[extensionId];
        if (! props) {
        } else {
          this.log(`-- deleting extensionId="${extensionId}"`);
          delete allExtensionsProps[extensionId];
          deleted = props;
          await this.storeExtensionsProps(allExtensionsProps);
        }
      }
    }

    this.log(`-- end extensionId="${extensionId}"`);
    return deleted;
  }

  // Remove the extensionProps for the Extensions with the given extensionIds
  // and return the props of those that were actually deleted
  async removeExtensions(extensionIds, ignoreLocks) {
    var   deletedLocked         = (typeof ignoreLocks) === 'boolean' ? ignoreLocks : false;
    const removedExtensionProps = [];
    var   count                 = 0;

    if (extensionIds && extensionIds.length > 0) {
      const allExtensionsProps = await this.getExtensionsProps();
      if (allExtensionsProps) {
        for (const extensionId of extensionIds) {
          if (extensionId && (typeof extensionId === 'string') && extensionId.length > 0) {
            const props = allExtensionsProps[extensionId];
            if (props) {
              removedExtensionProps.push(props);
              count++;
              delete allExtensionsProps[extensionId];
            }
          }
        }

        if (count > 0) await this.storeExtensionsProps(allExtensionsProps);
      }
    }

    return removedExtensionProps;
  }



  async autoRemoveUninstalledExtensions(numDays) {
    const nowMS            = Date.now();
    const removeBeforeMS   = getMidnightMS(nowMS, -numDays - 1);
    const removeBeforeTime = formatMsToDateTime24HR(removeBeforeMS);
    const parameters       = { 'numDays': numDays, "removeBeforeTime": removeBeforeTime };

    const removedExtensions = [];
    var   removedCount      = 0;

    this.debugAlways(`-- begin -- numDays=${numDays}, removeBeforeMS=${removeBeforeMS}, removeBeforeTime="${removeBeforeTime}"`);

    if (this.fsbEventLogger) {
      await this.fsbEventLogger.logInternalEvent("autoRemoveUninstalledExtensions", "request", parameters, "");
    }

    if (numDays < 0) { // -1: auto-remove is disabled, 0: remove immediately
      this.debugAlways("-- Auto-Remove is Disabled");
      if (this.fsbEventLogger) {
        await this.fsbEventLogger.logInternalEvent("autoRemoveUninstalledExtensions", "success", parameters, "Auto-Remove is Disabled");
      }

    } else {
      const installedExtensionById = [];
      const installedExtensions    = await messenger.management.getAll();
      for (const ext of installedExtensions) {
        installedExtensionById[ext.id] = ext;
      }

      const allExtensionsProps = await this.getExtensionsProps();
      for (const [extensionId, extProps] of Object.entries(allExtensionsProps)) {
        var notInstalled      = false;
        var alreadyRecorded   = false;
        var uninstalledTimeMS = nowMS;

        if (extProps.uninstalled) {
          var installedExtension = installedExtensionById[extensionId];
          if (installedExtension) {
            this.debugAlways(`-- Extension recorded as Uninstalled IS Installed (again?,) ID="${extensionId}"`);
            extProps.uninstalled = false;
            delete extProps['uninstalledTimeMS'];
            delete extProps['uninstalledType'];
            this.debugAlways(`-- Recording Extension as NOT Uninstalled, ID="${extensionId}"`);
            await this.storeExtensionPropsById(extensionId, extProps);
          } else {
            this.debugAlways(`-- Extension already recorded as Uninstalled, ID="${extensionId}"`);
            notInstalled      = true;
            alreadyRecorded   = true;
            uninstalledTimeMS = extProps.uninstalledTimeMS;
          }

        } else {
          var installedExtension = installedExtensionById[extensionId];
          if (installedExtension) {
            this.debugAlways(`-- Extension is still Installed, ID="${extensionId}"`);
          } else {
            this.debugAlways(`-- Extension is no longer Installed, ID="${extensionId}"`);
            notInstalled               = true;
            extProps.uninstalled       = true;
            extProps.uninstalledTimeMS = nowMS;
            extProps.uninstalledType   = 'autoRemoveUninstalledExtensions';
          }
        }

        if (notInstalled) {
          if (numDays == 0 || uninstalledTimeMS < removeBeforeMS) {
            if (numDays == 0) {
              this.debugAlways(`-- Immediately Removing Extension, ID="${extensionId}"`);
            } else {
              this.debugAlways(`-- uninstalledTimeMS=${uninstalledTimeMS} removeBeforeMS=${removeBeforeMS} -- Removing Extension, ID="${extensionId}"`);
            }
            await this.removeExtension(extensionId);
            removedExtenions.push(extensionId);
            ++removedCount;

          } else if (alreadyRecorded) {
            this.debugAlways(`-- Extension already recorded as Uninstalled, ID="${extensionId}"`);
          } else {
            this.debugAlways(`-- Recording Extension as Uninstalled, ID="${extensionId}"`);
            await this.storeExtensionPropsById(extensionId, extProps);
          }
        }
      }
    }

    this.debugAlways(`-- removedCount=${removedCount}`);
    if (this.fsbEventLogger) {
      await this.fsbEventLogger.logInternalEvent("autoRemoveUninstalledExtensions", "success", parameters, `removedCount=${removedCount}`);
    }

    this.debugAlways("-- end");

    return removedExtensions;
  }



  // Set allowAccess=true for the extensionProps for ALL Extensions
  // and return a count of how many were actually changed
  async allowAccessAllExtensions() {
    let count = 0;
    const allExtensionsProps = await this.getExtensionsProps();
    if (allExtensionsProps) {
      for (const [extensionId, props] of Object.entries(allExtensionsProps)) {
        if (props && ! props.allowAccess) {
          count++;
          props.allowAccess = true;
        }
      }
      if (count > 0) await this.storeExtensionsProps(allExtensionsProps);
    }
    return count;
  }

  // Set allowAccess=false for the extensionProps for ALL Extensions
  // and return a count of how many were actually changed
  async disallowAccessAllExtensions() {
    let count = 0;
    const allExtensionsProps = await this.getExtensionsProps();
    if (allExtensionsProps) {
      for (const [extensionId, props] of Object.entries(allExtensionsProps)) {
        if (props && props.allowAccess) {
          count++;
          props.allowAccess = false;
        }
      }
      if (count > 0) await this.storeExtensionsProps(allExtensionsProps);
    }
    return count;
  }



  // Set allowAccess=true for the extensionProps
  // for the Extensions with the given extensionIds
  // and return a count of how many were actually changed
  async allowAccessSelectedExtensions(extensionIds) {
    let count = 0;
    if (extensionIds && extensionIds.length > 0) {
      const allExtensionsProps = await this.getExtensionsProps();
      if (allExtensionsProps) {
        for (const extensionId of extensionIds) {
          if (extensionId && (typeof extensionId === 'string') && extensionId.length > 0) {
            const props = allExtensionsProps[extensionId];
            if (props && ! props.allowAccess) {
              count++;
              props.allowAccess = true;
            }
          }
        }
        if (count > 0) await this.storeExtensionsProps(allExtensionsProps);
      }
    }
    return count;
  }

  // Set allowAccess=false for the extensionProps
  // for the Extensions with the given extensionIds
  // and return a count of how many were actually changed
  async disallowAccessSelectedExtensions(extensionIds) {
    let count = 0;
    if (extensionIds && extensionIds.length > 0) {
      const allExtensionsProps = await this.getExtensionsProps();
      if (allExtensionsProps) {
        for (const extensionId of extensionIds) {
          if (extensionId && (typeof extensionId === 'string') && extensionId.length > 0) {
            const props = allExtensionsProps[extensionId];
            if (props && props.allowAccess) {
              count++;
              props.allowAccess = false;
            }
          }
        }
        if (count > 0) await this.storeExtensionsProps(allExtensionsProps);
      }
    }
    return count;
  }

  async allowAccess(extensionId) {
    this.debug(`-- extensionId="${extensionId}"`);

    if ((typeof extensionId === 'string') && extensionId.length > 0) {
      var installedExtension;
      try {
        installedExtension = await messenger.management.get(extensionId);
      } catch (error) {
        if (! error.message.startsWith("No such addon")) {
          this.caught(error, `Error getting Extension "${extensionId}"`);
        }
      }

      if (! installedExtension) {
        this.error(`-- Extension is not installed, ID="${extensionId}"`);

      } else {
        const props = await this.getExtensionPropsById(extensionId);

        if (props) {
          this.debug(`-- extensionId="${extensionId}" already has props, just change allowAccess and store`);
          props.allowAccess = true;
          await this.storeExtensionPropsById(extensionId, props);
          return true;

        } else {
          this.debug(`-- extensionId="${extensionId}" does not already have props, create new props and store`);

          const newProps = {
            'allowAccess': true,
            'installed':   true,
            'id':          installedExtension.id,
            'description': installedExtension.description,
            'disabled':    ! installedExtension.enabled,
            'name':        installedExtension.name,
            'shortName':   installedExtension.shortName,
            'version':     installedExtension.version,
            'versionName': installedExtension.versionName
          }
          this.debug(`-- extensionId="${extensionId}" New Props:`, newProps);

          await this.storeExtensionPropsById(extensionId, newProps);
          return true;
        }
      }
    }

    return false;
  }

  async disallowAccess(extensionId) {
    this.debug(`-- extensionId="${extensionId}"`);

    if ((typeof extensionId === 'string') && extensionId.length > 0) {
      var installedExtension;
      try {
        installedExtension = await messenger.management.get(extensionId);
      } catch (error) {
        if (! error.message.startsWith("No such addon")) {
          this.caught(error, `Error getting Extentsion "${extensionId}"`);
        }
      }

      if (! installedExtension) {
        this.error(`-- Extension is not installed, ID="${extensionId}"`);

      } else {
        const props = await this.getExtensionPropsById(extensionId);

        if (props) {
          this.debug(`-- extensionId="${extensionId}" already has props, just change allowAccess and store`);
          props.allowAccess = false;
          await this.storeExtensionPropsById(extensionId, props);
          return true;

        } else {
          this.debug(`-- extensionId="${extensionId}" does not already have props, create new props and store`);

          const newProps = {
            'allowAccess': false,
            'installed':   true,
            'id':          installedExtension.id,
            'description': installedExtension.description,
            'disabled':    ! installedExtension.enabled,
            'name':        installedExtension.name,
            'shortName':   installedExtension.shortName,
            'version':     installedExtension.version,
            'versionName': installedExtension.versionName
          }
          this.debug(`-- extensionId="${extensionId}" New Props:`, newProps);

          await this.storeExtensionPropsById(extensionId, newProps);
          return true;
        }
      }
    }

    return false;
  }



  async getWindowBounds(windowName) {
    if (windowName && windowName.length > 0) {
      const allWindowBounds = await this.getOption('windowBounds');
      if (allWindowBounds) return allWindowBounds[windowName];
    }
  }

  async storeWindowBounds(windowName, theWindow) {
    if (windowName && windowName.length > 0 && theWindow) {
      let allWindowBounds = await this.getOption('windowBounds');
      if (! allWindowBounds) allWindowBounds = {};

      const bounds = {
        "top":    theWindow.screenTop,
        "left":   theWindow.screenLeft,
        "width":  theWindow.outerWidth,
        "height": theWindow.outerHeight
      }

      allWindowBounds[windowName] = bounds;

      await this.saveOption('windowBounds', allWindowBounds);

      return bounds;
    }
  }



  /* returns { "fileName": string, "bytesWritten":  number }
   *         { "invalid":  string                          } If the fileName or the full pathName for the file became too long. The returned string gives the reason.
   *         { "error":    string                          } If there was some error writing the file. The returned string gives the reason.
   */
  async backupToFile() {
    const fileName = formatNowToDateTimeForFilename() + this.BACKUP_FILENAME_EXTENSION;

    try {
      const allOptions = await this.getAllOptions();

      if (this.DEBUG) {
        this.debugAlways(`-- Backing up all options to file "${fileName}"`);
        this.debugAlways("-- Backing up", allOptions);
        logProps("", "allOptions", allOptions);
      }
      const response = await this.fsBrokerApi.writeObjectToJSONFile(fileName, allOptions);
      this.debug(`--response: "${response}"`);

      return response;

    } catch (error) {
      this.caught(error, `-- Failed to write options backup file "${fileName}"`);
      return { "error": error.name + ": " + error.message };
    }
  }

  /* returns { "fileNames": [],    "length": number }
   *         { "error":     string                   } If there was some error writing the file. The returned string gives the reason.
   */
  async listBackupFiles() {
    try {
      this.debug(`-- Getting list of options backup files with matchGlob "${this.BACKUP_FILENAME_MATCH_GLOB}"`);
      const response = await this.fsBrokerApi.listFiles(this.BACKUP_FILENAME_MATCH_GLOB);
      this.debug(`--response: "${response}"`);

      return response;

    } catch (error) {
      this.caught(error, "-- Failed to get list of options backup files");
      return { "error": error.name + ": " + error.message };
    }
  }

  /* returns { "fileInfo": [],    "length": number } array of IOUtils.FileInfo - see the FileSystemBroker API README file
   *         { "error":    string                  } If there was some error writing the file. The returned string gives the reason.
   */
  async listBackupFileInfo() {
    try {
      this.debug(`-- Getting list of options backup files with matchGlob "${this.BACKUP_FILENAME_MATCH_GLOB}"`);
      const response = await this.fsBrokerApi.listFileInfo(this.BACKUP_FILENAME_MATCH_GLOB);
      this.debug(`--response: "${response}"`);

      return response;

    } catch (error) {
      this.caught(error, "-- Failed to get list info for options backup files");
      return { "error": error.name + ": " + error.message };
    }
  }

  /* returns { "fileName": string, "data": object } javascript object
   *         { "invalid":  string                 } If the fileName is invalid or the full pathName for the file became too long. The returned string gives the reason.
   *         { "error":    string                 } If there was some error reading the file. The returned string gives the reason.
   */
  async readBackupFile(fileName) {
    try {
      this.debug(`-- Reading options backup file "${fileName}"`);
      const response = await this.fsBrokerApi.readObjectFromJSONFile(fileName);
      this.debug(`--response: "${response}"`);

      return response;

    } catch (error) {
      this.caught(error, `-- Failed to read options backup file "${fileName}"`);
      return { "error": error.name + ": " + error.message };
    }
  }

  /* returns { "fileName": string, "object": object } (all options)
   *         { "invalid":  string                   } If the fileName is invalid or the full pathName for the file became too long. The returned string gives the reason.
   *         { "error":    string                   } If there was some error reading the file or restoring options. The returned string gives the reason.
   */
  async readOptionsFromBackupAndRestore(fileName) {
    this.debug(`-- Reading options backup file "${fileName}"`);

    const response = await this.readBackupFile(fileName);

    if (response && response.object) {
      if (this.DEBUG) {
        this.debug(`-- readBackupFile "${fileName}" -- DATA RETURNED:`);
        logProps("", "readOptionsFromBackupAndRestore", response.object);
      }

      // sanity checks on the data?

      try {
        await messenger.storage.local.set(response.object);
      } catch (error) {
        this.caught(`-- Failed to restore options from file "${fileName}" -- messenger.storage.local.set() failed`);
        return { "error": `Failed to restore options from file "${fileName}" --  messenger.storage.local.set() failed` };
      }
    }

    return response;
  }

  /* returns object (all options)
   *
   * throws if unable to read backup file
   * or if unable to restore the options into local storage
   */
  async getOptionsFromBackupAndRestore(fileName) {
    this.debug(`-- Reading options backup file "${fileName}"`);

    const response = await this.readBackupFile(fileName);

    if (! response) {
      this.error(`-- readBackupFile "${fileName}" -- READ FILE ERROR: NO RESPONSE FROM FileSystemBroker`);
      throw new Error(`readBackupFile "${fileName}" -- READ FILE ERROR: NO RESPONSE FROM FileSystemBroker`);
    } else if (response.invalid) {
      this.error(`-- readBackupFile "${fileName}" -- READ FILE ERROR: ${response.invalid}`);
      throw new Error(`readBackupFile "${fileName}" -- READ FILE ERROR: ${response.invalid}`);
    } else if (response.error) {
      this.error(`-- readBackupFile "${fileName}" -- READ FILE ERROR: ${response.error}`);
      throw new Error(`readBackupFile "${fileName}" -- READ FILE ERROR: ${response.error}`);
    } else if (! response.fileName) {
      this.error(`-- readBackupFile "${fileName}" -- NO FILENAME RETURNED`);
      throw new Error(`readBackupFile "${fileName}" -- NO FILENAME RETURNED`);
    } else if (! response.object) {
      this.error(`-- readBackupFile "${fileName}" -- NO DATA RETURNED`);
      throw new Error(`readBackupFile "${fileName}" -- NO DATA RETURNED`);
    }

    if (this.DEBUG) {
      this.debugAlways(`-- readBackupFile "${fileName}" -- DATA RETURNED:`);
      logProps("", "getOptionsFromBackupAndRestore", response.object);
    }

    // sanity checks on the data?

    try {
      await messenger.storage.local.set(response.object);
    } catch (error) {
      this.caught(`-- Failed to restore options from file "${fileName}" -- messenger.storage.local.set() failed`);
      throw new Error(`Failed to restore options from file "${fileName}" --  messenger.storage.local.set() failed`);
    }

    return response.object;
  }

  /* returns { "fileName": string, "deleted": boolean }
   *         { "invalid":  string                     } If the fileName is invalid or the full pathName for the file became too long. The returned string gives the reason.
   *         { "error":    string                     } If there was some error deleting the file. The returned string gives the reason.
   */
  async deleteBackupFile(fileName) {
    try {
      this.debug(`-- Deleting options backup file "${fileName}"`);
      const response = await this.fsBrokerApi.deleteFile(fileName);
      this.debug(`--response: "${response}"`);

      return response;

    } catch (error) {
      this.caught(error, `--  Failed to delete options backup file "${fileName}"`);
      return { "error": error.name + ": " + error.message };
    }
  }
}
