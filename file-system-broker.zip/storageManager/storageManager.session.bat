start "" gvim -S storageManager.css.session.vim
start "" gvim -S storageManager.html.session.vim
start "" gvim -S storageManager.js.session.vim
exit
