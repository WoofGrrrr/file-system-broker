start "" gvim -S extensionChooserUI.css.session.vim
start "" gvim -S extensionChooserUI.html.session.vim
start "" gvim -S extensionChooserUI.js.session.vim
exit
