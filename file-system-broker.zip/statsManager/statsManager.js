import { Logger              } from '../modules/logger.js';
import { FsbOptions          } from '../modules/options.js';
import { FileSystemBrokerAPI } from '../modules/FileSystemBroker/filesystem_broker_api.js';
import { getI18nMsg, getI18nMsgSubst, formatMsToDateTime24HR , formatMsToDateTime12HR } from '../modules/utilities.js';




class StatsManager {
  #CLASS_NAME    = this.constructor.name;

  #INFO          = false;
  #LOG           = false;
  #DEBUG         = false;
  #WARN          = false;

  #IGNORE_DIRECTORY_NAMES = [ '.tmp.drivedownload', '.tmp.driveupload' ]; // these directories are created by Google Drive

  #logger        = new Logger();
  #fsbOptionsApi = new FsbOptions(this.logger);
  #fsBrokerApi   = new FileSystemBrokerAPI();

  //// don't need to do any of this this because we aren't using options that need FsbEventLogger
//fsbCommandsApi = new FileSystemBrokerCommands(this.logger, this.fsbOptionsApi);
//fsbEventLogger = new FsbEventLogger(this.logger, this.fsbOptionsApi, this.fsbCommandsApi); // <---- this is why we new fsbCommandsApi 
//#fsbOptionsApi.setEventLogger(this.#fsbEventLogger);
//fsbCommandsApi.setEventLogger(this.fsbEventLogger);
  

  // internal state
  #canceled = false;


  #listHeaderText_dirName                    = getI18nMsg( "fsbStatsManager_directoryListHeader_directoryName",              "Directory Name"     );
  #listHeaderText_dirPathName                = getI18nMsg( "fsbStatsManager_directoryListHeader_directoryName",              "Directory PathName" );
  #listHeaderText_extensionId                = getI18nMsg( "fsbStatsManager_directoryListHeader_extensionId",                "Extension ID"       );
  #listHeaderText_extensionInstalled         = getI18nMsg( "fsbStatsManager_directoryListHeader_extensionInstalled",         "I?"                 );
  #listHeaderText_extensionEnabled           = getI18nMsg( "fsbStatsManager_directoryListHeader_extensionEnabled",           "E?"                 );
  #listHeaderText_extensionConfigured        = getI18nMsg( "fsbStatsManager_directoryListHeader_extensionConfigured",        "C?"                 );
  #listHeaderText_extensionAccessAllowed     = getI18nMsg( "fsbStatsManager_directoryListHeader_extensionAccessAllowed",     "A?"                 );

  #listHeaderText_count_children             = getI18nMsg( "fsbStatsManager_directoryListHeader_count_children",             "#I"                 );
  #listHeaderText_count_regular              = getI18nMsg( "fsbStatsManager_directoryListHeader_count_type_regular",         "#R"                 );
  #listHeaderText_count_directory            = getI18nMsg( "fsbStatsManager_directoryListHeader_count_type_directory",       "#D"                 );
  #listHeaderText_count_other                = getI18nMsg( "fsbStatsManager_directoryListHeader_count_type_other",           "#O"                 );
  #listHeaderText_count_unknown              = getI18nMsg( "fsbStatsManager_directoryListHeader_count_type_unknown",         "#U"                 );
  #listHeaderText_count_error                = getI18nMsg( "fsbStatsManager_directoryListHeader_count_type_error",           "#E"                 );

  #listHeaderText_time_creation_earliest     = getI18nMsg( "fsbStatsManager_directoryListHeader_time_creation_earliest",     ""                   );
  #listHeaderText_time_creation_latest       = getI18nMsg( "fsbStatsManager_directoryListHeader_time_creation_latest",       ""                   );
  #listHeaderText_time_lastAccessed_earliest = getI18nMsg( "fsbStatsManager_directoryListHeader_time_lastAccessed_earliest", ""                   );
  #listHeaderText_time_lastAccessed_latest   = getI18nMsg( "fsbStatsManager_directoryListHeader_time_lastAccessed_latest",   ""                   );
  #listHeaderText_time_lastModified_earliest = getI18nMsg( "fsbStatsManager_directoryListHeader_time_lastModified_earliest", ""                   );
  #listHeaderText_time_lastModified_latest   = getI18nMsg( "fsbStatsManager_directoryListHeader_time_lastModified_latest",   ""                   );

  #listHeaderText_size_smallest              = getI18nMsg( "fsbStatsManager_directoryListHeader_size_smallest",              ""                   );
  #listHeaderText_size_largest               = getI18nMsg( "fsbStatsManager_directoryListHeader_size_largest",               ""                   );
  #listHeaderText_size_total                 = getI18nMsg( "fsbStatsManager_directoryListHeader_size_total",                 ""                   );


  #listHeaderTooltip_dirName                    = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_directoryName",              "Directory Name"                );
  #listHeaderTooltip_dirPathName                = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_directoryName",              "Directory PathName"            );
  #listHeaderTooltip_extensionId                = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_extensionId",                "Extension ID"                  );
  #listHeaderTooltip_extensionInstalled         = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_extensionInstalled",         "Installed?"                    );
  #listHeaderTooltip_extensionEnabled           = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_extensionEnabled",           "Enabled?"                      );
  #listHeaderTooltip_extensionConfigured        = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_extensionConfigured",        "Configured?"                   );
  #listHeaderTooltip_extensionAccessAllowed     = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_extensionAccessAllowed",     "Access Allowed?"               );

  #listHeaderTooltip_count_children             = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_count_children",             "Number of Items"               );
  #listHeaderTooltip_count_regular              = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_count_type_regular",         "Number of Regular Files"       );
  #listHeaderTooltip_count_directory            = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_count_type_directory",       "Number of Directories"         );
  #listHeaderTooltip_count_other                = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_count_type_other",           "Number of Other Items"         );
  #listHeaderTooltip_count_unknown              = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_count_type_unknown",         "Number of Unknown"             );
  #listHeaderTooltip_count_error                = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_count_type_error",           "Number of Errors getting Type" );

  #listHeaderTooltip_time_creation_earliest     = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_time_creation_earliest",     "Earliest Creation Time"        );
  #listHeaderTooltip_time_creation_latest       = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_time_creation_latest",       "Latest Creation Time"          );
  #listHeaderTooltip_time_lastAccessed_earliest = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_time_lastAccessed_earliest", "Earliest Last Accessed Time"   );
  #listHeaderTooltip_time_lastAccessed_latest   = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_time_lastAccessed_latest",   "Latest Last Accessed Time"     );
  #listHeaderTooltip_time_lastModified_earliest = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_time_lastModified_earliest", "Earliest Last MOdified Time"   );
  #listHeaderTooltip_time_lastModified_latest   = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_time_lastModified_latest",   "Latest Last MOdified Time"     );

  #listHeaderTooltip_size_smallest              = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_size_smallest",              "Smallest Regular File"         );
  #listHeaderTooltip_size_largest               = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_size_largest",               "Largest Regular File"          );
  #listHeaderTooltip_size_total                 = getI18nMsg( "fsbStatsManager_directoryListHeader_tooltip_size_total",                 "Total of Regular File sizes"   );



  constructor() {
  }



  info(...info) {
    if (this.#INFO) this.#logger.info(this.#CLASS_NAME, ...info);
  }

  infoAlways(...info) {
    this.#logger.infoAlways(this.#CLASS_NAME, ...info);
  }

  log(...info) {
    if (this.#LOG) this.#logger.log(this.#CLASS_NAME, ...info);
  }

  logAlways(...info) {
    this.#logger.logAlways(this.#CLASS_NAME, ...info);
  }

  debug(...info) {
    if (this.#DEBUG) this.#logger.debug(this.#CLASS_NAME, ...info);
  }

  debugAlways(...info) {
    this.#logger.debugAlways(this.#CLASS_NAME, ...info);
  }

  warn(...info) {
    if (this.#WARN) this.#logger.warn(this.#CLASS_NAME, ...info);
  }

  warnAlways(...info) {
    this.#logger.warnAlways(this.#CLASS_NAME, ...info);
  }

  error(...info) {
    // always log errors
    this.#logger.error(this.#CLASS_NAME, ...info);
  }
  
  caught(e, msg, ...info) {
    // always log exceptions
    this.#logger.error( this.#CLASS_NAME,
                       msg,
                       "\n- name:    " + e.name,
                       "\n- message: " + e.message,
                       "\n- stack:   " + e.stack,
                       ...info
                     );
  }



  async run(e) {
    this.debug("-- begin");

    window.addEventListener("beforeunload", (e) => this.windowUnloading(e));

    const showInstructions = await this.#fsbOptionsApi.isEnabledShowStatsManagerInstructions();
    this.showHideInstructions(showInstructions);

    await this.updateOptionsUI();
//  await updateStatsManagerUI() {
    await this.localizePage();
    await this.buildDirectoryListUI();
    this.setupEventListeners();
  }



  setupEventListeners() {
    document.addEventListener( "change", (e) => this.optionChanged(e) );   // One of the checkboxes or radio buttons was clicked or a select has changed

    const doneBtn = document.getElementById("fsbStatsManagerDoneButton");
    if (! doneBtn) {
      this.error("Failed to get element '#fsbStatsManagerDoneButton'");
    } else {
      doneBtn.addEventListener("click", (e) => this.doneButtonClicked(e));
    }

    const refreshBtn = document.getElementById("fsbStatsManagerRefreshButton");
    if (! refreshBtn) {
      this.error("Failed to get element '#fsbStatsManagerRefreshButton'");
    } else {
      refreshBtn.addEventListener("click", (e) => this.refreshButtonClicked(e));
    }

    const deleteBtn = document.getElementById("fsbStatsManagerDeleteButton");
    if (! deleteBtn) {
      this.error("Failed to get element '#fsbStatsManagerDeleteButton'");
    } else {
      deleteBtn.addEventListener("click", (e) => this.deleteButtonClicked(e));
    }
  }



  async localizePage() {
    this.debug("-- start");

    for (const el of document.querySelectorAll("[data-l10n-id]")) {
      const id = el.getAttribute("data-l10n-id");
      let i18nMessage = browser.i18n.getMessage(id);
      if (i18nMessage == "") {
        i18nMessage = id;
      }
      el.textContent = i18nMessage;
    }

    for (const el of document.querySelectorAll("[data-html-l10n-id]")) {
      const id = el.getAttribute("data-html-l10n-id");
      let i18nMessage = browser.i18n.getMessage(id);
      if (i18nMessage == "") {
        i18nMessage = id;
      }
      el.insertAdjacentHTML('afterbegin', i18nMessage);
    }

    this.debug("-- end");
  }



  async updateOptionsUI() {
    this.debug("-- start");

    const options = await this.#fsbOptionsApi.getAllOptions();

    this.debug("-- sync options to UI");
    for (const [optionName, optionValue] of Object.entries(options)) {
      this.debug("-- option: ", optionName, "value: ", optionValue);

      if (this.#fsbOptionsApi.isDefaultOption(optionName)) { // MABXXX WHY WHY WHY???
        const optionElement = document.getElementById(optionName);

        if (optionElement && optionElement.classList.contains("fsbGeneralOption")) {
          if (optionElement.tagName === 'INPUT') {
            if (optionElement.type === 'checkbox') {
              optionElement.checked = optionValue;
            } else if (optionElement.type === 'radio') {
              optionElement.value = optionValue;
            } else if (optionElement.type === 'text') {
              // MABXXX we don't handle this yet...
              optionElement.value = optionValue;
            }
          } else if (optionElement.tagName === 'SELECT') {
            optionElement.value = optionValue;
          }
        }
      }
    }

    this.debug("-- end");
  }



  // One of the Options checkboxes or radio buttons (etc) has been clicked or a select has changed
  //
  // copied from optionsUI.js, so this does a lot that we don't really need for now.
  async optionChanged(e) {
    if (e == null) return;
    this.debug(`-- tagName="${e.target.tagName}" type="${e.target.type}" fsbGeneralOption? ${e.target.classList.contains("fsbGeneralOption")} id="${e.target.id}"`);

    var target = e.target;
    if ( target.tagName == "INPUT"
         && target.classList.contains("fsbGeneralOption")
         && ( target.type == "checkbox"
              || target.type == "radio"
            )
       )
    {
      const optionName  = target.id;
      const optionValue = target.checked;

      /* if it's a radio button, set the values for all the other buttons in the group to false */
      if (target.type == "radio") { // is it a radio button?
        this.debug(`-- radio buttton selected ${optionName}=<${optionValue}> - group=${target.name}`);

        // first, set this option
        this.debug(`-- Setting Radio Option {[${optionName}]: ${optionValue}}`);
        await this.#fsbOptionsApi.storeOption(
          { [optionName]: optionValue }
        );

        // get all the elements with the same name, and if they're a radio, un-check them
        if (target.name) { /* && (optionValue == true || optionValue == 'true')) { Don't need this. Event fired *ONLY* when SELECTED, i.e. true */
          const radioGroupName = target.name;
          const radioGroup = document.querySelectorAll(`input[type="radio"][name="${radioGroupName}"]`);
          if (! radioGroup) {
            this.debug('-- no radio group found');
          } else {
            this.debug(`-- radio group members length=${radioGroup.length}`);
            if (radioGroup.length < 2) {
              this.debug('-- no radio group members to reset (length < 2)');
            } else {
              for (const radio of radioGroup) {
                if (radio.id != optionName) { // don't un-check the one that fired
                  this.debug(`-- resetting radio button {[${radio.id}]: false}`);
                  await this.#fsbOptionsApi.storeOption(
                    { [radio.id]: false }
                  );
                }
              }
            }
          }
        }
      } else { // since we already tested for it, it's got to be a checkbox
        this.debug(`-- Setting Checkbox Option {[${optionName}]: ${optionValue}}`);
        await this.#fsbOptionsApi.storeOption(
          { [optionName]: optionValue }
        );

        // special processing for these checkboxes
        switch (optionName) {
          case "fsbShowStatsManagerInstructions": 
            this.showHideInstructions(optionValue);
            break;
        }
      }
    } else if ( target.tagName === 'SELECT'
                && target.classList.contains("fsbGeneralOption")
              )
    {
      const optionName  = target.id;
      const optionValue = target.value;

      this.debug(`-- Setting Select Option {[${optionName}]: ${optionValue}}`);
      await this.#fsbOptionsApi.storeOption(
        { [optionName]: optionValue }
      );
    }
  }



  showHideInstructions(show) {
    this.debug(`-- show=${show}`);
    const panel = document.getElementById("fsbStatsManagerInstructions");
    if (panel) {
      if (show) {
        panel.style.setProperty('display', 'block');
      } else {
        panel.style.setProperty('display', 'none');
      }
    }
  }
  


  async updateStatsManagerUI() {
  }
  


  async windowUnloading(e) {
    if (this.DEBUG) this.debugAlways( "--- Window Unloading ---"
                                      + `\n- window.screenTop=${window.screenTop}`
                                      + `\n- window.screenLeft=${window.screenLeft}`
                                      + `\n- window.outerWidth=${window.outerWidth}`
                                      + `\n- window.outerHeight=${window.outerHeight}`
                                      + `\n- this.#canceled=${this.#canceled}`
                                    );
    await this.#fsbOptionsApi.storeWindowBounds("statsManagerWindowBounds", window);

    if (this.DEBUG) {
      let bounds = await this.#fsbOptionsApi.getWindowBounds("statsManagerWindowBounds");

      if (! bounds) {
        this.debugAlways("--- WINDOW UNLOADING --- Retrieve Stored Window Bounds --- FAILED TO GET Stats Manager Window Bounds ---");
      } else if (typeof bounds !== 'object') {
        this.debugAlways(`--- WINDOW UNLOADING --- Retrieve Stored Window Bounds --- Stats Manager Window Bounds IS NOT AN OBJECT: typeof='${typeof bounds}' ---`);
      } else {
        this.debugAlways( "--- Retrieve Stored Window Bounds ---"
                          + `\n- bounds.top:    ${bounds.top}`
                          + `\n- bounds.left:   ${bounds.left}`
                          + `\n- bounds.width:  ${bounds.width}`
                          + `\n- bounds.height: ${bounds.height}`
                        );
      }
    }

    // Tell Thunderbird to close the window
    e.returnValue = '';  // any "non-truthy" value will do
    return false;
  }



  async buildDirectoryListUI() {
    this.resetMessages();
    this.resetErrors();

    const domDirectoryList = document.getElementById("fsbStatsManagerDirectoryList");
    if (! domDirectoryList) {
      this.error("-- failed to get element #fsbStatsManagerDirectoryList");
      this.setErrorFor("fsbStatsManagerTitlePanel", fsbStatsManager_error_noDirectoryListElement);
      return;
    }

    domDirectoryList.innerHTML = '';
    this.updateUIOnSelectionChanged();

    const i18nMessage = getI18nMsg("fsbStatsManager_message_directoryListLoading", "...");
    const loadingTR = document.createElement("tr");
    loadingTR.classList.add("data-loading-message");
    loadingTR.appendChild( document.createTextNode(i18nMessage) ); // you can put a text node in a TR ???
    domDirectoryList.appendChild(loadingTR);

    const stats = await this.getFsbStats();
    this.debug("---stats\n", stats);
    const fsbStats    = stats?.fsbStats
    const fsbDirStats = stats?.dirStats

    var noDirectoriesErrorReported = false;
    if (! fsbDirStats) {
      this.error("---NO fsbDirStats");
      this.setErrorFor("fsbStatsManagerTitlePanel", fsbStatsManager_error_noDirectories);
      noDirectoriesErrorReported = true;
    } else if (Object.keys(fsbDirStats).length < 1) {
      this.error("---fsbDirStats.length < 1");
      this.setErrorFor("fsbStatsManagerTitlePanel", fsbStatsManager_error_noDirectories);
      noDirectoriesErrorReported = true;
    } else {
      for (const dirName of Object.keys(fsbDirStats)) {
        if (this.#IGNORE_DIRECTORY_NAMES.includes(dirName)) {
          this.debugAlways(`---IGNORING DIRECTORY "${dirName}"`);
          delete fsbDirStats[dirName];
        }
      }
    }

    domDirectoryList.innerHTML = '';

    const headerItemUI = this.buildDirectoryListHeaderUI();
    domDirectoryList.append(headerItemUI);

    if (Object.keys(fsbDirStats).length < 1) { // DO THIS AGAIN AFTER REMOVAL OF ANY IGNORED DIRECTORY NAMES
      if (! noDirectoriesErrorReported) {
        this.error("---fsbDirStats.length < 1");
        this.setErrorFor("fsbStatsManagerTitlePanel", fsbStatsManager_error_noDirectories);
        noDirectoriesErrorReported = true;
      }
    } else {
      const installedExtensions = await messenger.management.getAll();
      const extensionsProps     = await this.#fsbOptionsApi.getExtensionsProps();;
      const sortedKeys          = Object.keys(fsbDirStats).sort((a, b) => { return a.localeCompare( b, undefined, {'sensitivity': 'base'} ) } );

      for (const key of sortedKeys) {
        const dirStats       = fsbDirStats[key];
        var   extensionInfo  = null;
        var   extensionProps = null;

        if (installedExtensions) {
          extensionInfo = installedExtensions.find( extension =>
            {
              return (extension.type === 'extension' && extension.id === dirStats.dirName);
            }
          );  
          this.debug("---extensionInfo\n", extensionInfo);
        }

        if (extensionsProps) {
          extensionProps = (extensionsProps && dirStats.dirName in extensionsProps) ? extensionsProps[dirStats.dirName] : null;
          this.debug("---extensionProps\n", extensionProps);
        }

        const listItemUI = await this.buildDirectoryListItemUI(dirStats, extensionInfo, extensionProps);
        domDirectoryList.append(listItemUI);
      }
    }
  }



  buildDirectoryListHeaderUI() {
    this.debug("-- BUILD LIST HEADER UI");

    const dirHeaderTR = document.createElement("tr");
      dirHeaderTR.classList.add("directory-list-header"); // directory-list-header

      // Create Directory Name element and add it to the row
      const dirNameTH = document.createElement("th");
        dirNameTH.classList.add("list-header-data");  // directory-list-header > list-header-data
        dirNameTH.classList.add("header-name");       // directory-list-header > header-name
        dirNameTH.appendChild( document.createTextNode(this.#listHeaderText_dirName) );
        dirNameTH.setAttribute("title", this.#listHeaderTooltip_dirName);
      dirHeaderTR.appendChild(dirNameTH);

      // Create Extension ID element and add it to the row
      const extIdTH = document.createElement("th");
        extIdTH.classList.add("list-header-data");  // directory-list-header > list-header-data
        extIdTH.classList.add("header-ext-id");    // directory-list-header > header-ext-id
        extIdTH.appendChild( document.createTextNode(this.#listHeaderText_extensionId) );
        extIdTH.setAttribute("title", this.#listHeaderTooltip_extensionId);
      dirHeaderTR.appendChild(extIdTH);

      // Create Extension Installed element and add it to the row
      const extInstalledTH = document.createElement("th");
        extInstalledTH.classList.add("list-header-data");      // directory-list-header > list-header-data
        extInstalledTH.classList.add("header-ext-installed");  // directory-list-header > header-ext-installed
        extInstalledTH.appendChild( document.createTextNode(this.#listHeaderText_extensionInstalled) );
        extInstalledTH.setAttribute("title", this.#listHeaderTooltip_extensionInstalled);
      dirHeaderTR.appendChild(extInstalledTH);

      // Create Extension Enabled element and add it to the row
      const extEnabledTH = document.createElement("th");
        extEnabledTH.classList.add("list-header-data");     // directory-list-header > list-header-data
        extEnabledTH.classList.add("header-ext-enabled");  // directory-list-header > header-ext-enabled
        extEnabledTH.appendChild( document.createTextNode(this.#listHeaderText_extensionEnabled) );
        extEnabledTH.setAttribute("title", this.#listHeaderTooltip_extensionEnabled);
      dirHeaderTR.appendChild(extEnabledTH);

      // Create Extension Configured element and add it to the row
      const extConfiguredTH = document.createElement("th");
        extConfiguredTH.classList.add("list-header-data");        // directory-list-header > list-header-data
        extConfiguredTH.classList.add("header-ext-configured");  // directory-list-header > header-ext-configured
        extConfiguredTH.appendChild( document.createTextNode(this.#listHeaderText_extensionConfigured) );
        extConfiguredTH.setAttribute("title", this.#listHeaderTooltip_extensionConfigured);
      dirHeaderTR.appendChild(extConfiguredTH);

      // Create Extension Access Allowed element and add it to the row
      const extAccessAllowedTH = document.createElement("th");
        extAccessAllowedTH.classList.add("list-header-data");        // directory-list-header > list-header-data
        extAccessAllowedTH.classList.add("header-ext-access");  // directory-list-header > header-ext-access
        extAccessAllowedTH.appendChild( document.createTextNode(this.#listHeaderText_extensionAccessAllowed) );
        extAccessAllowedTH.setAttribute("title", this.#listHeaderTooltip_extensionAccessAllowed);
      dirHeaderTR.appendChild(extAccessAllowedTH);

      // Create Child Count element and add it to the row
      const childCountTH = document.createElement("th");
        childCountTH.classList.add("list-header-data");       // directory-list-header > list-header-data
        childCountTH.classList.add("header-count-children");  // directory-list-header > header-count-children
        childCountTH.appendChild( document.createTextNode(this.#listHeaderText_count_children) );
        childCountTH.setAttribute("title", this.#listHeaderTooltip_count_children);
      dirHeaderTR.appendChild(childCountTH);

      // Create Child Type egular' Count element and add it to the row
      const regularCountTH = document.createElement("th");
        regularCountTH.classList.add("list-header-data");      // directory-list-header > list-header-data
        regularCountTH.classList.add("header-count-regular");  // directory-list-header > header-count-regular
        regularCountTH.appendChild( document.createTextNode(this.#listHeaderText_count_regular) );
        regularCountTH.setAttribute("title", this.#listHeaderTooltip_count_regular);
      dirHeaderTR.appendChild(regularCountTH);

      // Create Child Type 'directory' Count element and add it to the row
      const directoryCountTH = document.createElement("th");
        directoryCountTH.classList.add("list-header-data");        // directory-list-header > list-header-data
        directoryCountTH.classList.add("header-count-directory");  // directory-list-header > header-count-directory
        directoryCountTH.appendChild( document.createTextNode(this.#listHeaderText_count_directory) );
        directoryCountTH.setAttribute("title", this.#listHeaderTooltip_count_directory);
      dirHeaderTR.appendChild(directoryCountTH);

      // Create Child Type 'other' Count element and add it to the row
      const otherCountTH = document.createElement("th");
        otherCountTH.classList.add("list-header-data");    // directory-list-header > list-header-data
        otherCountTH.classList.add("header-count-other");  // directory-list-header > header-count-other
        otherCountTH.appendChild( document.createTextNode(this.#listHeaderText_count_other) );
        otherCountTH.setAttribute("title", this.#listHeaderTooltip_count_other);
      dirHeaderTR.appendChild(otherCountTH);

      // Create Child Type unknown Count element and add it to the row
      const unknownCountTH = document.createElement("th");
        unknownCountTH.classList.add("list-header-data");      // directory-list-header > list-header-data
        unknownCountTH.classList.add("header-count-unknown");  // directory-list-header > header-count-unknown
        unknownCountTH.appendChild( document.createTextNode(this.#listHeaderText_count_unknown) );
        unknownCountTH.setAttribute("title", this.#listHeaderTooltip_count_unknown);
      dirHeaderTR.appendChild(unknownCountTH);

      // Create Child Type error Count element and add it to the row
      const errorCountTH = document.createElement("th");
        errorCountTH.classList.add("list-header-data");    // directory-list-header > list-header-data
        errorCountTH.classList.add("header-count-error");  // directory-list-header > header-count-error
        errorCountTH.appendChild( document.createTextNode(this.#listHeaderText_count_error) );
        errorCountTH.setAttribute("title", this.#listHeaderTooltip_count_error);
      dirHeaderTR.appendChild(errorCountTH);

      // Create Earliest Creation Time element and add it to the row
      const timeCreationEarliestTH = document.createElement("th");
        timeCreationEarliestTH.classList.add("list-header-data");               // directory-list-header > list-header-data
        timeCreationEarliestTH.classList.add("header-time-creation-earliest");  // directory-list-header > header-time-creation-earliest
        timeCreationEarliestTH.appendChild( document.createTextNode(this.#listHeaderText_time_creation_earliest) );
        timeCreationEarliestTH.setAttribute("title", this.#listHeaderTooltip_time_creation_earliest);
      dirHeaderTR.appendChild(timeCreationEarliestTH);

      // Create Latest Creation Time element and add it to the row
      const timeCreationLatestTH = document.createElement("th");
        timeCreationLatestTH.classList.add("list-header-data");             // directory-list-header > list-header-data
        timeCreationLatestTH.classList.add("header-time-creation-latest");  // directory-list-header > header-time-creation-latest
        timeCreationLatestTH.appendChild( document.createTextNode(this.#listHeaderText_time_creation_latest) );
        timeCreationLatestTH.setAttribute("title", this.#listHeaderTooltip_time_creation_latest);
      dirHeaderTR.appendChild(timeCreationLatestTH);

      // Create Earliest Last Accessed Time element and add it to the row
      const timeLastAccessedEarliestTH = document.createElement("th");
        timeLastAccessedEarliestTH.classList.add("list-header-data");                     // directory-list-header > list-header-data
        timeLastAccessedEarliestTH.classList.add("header-time-last-accessed-earliest");   // directory-list-header > header-time-last-accessed-earliest
        timeLastAccessedEarliestTH.appendChild( document.createTextNode(this.#listHeaderText_time_lastAccessed_earliest) );
        timeLastAccessedEarliestTH.setAttribute("title", this.#listHeaderTooltip_time_lastAccessed_earliest);
      dirHeaderTR.appendChild(timeLastAccessedEarliestTH);

      // Create Latest Last Accessed Time element and add it to the row
      const timeLastAccessedLatestTH = document.createElement("th");
        timeLastAccessedLatestTH.classList.add("list-header-data");                  // directory-list-header > list-header-data
        timeLastAccessedLatestTH.classList.add("header-time-last-accessed-latest");  // directory-list-header > header-time-last-accessed-latest
        timeLastAccessedLatestTH.appendChild( document.createTextNode(this.#listHeaderText_time_lastAccessed_latest) );
        timeLastAccessedLatestTH.setAttribute("title", this.#listHeaderTooltip_time_lastAccessed_latest);
      dirHeaderTR.appendChild(timeLastAccessedLatestTH);

      // Create Earliest Last Modified Time element and add it to the row
      const timeLastModifiedEarliestTH = document.createElement("th");
        timeLastModifiedEarliestTH.classList.add("list-header-data");                    // directory-list-header > list-header-data
        timeLastModifiedEarliestTH.classList.add("header-time-last-modified-earliest");  // directory-list-header > header-time-last-modified-earliest
        timeLastModifiedEarliestTH.appendChild( document.createTextNode(this.#listHeaderText_time_lastModified_earliest) );
        timeLastModifiedEarliestTH.setAttribute("title", this.#listHeaderTooltip_time_lastModified_earliest);
      dirHeaderTR.appendChild(timeLastModifiedEarliestTH);

      // Create Latest Last Modified Time element and add it to the row
      const timeLastModifiedLatestTH = document.createElement("th");
        timeLastModifiedLatestTH.classList.add("list-header-data");                  // directory-list-header > list-header-data
        timeLastModifiedLatestTH.classList.add("header-time-last-modified-latest");  // directory-list-header > header-time-last-modified-latest
        timeLastModifiedLatestTH.appendChild( document.createTextNode(this.#listHeaderText_time_lastModified_latest) );
        timeLastModifiedLatestTH.setAttribute("title", this.#listHeaderTooltip_time_lastModified_latest);
      dirHeaderTR.appendChild(timeLastModifiedLatestTH);

      // Create Smallest Size element and add it to the row
      const sizeSmallestTH = document.createElement("th");
        sizeSmallestTH.classList.add("list-header-data");     // directory-list-header > list-header-data
        sizeSmallestTH.classList.add("header-size-smallest"); // directory-list-header > header-size-smallest
        sizeSmallestTH.appendChild( document.createTextNode(this.#listHeaderText_size_smallest) );
        sizeSmallestTH.setAttribute("title", this.#listHeaderTooltip_size_smallest);
      dirHeaderTR.appendChild(sizeSmallestTH);

      // Create Largest Size element and add it to the row
      const sizeLargestTH = document.createElement("th");
        sizeLargestTH.classList.add("list-header-data");     // directory-list-header > list-header-data
        sizeLargestTH.classList.add("header-size-largest");  // directory-list-header > header-size-largest
        sizeLargestTH.appendChild( document.createTextNode(this.#listHeaderText_size_largest) );
        sizeLargestTH.setAttribute("title", this.#listHeaderTooltip_size_largest);
      dirHeaderTR.appendChild(sizeLargestTH);

      // Create Total Size element and add it to the row
      const sizeTotalTH = document.createElement("th");
        sizeTotalTH.classList.add("list-header-data");   // directory-list-header > list-header-data
        sizeTotalTH.classList.add("header-size-totel");  // directory-list-header > header-size-totel
        sizeTotalTH.appendChild( document.createTextNode(this.#listHeaderText_size_total) );
        sizeTotalTH.setAttribute("title", this.#listHeaderTooltip_size_total);
      dirHeaderTR.appendChild(sizeTotalTH);

    return dirHeaderTR;
  }  



  // async just because of formatFileSize()
  async buildDirectoryListItemUI(dirStats, extensionInfo, extensionProps) {
    /*
     * dirStats
     *   {
     *     'dirName':                         string:   directory fileName
     *     'dirPath':                         string:   directory full pathName
     *     'error':                           string:   a description if there was an error getting information. None of the data below will be present.
     *     'count_children':                  integer:  total number of child items
     *     'count_type_regular':              integer:  number of child items with type 'regular'
     *     'count_type_directory':            integer:  number of child items with type 'directory'
     *     'count_type_other':                integer:  number of child items with type 'other'
     *     'count_type_unknown':              integer:  number of child items whose type is none of the three above
     *     'count_type_error':                integer:  number of child items whose type could not be determined
     *     'time_childCreation_earliest':     integer:  earliest Creation Time      of all child items in MS (OS-dependent) (undefined if no children)
     *     'time_childCreation_latest':       integer:  latest   Creation Time      of all child items in MS (OS-dependent) (undefined if no children)
     *     'time_childLastAccessed_earliest': integer:  earliest Last Accessed Time of all child items in MS (OS-dependent) (undefined if no children)
     *     'time_childLastAccessed_latest':   integer:  latest   Last Accessed Time of all child items in MS (OS-dependent) (undefined if no children)
     *     'time_childLastModified_earliest': integer:  earliest Last Modified Time of all child items in MS (OS-dependent) (undefined if no children)
     *     'time_childLastModified_latest':   integer:  latest   Last Modified Time of all child items in MS (OS-dependent) (undefined if no children)
     *     'size_smallest':                   integer:  smallest size (bytes) of all child items with type 'regular' (-1 if none)
     *     'size_largest':                    integer:  largest size (bytes) of all child items with type 'regular' (-1 if none)
     *     'size_total':                      integer:  total of sizes (bytes) of all child items with type 'regular'
     *   }
     */
    this.debug(`BUILD DIRECTORY LIST ITEM UI: --- dirStats:\n`, dirStats);

    const dirItemTR = document.createElement("tr");
      dirItemTR.classList.add("directory-list-item");             // directory-list-item
      dirItemTR.setAttribute("dirName", dirStats.dirName);
      dirItemTR.addEventListener("click", (e) => this.directoryListItemClicked(e));

      // Create Directory Name element and add it to the row
      const dirNameTD = document.createElement("td");
        dirNameTD.classList.add("list-item-data"); // directory-list-item > list-item-data
        dirNameTD.classList.add("list-item-name"); // directory-list-item > list-item-name
        dirNameTD.appendChild( document.createTextNode(dirStats.dirName) );
      dirItemTR.appendChild(dirNameTD);

      // Create Extension ID element and add it to the row
      const extIdTD = document.createElement("td");
        extIdTD.classList.add("list-item-data");   // directory-list-item > list-item-data
        extIdTD.classList.add("list-item-ext-id"); // directory-list-item > list-item-ext-id
        if (extensionInfo) {
          extIdTD.appendChild( document.createTextNode(extensionInfo.id) );
        }
      dirItemTR.appendChild(extIdTD);

      // Create Extension Installed element and add it to the row
      const extInstalledTD = document.createElement("td");
        extInstalledTD.classList.add("list-item-data");          // directory-list-item > list-item-data
        extInstalledTD.classList.add("list-item-boolean");       // directory-list-item > list-item-boolean
        extInstalledTD.classList.add("list-item-ext-installed"); // directory-list-item > list-item-ext-installed
        const extInstalledDotSpan = document.createElement("span");
          extInstalledDotSpan.classList.add("list-item-dot");
          if (extensionInfo) {
            extInstalledDotSpan.classList.add("dot-ext-installed");
          } else {
            extInstalledDotSpan.classList.add("dot-ext-not-installed");
          }
        extInstalledTD.appendChild(extInstalledDotSpan);
      dirItemTR.appendChild(extInstalledTD);

      // Create Extension Enabled element and add it to the row
      const extEnabledTD = document.createElement("td");
        extEnabledTD.classList.add("list-item-data");        // directory-list-item > list-item-data
        extEnabledTD.classList.add("list-item-boolean");     // directory-list-item > list-item-boolean
        extEnabledTD.classList.add("list-item-ext-enabled"); // directory-list-item > list-item-ext-enabled
        const extEnabledDotSpan = document.createElement("span");
          extEnabledDotSpan.classList.add("list-item-dot");
          if (extensionInfo) {
            if (extensionInfo.disabled) {
              extEnabledDotSpan.classList.add("dot-ext-disabled");
            } else {
              extEnabledDotSpan.classList.add("dot-ext-enabled");
            }
          } else {
            extEnabledDotSpan.classList.add("dot-ext-disabled-not-installed");
          }
        extEnabledTD.appendChild(extEnabledDotSpan);
      dirItemTR.appendChild(extEnabledTD);

      // Create Extension Configured element and add it to the row
      const extConfiguredTD = document.createElement("td");
        extConfiguredTD.classList.add("list-item-data");           // directory-list-item > list-item-data
        extConfiguredTD.classList.add("list-item-boolean");        // directory-list-item > list-item-boolean
        extConfiguredTD.classList.add("list-item-ext-configured"); // directory-list-item > list-item-ext-configured
        const extConfiguredDotSpan = document.createElement("span");
          extConfiguredDotSpan.classList.add("list-item-dot");
          if (extensionProps) {
            extConfiguredDotSpan.classList.add("dot-ext-configured");
          } else {
            extConfiguredDotSpan.classList.add("dot-ext-not-configured");
          }
        extConfiguredTD.appendChild(extConfiguredDotSpan);
      dirItemTR.appendChild(extConfiguredTD);

      // Create Extension Access Allowed element and add it to the row
      const extAccessAllowedTD = document.createElement("td");
        extAccessAllowedTD.classList.add("list-item-data");       // directory-list-item > list-item-data
        extAccessAllowedTD.classList.add("list-item-boolean");    // directory-list-item > list-item-boolean
        extAccessAllowedTD.classList.add("list-item-ext-access"); // directory-list-item > list-item-ext-access-allowed
        const extAccessAllowedDotSpan = document.createElement("span");
          extAccessAllowedDotSpan.classList.add("list-item-dot");
          if (extensionProps) {
            if (extensionProps.allowAccess) {
              extAccessAllowedDotSpan.classList.add("dot-ext-access-allowed");
            } else {
              extAccessAllowedDotSpan.classList.add("dot-ext-access-denied");
            }
          } else {
            extAccessAllowedDotSpan.classList.add("dot-ext-access-not-configured");
          }
        extAccessAllowedTD.appendChild(extAccessAllowedDotSpan);
      dirItemTR.appendChild(extAccessAllowedTD);
    


      // Create Child Count element and add it to the row
      const countChildrenTD = document.createElement("td");
        countChildrenTD.classList.add("list-item-data");  // directory-list-item > list-item-data
        countChildrenTD.classList.add("list-item-count"); // directory-list-item > list-item-count
        countChildrenTD.classList.add("count-children");  // directory-list-item > count-children
        countChildrenTD.appendChild( document.createTextNode( dirStats.count_children ) );
      dirItemTR.appendChild(countChildrenTD);

      // Create Type Regular Count element and add it to the row
      const countTypeRegularTD = document.createElement("td");
        countTypeRegularTD.classList.add("list-item-data");     // directory-list-item > list-item-data
        countTypeRegularTD.classList.add("list-item-count");    // directory-list-item > list-item-count
        countTypeRegularTD.classList.add("count-type-regular"); // directory-list-item > count-type-regular
        countTypeRegularTD.appendChild( document.createTextNode( dirStats.count_type_regular ) );
      dirItemTR.appendChild(countTypeRegularTD);

      // Create Type Directory Count element and add it to the row
      const countTypeDirectoryTD = document.createElement("td");
        countTypeDirectoryTD.classList.add("list-item-data");       // directory-list-item > list-item-data
        countTypeDirectoryTD.classList.add("list-item-count");      // directory-list-item > list-item-count
        countTypeDirectoryTD.classList.add("count-type-directory"); // directory-list-item > count-type-directory
        countTypeDirectoryTD.appendChild( document.createTextNode( dirStats.count_type_directory ) );
      dirItemTR.appendChild(countTypeDirectoryTD);

      // Create Type Other Count element and add it to the row
      const countTypeOtherTD = document.createElement("td");
        countTypeOtherTD.classList.add("list-item-data");   // directory-list-item > list-item-data
        countTypeOtherTD.classList.add("list-item-count");  // directory-list-item > list-item-count
        countTypeOtherTD.classList.add("count-type-other"); // directory-list-item > count-type-other
        countTypeOtherTD.appendChild( document.createTextNode( dirStats.count_type_other ) );
      dirItemTR.appendChild(countTypeOtherTD);

      // Create Type Unknown Count element and add it to the row
      const countTypeUnknownTD = document.createElement("td");
        countTypeUnknownTD.classList.add("list-item-data");     // directory-list-item > list-item-data
        countTypeUnknownTD.classList.add("list-item-count");    // directory-list-item > list-item-count
        countTypeUnknownTD.classList.add("count-type-unknown"); // directory-list-item > count-type-unknown
        countTypeUnknownTD.appendChild( document.createTextNode( dirStats.count_type_unknown ) );
      dirItemTR.appendChild(countTypeUnknownTD);

      // Create Type Error Count element and add it to the row
      const countTypeErrorTD = document.createElement("td");
        countTypeErrorTD.classList.add("list-item-data");   // directory-list-item > list-item-data
        countTypeErrorTD.classList.add("list-item-count");  // directory-list-item > list-item-count
        countTypeErrorTD.classList.add("count-type-error"); // directory-list-item > count-type-error
        countTypeErrorTD.appendChild( document.createTextNode( dirStats.count_type_error ) );
      dirItemTR.appendChild(countTypeErrorTD);



      // Create Earliest Child Creation Date/Time element and add it to the row
      const timeEarliestChildCreationTD = document.createElement("td");
        timeEarliestChildCreationTD.classList.add("list-item-data");               // directory-list-item > list-item-data
        timeEarliestChildCreationTD.classList.add("list-item-time");               // directory-list-item > list-item-time
        timeEarliestChildCreationTD.classList.add("time-child-creation-earliest"); // directory-list-item > time-child-creation-earliest
        timeEarliestChildCreationTD.appendChild( document.createTextNode( formatMsToDateTime24HR(dirStats.time_childCreation_earliest) ) );
      dirItemTR.appendChild(timeEarliestChildCreationTD);

      // Create Latest Child Creation Date/Time element and add it to the row
      const timeLatestChildCreationTD = document.createElement("td");
        timeLatestChildCreationTD.classList.add("list-item-data");             // directory-list-item > list-item-data
        timeLatestChildCreationTD.classList.add("list-item-time");             // directory-list-item > list-item-time
        timeLatestChildCreationTD.classList.add("time-child-creation-latest"); // directory-list-item > time-child-creation-latest
        timeLatestChildCreationTD.appendChild( document.createTextNode( formatMsToDateTime24HR(dirStats.time_childCreation_latest) ) );
      dirItemTR.appendChild(timeLatestChildCreationTD);

      // Create Earliest Child Last Accessed Date/Time element and add it to the row
      const timeEarliestChildLastAccessTD = document.createElement("td");
        timeEarliestChildLastAccessTD.classList.add("list-item-data");                    // directory-list-item > list-item-data
        timeEarliestChildLastAccessTD.classList.add("list-item-time");                    // directory-list-item > list-item-time
        timeEarliestChildLastAccessTD.classList.add("time-child-last-accessed-earliest"); // directory-list-item > time-child-last-accessed-earliest
        timeEarliestChildLastAccessTD.appendChild( document.createTextNode( formatMsToDateTime24HR(dirStats.time_childLastAccessed_earliest) ) );
      dirItemTR.appendChild(timeEarliestChildLastAccessTD);

      // Create Latest Child Last Accessed Date/Time element and add it to the row
      const timeLatestChildLastAccessedTD = document.createElement("td");
        timeLatestChildLastAccessedTD.classList.add("list-item-data");                  // directory-list-item > list-item-data
        timeLatestChildLastAccessedTD.classList.add("list-item-time");                  // directory-list-item > list-item-time
        timeLatestChildLastAccessedTD.classList.add("time-child-last-accessed-latest"); // directory-list-item > time-child-last-accessed-latest
        timeLatestChildLastAccessedTD.appendChild( document.createTextNode( formatMsToDateTime24HR(dirStats.time_childLastAccessedTime_latest) ) );
      dirItemTR.appendChild(timeLatestChildLastAccessedTD);

      // Create Earliest Child Last Modified Date/Time element and add it to the row
      const timeEarliestChildLastModifiedTD = document.createElement("td");
        timeEarliestChildLastModifiedTD.classList.add("list-item-data");                    // directory-list-item > list-item-data
        timeEarliestChildLastModifiedTD.classList.add("list-item-time");                    // directory-list-item > list-item-time
        timeEarliestChildLastModifiedTD.classList.add("time-child-last-modified-earliest"); // directory-list-item > time-child-last-modified-earliest
        timeEarliestChildLastModifiedTD.appendChild( document.createTextNode( formatMsToDateTime24HR(dirStats.time_childLastModified_earliest) ) );
      dirItemTR.appendChild(timeEarliestChildLastModifiedTD);

      // Create Latest Child Last Modified Date/Time element and add it to the row
      const timeLatestChildLastModifiedTD = document.createElement("td");
        timeLatestChildLastModifiedTD.classList.add("list-item-data");                  // directory-list-item > list-item-data
        timeLatestChildLastModifiedTD.classList.add("list-item-time");                  // directory-list-item > list-item-time
        timeLatestChildLastModifiedTD.classList.add("time-child-last-modified-latest"); // directory-list-item > time-child-last-modified-latest
        timeLatestChildLastModifiedTD.appendChild( document.createTextNode( formatMsToDateTime24HR(dirStats.time_childLastModified_latest) ) );
      dirItemTR.appendChild(timeLatestChildLastModifiedTD);



      // Create Smallest Size element and add it to the row
      const sizeSmallestTD = document.createElement("td");
        sizeSmallestTD.classList.add("list-item-data"); // directory-list-item > list-item-data
        sizeSmallestTD.classList.add("list-item-size"); // directory-list-item > list-item-size
        sizeSmallestTD.classList.add("size-smallest");  // directory-list-item > size-smallest
        sizeSmallestTD.appendChild( document.createTextNode( await messenger.messengerUtilities.formatFileSize(dirStats.size_smallest) ) );
      dirItemTR.appendChild(sizeSmallestTD);

      // Create Size element and add it to the row
      const sizeLargestTD = document.createElement("td");
        sizeLargestTD.classList.add("list-item-data"); // directory-list-item > list-item-data
        sizeLargestTD.classList.add("list-item-size"); // directory-list-item > list-item-size
        sizeLargestTD.classList.add("size-largest");   // directory-list-item > size-largest
        sizeLargestTD.appendChild( document.createTextNode( await messenger.messengerUtilities.formatFileSize(dirStats.size_largest) ) );
      dirItemTR.appendChild(sizeLargestTD);

      // Create Size element and add it to the row
      const sizeTotalTD = document.createElement("td");
        sizeTotalTD.classList.add("list-item-data"); // directory-list-item > list-item-data
        sizeTotalTD.classList.add("list-item-size"); // directory-list-item > list-item-size
        sizeTotalTD.classList.add("size-total");     // directory-list-item > size-total
        sizeTotalTD.appendChild( document.createTextNode( await messenger.messengerUtilities.formatFileSize(dirStats.size_total) ) );
      dirItemTR.appendChild(sizeTotalTD);

    return dirItemTR;
  }  



  // - directoryNames: array of string
  async showDeleteDirsConfirmDialog(directoryNames) {
    this.debugAlways( "\n--- begin:",
                `\n directoryNames="${directoryNames}"`,
                `\n (typeof directoryNames)="${typeof directoryNames}"`,
                `\n isArray(directoryNames)="${Array.isArray(directoryNames)}"`,                              // but is MUST be
                `\n directoryNames.length=${Array.isArray(directoryNames) ? directoryNames.length : '(not an array)'}`, // but is MUST be
              );

    if (directoryNames == null) {
      this.error("directoryNames is null");
      return;
    } else if (typeof directoryNames === 'undefined') {
      this.error("directoryNames is undefined");
      return;
    } else if (! Array.isArray(directoryNames)) {
      this.error("directoryNames is not an array");
      return;
    } else if (directoryNames.length < 0) {
      this.error("directoryNames.length < 0");
      return;
    } else if (typeof directoryNames[0] !== 'string') {
      this.error("directoryNames[0] is not a string");
      return;
    } else {
    }

    var   popupLeft   = 100;
    var   popupTop    = 100;
    var   popupHeight = 500;
    var   popupWidth  = 600;
    const mainWindow  = await messenger.windows.getCurrent();

    if (! mainWindow) {
      this.debug("-- DID NOT GET THE CURRENT (MAIN, mail:3pane) WINDOW!!! ---");

    } else {
      this.debug( "\n--- Got the Current (Main, mail:3pane) Window:",
                  `\n- mainWindow.top=${mainWindow.top}`,
                  `\n- mainWindow.left=${mainWindow.left}`,
                  `\n- mainWindow.height=${mainWindow.height}`,
                  `\n- mainWindow.width=${mainWindow.width}`,
                );
//////popupTop  = mainWindow.top  + mainWindow. / 2;
      popupTop  = mainWindow.top  + Math.round( (mainWindow.height - popupHeight) / 2 );
//////popupLeft = mainWindow.left + 100;
      popupLeft = mainWindow.left + Math.round( (mainWindow.width  - popupWidth)  / 2 );
      if (mainWindow.height - 200 > popupHeight) popupHeight - mainWindow.Height - 200;   // make it higher, but not shorter
////////if (mainWindow.Width  - 200 > popupWidth)  popupWidth  = mainWindow.Width  - 200;   // make it wider,  but not narrower --- eh, don't need it wider
    }

    const bounds = await this.#fsbOptionsApi.getWindowBounds("DeleteDirsConfirmDialog"); // MABXXX PERHAPS THIS SHOULD ALWAYS BE CENTERED??????

    if (! bounds) {
      this.debug("-- no previous window bounds");
    } else if (typeof bounds !== 'object') {
      this.error(`-- PREVIOUS WINDOW BOUNDS IS NOT AN OBJECT: typeof='${typeof bounds}' #####`);
    } else {
      this.debug( "\n--- restoring previous window bounds:",
                  `\n- bounds.top=${bounds.top}`,
                  `\n- bounds.left=${bounds.left}`,
                  `\n- bounds.width=${bounds.width}`,
                  `\n- bounds.height=${bounds.height}`,
                );
//    popupTop    = bounds.top;
      popupTop    = mainWindow ? mainWindow.top  + Math.round( (mainWindow.height - bounds.height) / 2 ) : bounds.top; // CENTER ON THE MAIN WINDOW!!!
//    popupLeft   = bounds.left;
      popupLeft   = mainWindow ? mainWindow.left + Math.round( (mainWindow.width  - bounds.width)  / 2 )  : bounds.left; // CENTER ON THE MAIN WINDOW!!!
      popupWidth  = bounds.width;
      popupHeight = bounds.height;
    }

    this.debug( "\n--- window bounds:",
                `\n- popupTop=${popupTop}`,
                `\n- popupLeft=${popupLeft}`,
                `\n- popupWidth=${popupWidth}`,
                `\n- popupHeight=${popupHeight}`,
              );



    // window.id does not exist.  how do we get our own window id???
    var   ourTabId;
    var   ourWindowId;
    const currentTab = await messenger.tabs.getCurrent();
    if (! currentTab) {
      this.debug("-- messenger.tabs.getCurrent() didn't return a Tab");
    } else {
      this.debug(`-- currentTab.id="${currentTab.id}" currentTab.windowId="${currentTab.windowId}"`);
      ourTabId    = currentTab.id;
      ourWindowId = currentTab.windowId;
    }

    const title           = getI18nMsg("fsbStatsManager_dialog_confirmDeleteDirs_title");           // "Confirm Directory Deletion"
    const button1MsgId    = "fsbStatsManager_dialog_confirmDeleteDirs_button_continue.label";
    const button2MsgId    = "fsbStatsManager_dialog_confirmDeleteDirs_button_cancel.label";
    const messageContinue = getI18nMsg("fsbStatsManager_dialog_confirmDeleteDirs_messageContinue"); // "Do you wish to continue?"

    var  confirmDialogUrl = messenger.runtime.getURL("../dialogs/confirm.html")
                             + `?windowName=${encodeURIComponent("DeleteDirsConfirmDialog")}`
                             + `&title=${encodeURIComponent(title)}`
                             + "&buttons_3=false"
                             + `&button1MsgId=${encodeURIComponent(button1MsgId)}`
                             + `&button2MsgId=${encodeURIComponent(button2MsgId)}`;

    var message1;
    var message2;
    if (directoryNames.length < 2) {
      message1 = getI18nMsg("fsbStatsManager_dialog_confirmDeleteDirs_oneDir_message1"); // "One Directory will be deleted"
      message2 = getI18nMsg("fsbStatsManager_dialog_confirmDeleteDirs_oneDir_message2"); // " "
    } else {
      message1 = getI18nMsgSubst("fsbStatsManager_dialog_confirmDeleteDirs_nnDirs_message1", directoryNames.length.toString()); // "NN Directories will be deleted"
      message2 = getI18nMsg(     "fsbStatsManager_dialog_confirmDeleteDirs_nnDirs_message2"                                  ); // " "
    }
    confirmDialogUrl +=   `&message1=${encodeURIComponent(message1)}`
                        + `&message2=${encodeURIComponent(message2)}`
                        + `&message3=${encodeURIComponent(messageContinue)}`;

    // MABXXX DAMN!!! THERE'S NO WAY TO MAKE THIS MODAL!!! MUST USE action "default_popup".  But how to get Extension ID, etc?
    // The window.confirm() function doesn't give a way to specify button text.
    // Which is worse? Ugly ugly UGLY!!!
    const confirmDialogWindow = await messenger.windows.create(
      {
        'url':                 confirmDialogUrl,
        'type':                "popup",
        'titlePreface':        getI18nMsg("extensionName") + " - ",
        'top':                 popupTop,
        'left':                popupLeft,
        'height':              popupHeight,
        'width':               popupWidth,
        'allowScriptsToClose': true,
      }
    );

    this.debug( "\n--- Delete Directories Confirmation Popup Window Created --",
                `\n-from ourTabId="${ourTabId}"`,
                `\n-from ourWindowId="${ourWindowId}"`,
                `\n-confirmDialogWindow.id="${confirmDialogWindow.id}"`,
                `\n-URL="${confirmDialogUrl}"`,
              );

    // Re-focus on the confirmDialog window when our window gets focus
    // MABXXX PERHAPS THIS SHOULD BE DONE INSIDE #confirmDialogPrompt() ???
//  const focusListener = async (windowId) => this.windowFocusChanged(windowId, ourTabId, ourWindowId, confirmDialogWindow.id);
    const focusListener = null;
//  messenger.windows.onFocusChanged.addListener(focusListener);

    // ConfirmDialogResponse - expected:
    // - null     - the user closed the popup window        (set by our own windows.onRemoved listener - the defaultResponse sent to #confirmDialogPrompt)
    // - CLOSED   - the user closed the popup window        (sent by the ConfirmDialog window's window.onRemoved listener -- NOT REALLY - we use our own onRemoved listener)
    // - BUTTON_1 - the user clicked button 1               (sent by the ConfirmDialog window's button listener)
    // - BUTTON_2 - the user clicked button 2               (sent by the ConfirmDialog window's button listener)
    // - BUTTON_3 - the user clicked button 3               (sent by the ConfirmDialog window's button listener)

    const confirmDialogResponse = await this.#confirmDialogPrompt(confirmDialogWindow.id, focusListener, null);
    this.debug(`-- confirmDialogResponse="${confirmDialogResponse}"`);

    switch (confirmDialogResponse) {
      case 'BUTTON_1': // 'Yes' button - Continue
        this.debug("-- ConfirmDialog 'Continue' clicked");
        return true;
      case 'BUTTON_2': // 'No' button - Cancel
        this.debug("-- ConfirmDialog 'Cancel' clicked");
        return false;
      case 'CLOSED':   // this never happens - see comments in ConfirmDialog regarding conduit failure
      case null:       // closed using the window close button
        this.debug("-- ConfirmDialog window closed");
        return false;
      default:
        this.error(`-- UNKNOWN ConfirmDialog Response - NOT A KNOWN RESPONSE: "${confirmDialogResponse}"`);
    }
  }

  async #confirmDialogPrompt(confirmDialogWindowId, focusListener, defaultResponse) {
    try {
      await messenger.windows.get(confirmDialogWindowId);
    } catch (error) {
      // Window does not exist, assume closed.
      this.caught(error, "-- PERHAPS WINDOW CLOSED???");
      return defaultResponse;
    }

    return new Promise(resolve => {
      var response = defaultResponse;

      function windowRemovedListener(windowId) {
        if (windowId == confirmDialogWindowId) {

          messenger.runtime.onMessage.removeListener(messageListener);
          messenger.windows.onRemoved.removeListener(windowRemovedListener);
//////////messenger.windows.onFocusChanged.removeListener(focusListener);

          resolve(response);
        }
      }

      /* The ConfirmDialog sends a message as ConfirmDialogResponse:
       * - CLOSED   - the user closed the popup window   (sent by the ConfirmDialog window's window.onRemoved listener -- NOT REALLY -- using OUR onRemoved instead)
       * - BUTTON_1 - the user clicked button 1          (sent by the ConfirmDialog window's button listener)
       * - BUTTON_2 - the user clicked button 2          (sent by the ConfirmDialog window's button listener)
       * - BUTTON_3 - the user clicked button 3          (sent by the ConfirmDialog window's button listener)
       * Save this ConfirmDialogResponse into response for resolve()
       */
      function messageListener(request, sender, sendResponse) {
        if (sender.tab && sender.tab.windowId == confirmDialogWindowId && request && request.hasOwnProperty("ConfirmDialogResponse")) {
          response = request.ConfirmDialogResponse;
        }

        return false; // we're not sending any response 
      }

      messenger.runtime.onMessage.addListener(messageListener);
      messenger.windows.onRemoved.addListener(windowRemovedListener);
    });
  }




  async getFsbStats() {
    let fsbStatsResponse;
    try {
      fsbStatsResponse = await this.#fsBrokerApi.fsbStats();
      this.debug( "\n\n========================\nfsbStatsResponse:\n", fsbStatsResponse, "\n========================\n\n" );
    } catch (error) {
      this.caught(error, "-- getFsbDirStats");
    }

    if (! fsbStatsResponse) {
      this.error("-- fsbStats -- NO RESPONSE");
    } else if (fsbStatsResponse.invalid) {
      this.error(`-- fsbStats -- FSB STATS ERROR: ${fsbStatsResponse.invalid}`);
    } else if (fsbStatsResponse.error) {
      this.error(`-- fsbStats -- FSB STATS ERROR: ${fsbStatsResponse.error}`);
    } else if (! fsbStatsResponse.stats) {
      this.error("-- fsbStats -- NO STATS RETURNED");
    } else if (! fsbStatsResponse.stats.fsbStats) {
      this.error("-- fsbStats -- NO FSB_STATS RETURNED");
    } else if (! fsbStatsResponse.stats.dirStats) {
      this.error("-- fsbStats -- NO DIR_STATS RETURNED");
    } else {
      return fsbStatsResponse.stats;
    }
  }



  updateUIOnSelectionChanged() {
    const deleteBtn     = document.getElementById("fsbStatsManagerDeleteButton");
    const selectedCount = this.getSelectedDomDirectoryListItemCount();

    if (! deleteBtn) {
      this.error("Failed to get element '#fsbStatsManagerDeleteButton'");
    } else {
      if (selectedCount == 0) {
        deleteBtn.disabled  = true;
      } else if (selectedCount == 1) {
        deleteBtn.disabled  = false;
      } else {
        deleteBtn.disabled  = false;
      }
    }
  }



  // and directory-list-item (TR or TD) was clicked
  async directoryListItemClicked(e) {
    if (! e) return;

////e.stopPropagation();
////e.stopImmediatePropagation();

    this.debug(`-- e.target.tagName="${e.target.tagName}"`);

    if (e.target.tagName == "TR" || e.target.tagName == "TD") {
      this.debug("-- TR or TD Clicked");

      let trElement = e.target;
      if (e.target.tagName == "TD") {
        trElement = e.target.closest('tr');
      }

      if (! trElement) {
        this.debug("-- Did NOT get our TR");

      } else {
        this.debug(  "-- Got our TR --"
                    + ` directory-list-item? ${trElement.classList.contains("directory-list-item")}`
                  );
        if (trElement.classList.contains("directory-list-item")) {
          const dirName     = trElement.getAttribute("dirName");
          const wasSelected = trElement.classList.contains('selected');
      
          this.debug(`-- wasSelected=${wasSelected}  dirName="${dirName}"`);

          if (! wasSelected) {
            trElement.classList.add('selected');
          } else {
            trElement.classList.remove('selected');
          }

          this.updateUIOnSelectionChanged();
        }
      }
    }
  }

  deselectAllDirectories() {
    const domDirectoryList = document.getElementById("fsbStatsManagerDirectoryList");
    if (! domDirectoryList) {
      this.error("-- failed to get domDirectoryList");
    } else {
      for (const listItem of domDirectoryList.children) {
        listItem.classList.remove('selected');
      }

      this.updateUIOnSelectionChanged();
    }
  }



  // get only the FIRST!!!
  getSelectedDomDirectoryListItem() {
    const domDirectoryList = document.getElementById("fsbStatsManagerDirectoryList");
    if (! domDirectoryList) {
      this.error("-- failed to get domDirectoryList");
    } else {
      for (const domDirectoryListItemTR of domDirectoryList.children) {
        if (domDirectoryListItemTR.classList.contains('selected')) {
          return domDirectoryListItemTR;
        }
      }
    }
  }

  getSelectedDomDirectoryListItems() {
    const domDirectoryList = document.getElementById("fsbStatsManagerDirectoryList");
    if (! domDirectoryList) {
      this.error("-- failed to get domDirectoryList");
    } else {
      const selected = [];
      for (const domDirectoryListItemTR of domDirectoryList.children) {
        if (domDirectoryListItemTR.classList.contains('selected')) {
          selected.push(domDirectoryListItemTR);
        }
      }
      return selected;
    }
  }

  getSelectedDomDirectoryListItemCount() {
    let   count           = 0;
    const domDirectoryList = document.getElementById("fsbStatsManagerDirectoryList");

    if (! domDirectoryList) {
      this.error("-- failed to get domDirectoryList");
    } else {
      for (const domDirectoryListItemTR of domDirectoryList.children) {
        if (domDirectoryListItemTR.classList.contains('selected')) {
          ++count;
        }
      }
    }

    return count;
  }



  async refreshButtonClicked(e) {
    this.debug(`-- e.target.tagName="${e.target.tagName}"`);

    e.preventDefault();

    const refreshBtn = document.getElementById("fsbStatsManagerRefreshButton");
    if (! refreshBtn) {
      this.error("Failed to get element '#fsbStatsManagerRefreshButton'");
    } else {
      refreshBtn.disabled = true;
    }

    await this.buildDirectoryListUI();

    this.updateUIOnSelectionChanged();

    if (refreshBtn) refreshBtn.disabled = false;
  }



  async deleteButtonClicked(e) {
    this.debug(`-- e.target.tagName="${e.target.tagName}"`);

    e.preventDefault();

    this.resetMessages();
    this.resetErrors();

    const deleteBtn = document.getElementById("fsbStatsManagerDeleteButton");
    if (! deleteBtn) {
      this.error("Failed to get element '#fsbStatsManagerDeleteButton'");
    } else {
      deleteBtn.disabled = true;
    }

    const domSelectedDirectoryItemTRs = this.getSelectedDomDirectoryListItems();

    if (! domSelectedDirectoryItemTRs) {
      this.error("-- NO DIRECTORIES SELECTED -- Delete Button should have been disabled!!!");

    } else {
      this.debug(`-- domSelectedDirectoryItemTRs.length=${domSelectedDirectoryItemTRs.length}`);

      const dirTRs   = [];
      const dirNames = [];
      for (const domSelectedDirectoryItemTR of domSelectedDirectoryItemTRs) {
        const dirName = domSelectedDirectoryItemTR.getAttribute("dirName");
        if (! dirName) {
          this.error("Failed to get Attribute 'dirName'");
        } else {
          this.debug(`-- Deleting Directory dirName="${dirName}"`);
          dirTRs.push(domSelectedDirectoryItemTR);
          dirNames.push(dirName);
        }
      }

      if (dirNames.length < 1) {
        this.error("No selected TRs had a 'dirName' attribute");

      } else {
        const confirmed = await this.showDeleteDirsConfirmDialog(dirNames);

        if (! confirmed) {
          this.debug("The user chose to cancel directory deletion");
          this.setMessageFor("fsbStatsManagerTitlePanel", "fsbStatsManager_message_directoryDeleteCanceled"); 

        } else {
          var errors  = 0;
          var deleted = 0;

          for (var i = 0;  i <  dirTRs.length; ++i) {
            const dirTR   = dirTRs[i];
            const dirName = dirNames[i];

            const response = await this.#fsBrokerApi.fsbDeleteDirectory( dirName, {'recursive': true} );

            if (! response) {
              this.error(`-- FAILED TO DELETE DIRECTORY -- NO RESPONSE RETURNED -- dirName="${dirName}"`);
              ++errors;
            } else if (response.invalid) {
              this.error(`-- FAILED TO DELETE DIRECTORY -- INVALID RETURNED -- dirName="${dirName}": ${response.invalid}`); // MABXXX <---------- add response.invalid everywhere
              ++errors;
            } else if (response.error) {
              this.error(`-- FAILED TO DELETE DIRECTORY -- ERROR RETURNED -- dirName="${dirName}": ${response.error}`); // MABXXX <-------------- add response.error everywhere
              ++errors;
            } else if (! response.directoryName) {
              this.error(`-- FAILED TO DELETE DIRECTORY -- NO DIRECTORY NAME RETURNED -- dirName="${dirName}": response.directoryName="${response.directoryName}"`);
              ++errors;
            } else if (! response.deleted) {
              this.error(`-- FAILED TO DELETE DIRECTORY -- dirName="${dirName}" response.deleted="${response.deleted}"`);
              ++errors;
            } else {
              this.debug(`-- Directory Deleted -- dirName="${dirName}": response.directoryName="${response.directoryName}"`);
              ++deleted;
              dirTR.remove();
            }
          }

          if (errors) {
            if (errors === 1) {
              this.setErrorFor("fsbStatsManagerTitlePanel", "fsbStatsManager_error_oneDirectoryDeleteFailed"); 
            } else {
              this.setErrorFor("fsbStatsManagerTitlePanel", "fsbStatsManager_error_nnDirectoriesDeleteFailed", errors); 
            }
          }
          if (deleted === 1) {
            this.setMessageFor("fsbStatsManagerTitlePanel", "fsbStatsManager_message_oneDirectoryDeleted"); 
          } else {
            this.setMessageFor("fsbStatsManagerTitlePanel", "fsbStatsManager_message_nnDirectoriesDeleted", deleted); 
          }
        }
      }
    }

    this.updateUIOnSelectionChanged();

//  if ( deleteBtn) {
//    deleteBtn.disabled = false; // MABXXX What if something is still selected???
//  }
  }



  resetMessages() {
    let msgPanelDivs = document.querySelectorAll("div.messages-panel"); // <--------------- NOTE: messages-panel - same as for resetErrors(), but different attribute
    if (msgPanelDivs) {
      for (let msgPanelDiv of msgPanelDivs) {
        msgPanelDiv.setAttribute("msg", "false"); // <------------------------------------- different from resetErrors();
      }
    }

    let msgDivs = document.querySelectorAll("div.stats-msg");
    if (msgDivs) {
      for (let msgDiv of msgDivs) {
        msgDiv.setAttribute("msg", "false");
      }
    }

    let msgLabels = document.querySelectorAll("label.stats-msg-text");
    if (msgLabels) {
      for (let msgLabel of msgLabels) {
        msgLabel.setAttribute("msg", "false");
        msgLabel.innerText = ""; // MABXXX THIS IS A HUGE LESSON:  DO NOT USE: <label/>   USE: <label></label> 
      }
    }
  }

  /* there can be no more than one message per elementId */
  setMessageFor(elementId, msgId, parms) {
    var i18nMessage;
    if (parms !== null && parms !== undefined) {
      i18nMessage = getI18nMsgSubst(msgId, parms);
    } else {
      i18nMessage = getI18nMsg(msgId);
    }
    
    if (i18nMessage) {
      if (elementId && msgId) {
        const messagesPanelDivSelector = `div.messages-panel[messages-for='${elementId}']`;
        const messagesPanelDiv = document.querySelector(messagesPanelDivSelector);
        if (messagesPanelDiv) {
          messagesPanelDiv.setAttribute("msg", "true");
        }

        const divSelector = `div.stats-msg[msg-for='${elementId}']`;
        const msgDiv = document.querySelector(divSelector);
        if (msgDiv) {
          msgDiv.setAttribute("msg", "true");
        }

        const labelSelector = `label.stats-msg-text[msg-for='${elementId}']`;
        const msgLabel = document.querySelector(labelSelector);
        if (msgLabel) {
          msgLabel.setAttribute("msg", "true");
          msgLabel.innerText = i18nMessage;
        }
      }
    }
  }



  resetErrors() {
    let msgPanelDivs = document.querySelectorAll("div.messages-panel"); // <--------------- NOTE: messages-panel - same as for resetMessages(), but different attribute
    if (msgPanelDivs) {
      for (let msgPanelDiv of msgPanelDivs) {
        msgPanelDiv.setAttribute("error", "false"); // <----------------------------------- different from resetMessages();
      }
    }

    let errorDivs = document.querySelectorAll("div.stats-error");
    if (errorDivs) {
      for (let errorDiv of errorDivs) {
        errorDiv.setAttribute("error", "false");
      }
    }

    let errorLabels = document.querySelectorAll("label.stats-error-text");
    if (errorLabels) {
      for (let errorLabel of errorLabels) {
        errorLabel.setAttribute("error", "false");
        errorLabel.innerText = ""; // MABXXX THIS IS A HUGE LESSON:  DO NOT USE: <label/>   USE: <label></label> 
      }
    }
  }

  /* there can be no more than one error message per elementId */
  setErrorFor(elementId, msgId, parms) {
    var i18nMessage;
    if (parms) {
      i18nMessage = getI18nMsgSubst(msgId, parms);
    } else {
      i18nMessage = getI18nMsg(msgId);
    }

    if (i18nMessage) {
      if (elementId && msgId) {
        const divPanelSelector = `div.messages-panel[messages-for='${elementId}']`;
        const msgPanelDiv = document.querySelector(divPanelSelector);
        if (msgPanelDiv) {
          msgPanelDiv.setAttribute("error", "true");
        }

        let errorDiv = document.querySelector("div.stats-error[error-for='" + elementId + "']");
        if (errorDiv) {
          errorDiv.setAttribute("error", "true");
        }

        let errorLabel = document.querySelector("label.stats-error-text[error-for='" + elementId + "']");
        if (errorLabel) {
          errorLabel.setAttribute("error", "true");
          errorLabel.innerText = i18nMessage;
        }
      }
    }
  }



  async doneButtonClicked(e) {
    this.debug(`-- e.target.tagName="${e.target.tagName}"`);

    e.preventDefault();

    this.#canceled = true;

    let responseMessage = "DONE";
    this.debug(`-- Sending responseMessage="${responseMessage}"`);

    try {
      await messenger.runtime.sendMessage(
        { StatsManagerResponse: responseMessage }
      );
    } catch (error) {
      // any need to tell the user???
      this.caught( error,
                   "##### SEND RESPONSE MESSAGE FAILED #####"
                   + `\n- responseMessage="${responseMessage}"`
                 );
    }

    this.debug("-- Closing window");
    window.close();
  }
}



const directoryManager = new StatsManager();

document.addEventListener("DOMContentLoaded", (e) => directoryManager.run(e), {once: true});
