start "" gvim -S eventLogViewer.css.session.vim
start "" gvim -S eventLogViewer.html.session.vim
start "" gvim -S eventLogViewer.js.session.vim
exit
