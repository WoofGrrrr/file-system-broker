start "" gvim -S eventLogManager.css.session.vim
start "" gvim -S eventLogManager.html.session.vim
start "" gvim -S eventLogManager.js.session.vim
exit
