start "" gvim -S backupManager.css.session.vim
start "" gvim -S backupManager.html.session.vim
start "" gvim -S backupManager.js.session.vim
exit
